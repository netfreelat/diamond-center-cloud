/**
 * TEST: Notificación WhatsApp a Admins - Nuevo Pedido
 * 
 * Este script simula un pedido nuevo llamando al endpoint /notificar
 * para verificar que los admins reciben la alerta por WhatsApp.
 * 
 * Uso: node scratch/test-wa-admin-notify.js [local|vps]
 *   local -> http://localhost:3500
 *   vps   -> https://recargasney.com (default)
 */

const https = require('https');
const http  = require('http');

const TARGET = process.argv[2] === 'local' ? 'http://localhost:3500' : 'https://recargasney.com';
const isHttps = TARGET.startsWith('https');
const mod = isHttps ? https : http;

// Datos del pedido de prueba
const testRef = `TEST${Date.now().toString().slice(-6)}`;
const params = new URLSearchParams({
    uid:       '123456789',
    login_uid: '123456789',
    name:      'Cliente Prueba',
    pack:      '520 + 52 Diamantes',
    method:    'pagomovil',
    price:     '5.20USDT/3302.00Bs',
    ref:       testRef,
    wa:        '04243790757'   // WA del "cliente" en la prueba
});

const url = new URL(`${TARGET}/notificar?${params.toString()}`);

console.log(`\n🚀 Enviando pedido de prueba a: ${TARGET}`);
console.log(`📋 Referencia de prueba: ${testRef}`);
console.log(`\n⏳ Esperando respuesta del servidor...\n`);

const req = mod.get(url.toString(), (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`📡 Respuesta HTTP: ${res.statusCode}`);
        try {
            const data = JSON.parse(body);
            console.log(`✅ Respuesta del servidor:`, JSON.stringify(data, null, 2));

            if (data.success) {
                console.log(`\n🎉 ¡Pedido creado! N° Control: ${data.control_num}`);
                console.log(`📲 En ~10 segundos deberías recibir el WhatsApp en:`);
                console.log(`   → 04243790757`);
                console.log(`   → 04125313735`);
                console.log(`\n💡 Si no llega, verifica que el bot de WhatsApp esté conectado.`);
            } else {
                console.log(`\n⚠️  El servidor respondió con error:`, data.message || 'Sin mensaje');
                if (data.message && data.message.includes('REPORTADO')) {
                    console.log(`   (Prueba con una ref diferente, esta ya existe)`);
                }
            }
        } catch(e) {
            console.log(`Respuesta raw:`, body.substring(0, 300));
        }
    });
});

req.on('error', (e) => {
    console.error(`❌ Error de conexión: ${e.message}`);
    console.log(`\n💡 Si usaste "local", asegúrate de que el servidor esté corriendo:`);
    console.log(`   node server.js`);
});

req.setTimeout(15000, () => {
    req.destroy();
    console.error('⏱️  Timeout: El servidor tardó más de 15 segundos.');
});
