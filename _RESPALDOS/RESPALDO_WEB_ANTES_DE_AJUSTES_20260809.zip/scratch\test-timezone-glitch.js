const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    const { data: allOrders } = await supabase
        .from('ff_orders')
        .select('ref, time, pack, price, method')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    // Let's print each order's UTC time and Caracas local time
    console.log('--- ALL APPROVED ORDERS NEAR JUNE 26-27 ---');
    allOrders.slice(0, 10).forEach(o => {
        const d = new Date(o.time);
        const caracasTime = d.toLocaleString('es-VE', { timeZone: 'America/Caracas' });
        console.log(`Ref: ${o.ref.padEnd(14)} | UTC: ${d.toISOString()} | Caracas: ${caracasTime} | Price: ${o.price}`);
    });

    console.log('\n--- SIMULATING SERVER ON UTC TIMEZONE AT DIFFERENT HOURS TODAY (JUN 27) ---');
    // Let's test system hours in UTC on Jun 27
    const testUTCHours = [0, 1, 2, 3, 4, 5, 6, 10, 14];
    for (const h of testUTCHours) {
        // Mock a system date in UTC
        const sysDate = new Date(`2026-06-27T${h.toString().padStart(2,'0')}:00:00.000Z`);
        
        // Simulating: const nowVE = new Date(sysDate.toLocaleString('en-US', { timeZone: 'America/Caracas' }));
        // Note: In Node on Linux (UTC), sysDate.toLocaleString('en-US', { timeZone: 'America/Caracas' })
        const veStr = sysDate.toLocaleString('en-US', { timeZone: 'America/Caracas' });
        // Parsing veStr as local (UTC)
        const nowVE = new Date(veStr);
        const startOfToday = new Date(nowVE);
        startOfToday.setHours(0, 0, 0, 0);

        let count = 0;
        let sumUsdt = 0;
        allOrders.forEach(o => {
            const t = new Date(o.time);
            if (t >= startOfToday) {
                count++;
                sumUsdt += 0.85; // rough
            }
        });
        console.log(`UTC Hour ${h}:00 -> Caracas hour is ${sysDate.toLocaleString('en-US', { timeZone: 'America/Caracas', hour: '2-digit', hour12: false })} | startOfToday (interpreted in UTC): ${startOfToday.toISOString()} | Count matched: ${count}`);
    }
}

run();
