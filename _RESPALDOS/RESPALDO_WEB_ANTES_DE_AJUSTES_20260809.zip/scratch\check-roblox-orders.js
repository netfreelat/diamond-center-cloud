const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function check() {
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('juego', 'roblox');

    if (error) {
        console.error('Error querying:', error.message);
    } else {
        console.log('All Roblox Orders in DB:');
        console.log(JSON.stringify(data, null, 2));
    }
}
check();
