const https = require('https');
const querystring = require('querystring');

const EMAIL = 'jmnetfreelat@gmail.com';
const PASSWORD = 'Clifor1988';

let cookieJar = '';

function request(options, body = null) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            const setCookies = res.headers['set-cookie'];
            if (setCookies) {
                setCookies.forEach(c => {
                    const cookiePart = c.split(';')[0];
                    if (!cookieJar.includes(cookiePart.split('=')[0])) {
                        cookieJar += (cookieJar ? '; ' : '') + cookiePart;
                    } else {
                        const key = cookiePart.split('=')[0];
                        cookieJar = cookieJar.replace(new RegExp(key + '=[^;]*'), cookiePart);
                    }
                });
            }
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
        });
        req.on('error', reject);
        if (body) req.write(body);
        req.end();
    });
}

async function main() {
    const loginData = querystring.stringify({ email: EMAIL, password: PASSWORD });
    const loginRes = await request({
        hostname: 'jadh.shop', path: '/login', method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(loginData) }
    }, loginData);

    const redirectPath = loginRes.headers['location'] ? (loginRes.headers['location'].startsWith('http') ? new URL(loginRes.headers['location']).pathname : loginRes.headers['location']) : '/';
    await request({ hostname: 'jadh.shop', path: redirectPath || '/', method: 'GET', headers: { 'Cookie': cookieJar } });

    const paquetesRes = await request({
        hostname: 'jadh.shop', path: '/producto/freefire-paquetes', method: 'GET',
        headers: { 'Cookie': cookieJar }
    });

    // Extract all input and select elements with their IDs and names
    const inputRegex = /<(input|select)[^>]+>/g;
    let match;
    console.log('--- Inputs en la pagina ---');
    while ((match = inputRegex.exec(paquetesRes.body)) !== null) {
        console.log(match[0]);
    }
}
main().catch(console.error);
