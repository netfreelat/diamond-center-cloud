const puppeteer = require('puppeteer');
require('dotenv').config();

async function run() {
    console.log('🚀 Lanzando navegador para inspeccionar transacciones en jadh.shop...');
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    try {
        console.log('🔑 Iniciando sesión...');
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com');
        await page.type('#login-password', process.env.JADH_PASSWORD || 'Clifor1988');
        
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        console.log('✅ Login completado. Cargando dashboard...');
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        // Obtener el HTML completo de las primeras 3 tarjetas de transacciones
        const cardsHTML = await page.evaluate(() => {
            const cards = Array.from(document.querySelectorAll('.card, .transaction-card, div')).filter(el => {
                const text = el.innerText || '';
                return text.includes('Monto total:') && text.includes('Orden:');
            });
            
            // Retornar el HTML externo de las tarjetas para analizar sus clases y elementos ocultos
            return cards.map(c => ({
                text: c.innerText,
                html: c.innerHTML
            }));
        });

        console.log('--- TARJETAS ENCONTRADAS ---');
        cardsHTML.forEach((c, i) => {
            console.log(`\nCard #${i+1}:`);
            console.log('TEXT:', c.text);
            console.log('HTML:', c.html.substring(0, 1000));
        });

    } catch (e) {
        console.error('❌ Error:', e);
    } finally {
        await browser.close();
    }
}

run();
