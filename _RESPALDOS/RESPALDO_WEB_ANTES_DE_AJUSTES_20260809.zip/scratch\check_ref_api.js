﻿// Este script consulta directamente la API del servidor local
const http = require('http');
const fs = require('fs');

// Leer el token de admin desde el sistema
const opts = {
    hostname: 'localhost',
    port: 3500,
    path: '/admin/referidos',
    headers: { 'Authorization': 'Bearer test-internal' }
};
http.get(opts, res => {
    let body = '';
    res.on('data', d => body += d);
    res.on('end', () => {
        console.log('STATUS:', res.statusCode);
        console.log(body);
        process.exit(0);
    });
}).on('error', e => {
    console.log('ERROR:', e.message);
    process.exit(1);
});
