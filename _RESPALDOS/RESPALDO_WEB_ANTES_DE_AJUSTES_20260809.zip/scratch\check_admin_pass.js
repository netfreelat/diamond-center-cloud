require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing SUPABASE_URL or SUPABASE_KEY in .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkAdmin() {
    const { data, error } = await supabase.from('ff_settings').select('admin_username, admin_password, id').eq('id', 1).single();
    if (error) {
        console.error('Error fetching settings:', error);
    } else {
        console.log('Supabase ff_settings Admin Record:', data);
    }
}

checkAdmin();
