const puppeteer = require('puppeteer');
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml'
};

(async () => {
    const root = path.join(__dirname, '..');
    const server = http.createServer((req, res) => {
        const parsedUrl = url.parse(req.url);
        let cleanPath = parsedUrl.pathname === '/' ? '/index.html' : parsedUrl.pathname;
        let filePath = path.join(root, cleanPath);
        const ext = path.extname(filePath).toLowerCase();
        const contentType = mimeTypes[ext] || 'application/octet-stream';

        fs.readFile(filePath, (err, content) => {
            if (err) {
                res.writeHead(404);
                res.end('Not found');
            } else {
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(content, 'utf-8');
            }
        });
    });

    server.listen(8085);

    const browser = await puppeteer.launch({
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    const pageErrors = [];

    page.on('pageerror', err => {
        pageErrors.push(`[PAGE ERROR] ${err.toString()}\n${err.stack}`);
    });

    try {
        await page.goto('http://localhost:8085/index.html', { waitUntil: 'networkidle0', timeout: 10000 });
    } catch(e) {}

    console.log("\n=== COMPROBANDO ESTADO DE LA PAGINA RESTAURADA ===");
    if (pageErrors.length === 0) {
        console.log("✅ Cero errores de JavaScript en la pagina limpia!");
    } else {
        pageErrors.forEach(e => console.log(e));
    }

    await browser.close();
    server.close();
})();
