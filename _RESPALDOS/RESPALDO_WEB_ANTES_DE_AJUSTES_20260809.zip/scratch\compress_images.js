const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const imgDir = 'c:\\Users\\juanm\\Documents\\PROYECTOS ANTIGRAVITY\\solo para verificar id de free fire\\img';
const rootDir = 'c:\\Users\\juanm\\Documents\\PROYECTOS ANTIGRAVITY\\solo para verificar id de free fire';

async function run() {
    console.log("Iniciando optimización de imágenes con Puppeteer...");
    const browser = await puppeteer.launch({ headless: 'new' });
    const page = await browser.newPage();

    const imagesToProcess = [
        // Background y banners pesados
        { path: path.join(rootDir, 'fondo.jpg'), maxW: 1920, type: 'jpeg', quality: 0.8 },
        { path: path.join(rootDir, 'badge-diamond.png'), maxW: 300, type: 'png' },
        { path: path.join(rootDir, 'reviews_banner.png'), maxW: 500, type: 'png' },
        
        // Logos de juegos
        { path: path.join(imgDir, 'bloodstrike_logo.png'), maxW: 800, type: 'png' },
        { path: path.join(imgDir, 'roblox_logo.png'), maxW: 800, type: 'png' },
        { path: path.join(imgDir, 'freefire_logo.png'), maxW: 800, type: 'png' },
        
        // Banners generados y temporales
        { path: path.join(imgDir, 'Gemini_Generated_Image_iia1h8iia1h8iia1.png'), maxW: 1200, type: 'png' },
        { path: path.join(imgDir, 'Gemini_Generated_Image_s5ynsos5ynsos5yn.png'), maxW: 1200, type: 'png' },
        { path: path.join(imgDir, 'Gemini_Generated_Image_z14e55z14e55z14e.png'), maxW: 1200, type: 'png' },
        { path: path.join(imgDir, '11.png'), maxW: 800, type: 'png' },
        
        // Iconos de paquetes (deben ser pequeños)
        { path: path.join(imgDir, 'pase_booyah.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'tarjeta_mensual.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'tarjeta_basica.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'roblox.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'bloodstrike_coin.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'tarjeta_semanal.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'diamante.png'), maxW: 200, type: 'png' },
        { path: path.join(imgDir, 'logo.jpg'), maxW: 300, type: 'jpeg', quality: 0.85 },
        { path: path.join(imgDir, '27b7d139-089c-40f0-8f9b-bd2f30ce79c1.jpeg'), maxW: 600, type: 'jpeg', quality: 0.8 }
    ];

    for (const item of imagesToProcess) {
        if (!fs.existsSync(item.path)) {
            console.log(`⚠️ Saltando (no existe): ${path.basename(item.path)}`);
            continue;
        }

        const statsBefore = fs.statSync(item.path);
        const sizeBefore = (statsBefore.size / 1024).toFixed(1);

        console.log(`\nOptimizando ${path.basename(item.path)} (Tamaño actual: ${sizeBefore} KB)...`);

        const base64 = fs.readFileSync(item.path).toString('base64');
        const fileExt = path.extname(item.path).substring(1).toLowerCase();
        const mime = fileExt === 'jpg' || fileExt === 'jpeg' ? 'image/jpeg' : 'image/png';
        const dataUrl = `data:${mime};base64,${base64}`;

        const compressedBase64 = await page.evaluate(async (url, maxW, targetType, quality) => {
            return new Promise((resolve, reject) => {
                const img = new Image();
                img.onload = () => {
                    let w = img.width;
                    let h = img.height;
                    
                    if (w > maxW) {
                        h = Math.round((maxW / w) * h);
                        w = maxW;
                    }

                    const canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    const ctx = canvas.getContext('2d');
                    
                    // Si es JPEG, rellenar el fondo con negro para evitar transparencia rota
                    if (targetType === 'jpeg') {
                        ctx.fillStyle = '#000000';
                        ctx.fillRect(0, 0, w, h);
                    }

                    ctx.drawImage(img, 0, 0, w, h);
                    
                    const mimeType = targetType === 'jpeg' ? 'image/jpeg' : 'image/png';
                    const dataUrlOut = canvas.toDataURL(mimeType, quality || 0.8);
                    resolve(dataUrlOut.split(',')[1]);
                };
                img.onerror = (e) => reject('Error cargando imagen en canvas');
                img.src = url;
            });
        }, dataUrl, item.maxW, item.type, item.quality);

        const buffer = Buffer.from(compressedBase64, 'base64');
        fs.writeFileSync(item.path, buffer);

        const statsAfter = fs.statSync(item.path);
        const sizeAfter = (statsAfter.size / 1024).toFixed(1);
        const pct = ((1 - statsAfter.size / statsBefore.size) * 100).toFixed(1);
        console.log(`✅ ¡Optimizado! Nuevo tamaño: ${sizeAfter} KB (Reducción de -${pct}%)`);
    }

    console.log("\n🎉 ¡Todas las imágenes se optimizaron con éxito!");
    await browser.close();
}

run().catch(console.error);
