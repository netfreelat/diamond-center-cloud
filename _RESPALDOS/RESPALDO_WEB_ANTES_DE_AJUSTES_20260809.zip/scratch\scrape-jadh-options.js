const puppeteer = require('puppeteer');
const path = require('path');
require('dotenv').config();

async function scrapeOptions() {
    console.log('Lanzando navegador para obtener las opciones de Jadh.shop con login...');
    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.join(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    try {
        const browser = await puppeteer.launch(launchOptions);
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(60000);

        // 1. Login
        const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
        const password = process.env.JADH_PASSWORD || 'Clifor1988';

        console.log('Navegando a https://jadh.shop/ para hacer login...');
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });

        const needsLogin = await page.evaluate(() => {
            return !!document.querySelector('#login-email');
        });

        if (needsLogin) {
            console.log('Rellenando datos de inicio de sesión...');
            await page.waitForSelector('#login-email', { timeout: 15000 });
            await page.type('#login-email', email);
            await page.type('#login-password', password);

            console.log('Haciendo click en Iniciar Sesión...');
            await Promise.all([
                page.click('#login-form button[type="submit"]'),
                page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
            ]);
            console.log('Sesión iniciada con éxito.');
        } else {
            console.log('Sesión ya estaba activa.');
        }

        // 2. Navegar al producto
        console.log('Navegando a https://jadh.shop/producto/freefire-auto...');
        await page.goto('https://jadh.shop/producto/freefire-auto', { waitUntil: 'networkidle2' });

        console.log('Esperando por el selector #packageSelect...');
        await page.waitForSelector('#packageSelect', { timeout: 15000 });

        const options = await page.evaluate(() => {
            const select = document.querySelector('#packageSelect');
            const items = Array.from(select.options).map(opt => ({
                value: opt.value,
                text: opt.text.trim()
            }));
            return items;
        });

        console.log('OPCIONES ENCONTRADAS EN JADH.SHOP:');
        console.log(JSON.stringify(options, null, 2));

        await browser.close();
    } catch (e) {
        console.error('Error al hacer scraping:', e.message);
    }
}

scrapeOptions();
