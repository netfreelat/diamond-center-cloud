const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Buscando pedidos aprobados recientemente en Supabase...");
    
    // Obtener pedidos aprobados en las últimas 2 horas
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    
    const { data: orders, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    if (error) {
        console.error("Error obteniendo pedidos:", error.message);
        return;
    }

    console.log(`\nPedidos aprobados en total: ${orders.length}`);
    
    // Filtrar pedidos de hoy
    const now = Date.now();
    console.log(`Hora actual: ${new Date().toLocaleString("es-VE", { timeZone: "America/Caracas" })}`);

    for (const o of orders) {
        const orderTime = new Date(o.time).getTime();
        const diffMin = ((now - orderTime) / 60000).toFixed(1);
        
        // Si fue hace menos de 120 minutos
        if (diffMin < 120) {
            console.log(`-----------------------------------------------`);
            console.log(`Pedido Ref: ${o.ref} | Cliente: ${o.name} (ID: ${o.uid})`);
            console.log(`  Juego: ${o.juego} | Paquete: ${o.pack} | Precio: ${o.price}`);
            console.log(`  WhatsApp registrado: ${o.wa}`);
            console.log(`  Aprobado hace: ${diffMin} minutos (Hora: ${new Date(o.time).toLocaleString("es-VE", { timeZone: "America/Caracas" })})`);
            console.log(`  login_uid: ${o.login_uid}`);
        }
    }
}

run().catch(console.error);
