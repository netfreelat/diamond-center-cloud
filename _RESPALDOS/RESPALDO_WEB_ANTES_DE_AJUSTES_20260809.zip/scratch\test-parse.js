const text = `
Monto total:
0.63$
Orden:
#222694
Fecha:
2026-06-14 • 09:59 PM
Datos:
6959424640
Paquete:
Tarjeta Básica
Estado:
Exitoso`;

const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

const getValue = (lines, prefix) => {
    const idx = lines.findIndex(l => l.startsWith(prefix));
    if (idx === -1) return '';
    let val = lines[idx].substring(prefix.length).trim();
    if (!val && idx + 1 < lines.length) {
        val = lines[idx + 1].trim();
    }
    return val;
};

const uid1 = getValue(lines, 'ID de Jugador:');
const uid2 = getValue(lines, 'Datos:');
console.log("uid1:", uid1, "uid2:", uid2);
const uid = uid1 || uid2;
console.log("Final uid:", uid);
