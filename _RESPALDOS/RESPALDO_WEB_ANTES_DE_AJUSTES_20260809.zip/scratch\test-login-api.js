const http = require('http');
const body = JSON.stringify({ username: 'admin', password: 'admin123' });
const req = http.request({
  hostname: 'localhost',
  port: 3500,
  path: '/api/admin/login',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body)
  }
}, res => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    console.log('RESPUESTA:', d);
    process.exit(0);
  });
});
req.on('error', e => { console.error('ERROR:', e.message); process.exit(1); });
req.write(body);
req.end();
