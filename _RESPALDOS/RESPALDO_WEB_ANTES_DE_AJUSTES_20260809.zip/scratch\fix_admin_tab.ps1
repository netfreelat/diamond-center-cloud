$content = Get-Content 'admin.html' -Raw

# Fix literal \r\n that got inserted - replace the bad line that has literal backslash-r-backslash-n
$content = $content -replace '</script>\\r\\n\\r\\n    <!--', "</script>`r`n`r`n    <!--"

Set-Content 'admin.html' -Value $content -NoNewline
Write-Host "Done. Total lines: $((Get-Content 'admin.html').Count)"
