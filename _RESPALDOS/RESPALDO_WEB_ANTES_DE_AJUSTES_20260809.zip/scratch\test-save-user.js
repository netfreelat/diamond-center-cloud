require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Faltan credenciales de Supabase en .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function testSaveUser() {
    console.log('1. Intentando leer usuarios de ff_users...');
    const { data: users, error: readError } = await supabase
        .from('ff_users')
        .select('*')
        .limit(5);

    if (readError) {
        console.error('❌ Error al leer ff_users:', readError);
    } else {
        console.log('✅ Lectura exitosa. Usuarios encontrados:', users.length);
        if (users.length > 0) {
            console.log('Columnas disponibles en ff_users:', Object.keys(users[0]));
            console.log('Ejemplo de usuario en BD:', users[0]);
        }
    }

    console.log('\n2. Probando guardar un usuario de prueba con todos los campos...');
    const testUid = 'TEST_USER_' + Date.now();
    const payload = {
        uid: testUid,
        name: 'Test Name',
        apellido: 'Test Apellido',
        points: 10,
        password: 'test-password',
        cedula: 'V-12345678',
        phone: '584120000000',
        registered: new Date().toISOString(),
        referred_by: null,
        referral_claimed: false
    };

    const { data: insertData, error: insertError } = await supabase
        .from('ff_users')
        .upsert(payload);

    if (insertError) {
        console.error('❌ Error al guardar con todas las columnas:', insertError);
        
        console.log('\n3. Reintentando guardar con fallback (sin columnas extendidas)...');
        const fallbackPayload = {
            uid: testUid,
            name: 'Test Name',
            points: 10,
            password: 'test-password',
            registered: new Date().toISOString(),
            referred_by: null,
            referral_claimed: false
        };
        const { error: fallbackError } = await supabase
            .from('ff_users')
            .upsert(fallbackPayload);
            
        if (fallbackError) {
            console.error('❌ Falló también el fallback:', fallbackError);
        } else {
            console.log('✅ Fallback guardado correctamente.');
        }
    } else {
        console.log('✅ Guardado completo exitoso (la base de datos tiene todas las columnas).');
    }

    // Limpieza
    console.log('\n4. Limpiando usuario de prueba...');
    const { error: deleteError } = await supabase
        .from('ff_users')
        .delete()
        .eq('uid', testUid);
    if (deleteError) {
        console.error('❌ Error al limpiar:', deleteError);
    } else {
        console.log('✅ Limpieza completada.');
    }
}

testSaveUser();
