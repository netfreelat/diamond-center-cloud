const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function checkData() {
    console.log('--- BUSCANDO EN FF_PAGOS_RECIBIDOS ---');
    const { data: pagos, error: errPagos } = await supabase
        .from('ff_pagos_recibidos')
        .select('*');
    
    if (errPagos) {
        console.error('Error:', errPagos.message);
    } else {
        console.log(`Total rows in ff_pagos_recibidos: ${pagos.length}`);
        const matches = pagos.filter(p => p.ref.includes('1973') || p.ref.includes('01973'));
        console.log(`Encontrados ${matches.length} pagos recibidos con '1973':`);
        console.log(JSON.stringify(matches, null, 2));
    }

    console.log('\n--- BUSCANDO EN FF_ORDERS ---');
    const { data: orders, error: errOrders } = await supabase
        .from('ff_orders')
        .select('*')
        .order('time', { ascending: false });

    if (errOrders) {
        console.error('Error:', errOrders.message);
    } else {
        const pending = orders.filter(o => o.status === 'pending');
        console.log(`Encontrados ${pending.length} pedidos PENDIENTES:`);
        console.log(JSON.stringify(pending, null, 2));
    }
}

checkData();
