const ADMIN_WA_NUMBERS = ['04243790757', '04125313735'];
function isAdminPhone(phoneDigits) {
    if (!phoneDigits) return false;
    return ADMIN_WA_NUMBERS.some(adminNum => {
        let cleanAdmin = adminNum.replace(/\D/g, '');
        if (cleanAdmin.startsWith('0')) {
            cleanAdmin = '58' + cleanAdmin.substring(1);
        } else if (!cleanAdmin.startsWith('58') && cleanAdmin.length === 10) {
            cleanAdmin = '58' + cleanAdmin;
        }
        console.log("Comparing", phoneDigits, "with", cleanAdmin);
        return phoneDigits === cleanAdmin;
    });
}
console.log(isAdminPhone('584125322412'));
