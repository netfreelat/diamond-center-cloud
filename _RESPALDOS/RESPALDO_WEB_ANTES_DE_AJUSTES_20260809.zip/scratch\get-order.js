require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('ref', '7272')
        .single();

    if (error) {
        console.error('Error:', error.message);
        return;
    }

    console.log('Detalles del Pedido 7272:');
    console.log(JSON.stringify(data, null, 2));
}

run();
