const fs = require('fs');
const content = fs.readFileSync('server.js', 'utf8');
const lines = content.split('\n');
lines.forEach((line, index) => {
    if (line.includes('pagosValidados')) {
        console.log(`Line ${index + 1}: ${line}`);
    }
});
