const http = require('https'); // or http depending on SERVER_URL

const url = 'https://recargasney.com/api/admin/wa_broadcast_referrals';
const secret = 'Sneyder12345*#';

const data = JSON.stringify({});

const parsedUrl = new URL(url);
const options = {
    hostname: parsedUrl.hostname,
    port: parsedUrl.port || 443,
    path: parsedUrl.pathname,
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-WA-Secret': secret,
        'Content-Length': Buffer.byteLength(data)
    }
};

console.log('Sending broadcast trigger request to:', url);

const req = http.request(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`Status Code: ${res.statusCode}`);
        console.log('Response:', body);
    });
});

req.on('error', (err) => {
    console.error('Error:', err.message);
});

req.write(data);
req.end();
