const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function check() {
    const { data: data1, error: error1 } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('ref', '000000965');

    console.log("By Ref 000000965:", JSON.stringify(data1, null, 2));
}

check();
