const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.join(__dirname, '..', '.cache', 'puppeteer');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const puppeteer = require('puppeteer');

async function inspectMLBB() {
    let browser = null;
    try {
        const launchOptions = {
            headless: "new",
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        };
        if (process.platform === 'win32') {
            launchOptions.executablePath = path.join(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
        }
        browser = await puppeteer.launch(launchOptions);
        const page = await browser.newPage();
        
        console.log("Navigating to https://jadh.shop/producto/mobile-legends-us ...");
        await page.goto('https://jadh.shop/producto/mobile-legends-us', { waitUntil: 'networkidle2' });
        
        const currentUrl = page.url();
        console.log("Current URL:", currentUrl);
        
        if (currentUrl.includes('/auth') || currentUrl.includes('/login') || await page.$('#login-email')) {
            console.log("Logging in with email:", process.env.JADH_EMAIL);
            await page.waitForSelector('#login-email');
            await page.type('#login-email', process.env.JADH_EMAIL);
            await page.type('#login-password', process.env.JADH_PASSWORD);
            await Promise.all([
                page.click('#login-form button[type="submit"]'),
                page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
            ]);
            console.log("After login URL:", page.url());
            await page.goto('https://jadh.shop/producto/mobile-legends-us', { waitUntil: 'networkidle2' });
        }
        
        await new Promise(r => setTimeout(r, 2000));
        
        const info = await page.evaluate(() => {
            const select = document.querySelector('#packageSelect');
            const options = select ? Array.from(select.options).map(o => ({ value: o.value, text: o.textContent.trim() })) : [];
            const inputs = Array.from(document.querySelectorAll('input, select, textarea')).map(el => ({
                id: el.id,
                name: el.name,
                type: el.type,
                placeholder: el.placeholder,
                outerHTML: el.outerHTML
            }));
            return {
                title: document.title,
                url: window.location.href,
                options,
                inputs
            };
        });
        
        console.log("Product Info:", JSON.stringify(info, null, 2));
    } catch (e) {
        console.error("Error:", e);
    } finally {
        if (browser) await browser.close();
    }
}

inspectMLBB();
