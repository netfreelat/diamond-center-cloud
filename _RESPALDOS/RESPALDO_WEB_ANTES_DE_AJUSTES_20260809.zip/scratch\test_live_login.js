const https = require('https');
const http = require('http');

async function testLogin(hostname, isHttps, passwordToTest) {
    return new Promise((resolve) => {
        const postData = JSON.stringify({ username: 'admin', password: passwordToTest });
        const mod = isHttps ? https : http;
        const req = mod.request({
            hostname: hostname,
            path: '/api/admin/login',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        }, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                console.log(`[LOGIN TEST ${hostname} with '${passwordToTest}'] Status: ${res.statusCode} | Response: ${body}`);
                try {
                    const data = JSON.parse(body);
                    resolve(data);
                } catch (e) {
                    resolve(null);
                }
            });
        });

        req.on('error', (e) => {
            console.error(`[LOGIN TEST ERROR ${hostname}]`, e.message);
            resolve(null);
        });

        req.write(postData);
        req.end();
    });
}

async function testStats(hostname, isHttps, token) {
    return new Promise((resolve) => {
        const mod = isHttps ? https : http;
        const req = mod.request({
            hostname: hostname,
            path: '/admin/stats',
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        }, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                console.log(`[STATS TEST ${hostname}] Status: ${res.statusCode} | Response: ${body.substring(0, 150)}`);
                resolve(res.statusCode === 200);
            });
        });

        req.on('error', (e) => {
            console.error(`[STATS TEST ERROR ${hostname}]`, e.message);
            resolve(false);
        });

        req.end();
    });
}

async function runTests() {
    console.log("=== PROBANDO LOGIN EN RECARGASNEY.COM ===");
    const hosts = [
        { name: 'recargasney.com', isHttps: true },
        { name: 'recargasney.com', isHttps: false },
        { name: '13.140.142.173', isHttps: false }
    ];

    for (const h of hosts) {
        console.log(`\n--- Probando ${h.name} (HTTPS: ${h.isHttps}) ---`);
        const res1 = await testLogin(h.name, h.isHttps, 'Clifor1988**.');
        if (res1 && res1.success && res1.token) {
            console.log("🔑 Token obtenido con Clifor1988**.:", res1.token);
            const statsOk = await testStats(h.name, h.isHttps, res1.token);
            console.log("📊 Prueba de /admin/stats con token:", statsOk ? "EXITOSA ✅" : "FALLIDA ❌");
        }

        const res2 = await testLogin(h.name, h.isHttps, 'Sneyder12345*#');
        if (res2 && res2.success && res2.token) {
            console.log("🔑 Token obtenido con Sneyder12345*#:", res2.token);
            const statsOk2 = await testStats(h.name, h.isHttps, res2.token);
            console.log("📊 Prueba de /admin/stats con token:", statsOk2 ? "EXITOSA ✅" : "FALLIDA ❌");
        }
    }
}

runTests();
