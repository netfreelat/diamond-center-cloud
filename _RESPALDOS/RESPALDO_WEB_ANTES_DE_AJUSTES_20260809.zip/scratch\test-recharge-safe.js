const { rechargeViaJadh } = require('../jadh-service.js');
const puppeteer = require('puppeteer');
const path = require('path');

// Cargar variables de entorno
require('dotenv').config();

async function runSafeTest() {
    console.log('🛡️ Iniciando PRUEBA DE SEGURIDAD del Bot de Recarga...');
    console.log('Este test valida todo el flujo (Login, Navegación, Selección de campos) pero se detiene ANTES de clickear "RECARGAR" para no consumir tu saldo.');

    const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
    const password = process.env.JADH_PASSWORD || 'Clifor1988';
    const testUid = '2937558386'; // ID de prueba (Sneyder2107)
    const testPack = '100'; // Mapea a 110 💎 ($0.84)

    const browser = await puppeteer.launch({
        headless: true,
        executablePath: 'C:\\Users\\juanm\\Documents\\PROYECTOS ANTIGRAVITY\\solo para verificar id de free fire\\.cache\\puppeteer\\chrome\\win64-121.0.6167.85\\chrome-win64\\chrome.exe',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    try {
        console.log('1. Navegando a Jadh.shop...');
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });

        console.log('2. Iniciando sesión...');
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);

        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);
        console.log('✅ Sesión iniciada.');

        console.log('3. Navegando al producto Freefire Auto...');
        await page.goto('https://jadh.shop/producto/freefire-auto', { waitUntil: 'networkidle2' });

        console.log('4. Rellenando formulario de recarga...');
        await page.waitForSelector('#packageSelect', { timeout: 15000 });
        
        // Mapear 100 -> 156
        await page.select('#packageSelect', '156');
        console.log('✅ Paquete de 110 💎 ($0.84) seleccionado.');

        await page.waitForSelector('#gameAccountId', { timeout: 15000 });
        await page.type('#gameAccountId', testUid);
        console.log(`✅ ID de jugador ${testUid} ingresado.`);

        // Tomar captura de pantalla para corroborar visualmente que todo está listo
        const screenshotPath = path.join(__dirname, 'safe-test-ready.png');
        await page.screenshot({ path: screenshotPath, fullPage: true });
        console.log(`📸 Captura de pantalla de confirmación guardada en: ${screenshotPath}`);

        // Extraer los valores actuales de los campos para verificar
        const fields = await page.evaluate(() => {
            return {
                packageSelectValue: document.getElementById('packageSelect').value,
                gameAccountIdValue: document.getElementById('gameAccountId').value,
                buttonText: document.getElementById('btnPurchase').innerText.trim()
            };
        });

        console.log('\n--- VERIFICACIÓN DE VALORES EN PANTALLA ---');
        console.log('ID de paquete seleccionado:', fields.packageSelectValue, '(Esperado: 156)');
        console.log('ID de jugador ingresado:', fields.gameAccountIdValue, `(Esperado: ${testUid})`);
        console.log('Texto del botón de compra:', fields.buttonText, '(Esperado: RECARGAR)');
        console.log('-------------------------------------------\n');

        if (fields.packageSelectValue === '156' && fields.gameAccountIdValue === testUid) {
            console.log('🎉 ✅ ¡EL BOT HA PASADO TODAS LAS PRUEBAS CON ÉXITO! Todos los selectores y la lógica de Puppeteer son correctos.');
        } else {
            console.error('❌ Error: Algunos campos no se rellenaron correctamente.');
        }

    } catch (e) {
        console.error('❌ Ocurrió un error en la prueba:', e.message);
    } finally {
        await browser.close();
        console.log('🌐 Navegador cerrado. Test finalizado.');
    }
}

runSafeTest();
