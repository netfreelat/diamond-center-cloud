// Script para crear las tablas del programa de influencers en Supabase
// Ejecutar con: node scratch/setup-influencers-db.js

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_KEY,
    { auth: { persistSession: false } }
);

async function runSQL(description, sql) {
    console.log(`\n⏳ ${description}...`);
    try {
        const { data, error } = await supabase.rpc('exec_sql', { sql });
        if (error) {
            // rpc may not exist, try direct query via REST
            throw error;
        }
        console.log(`✅ ${description} — OK`);
        return true;
    } catch (e) {
        console.error(`❌ ${description} — Error: ${e.message}`);
        return false;
    }
}

async function createTableDirect(sql, label) {
    console.log(`\n⏳ ${label}...`);
    // Use supabase's postgrest to run raw SQL via the REST API
    const response = await fetch(`${process.env.SUPABASE_URL}/rest/v1/rpc/exec`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'apikey': process.env.SUPABASE_KEY,
            'Authorization': `Bearer ${process.env.SUPABASE_KEY}`
        },
        body: JSON.stringify({ query: sql })
    });
    if (!response.ok) {
        const text = await response.text();
        console.error(`❌ ${label}: ${text}`);
        return false;
    }
    console.log(`✅ ${label}`);
    return true;
}

async function setupInfluencerTables() {
    console.log('='.repeat(60));
    console.log('  Diamond Center FF — Setup Influencer Program');
    console.log(`  Supabase: ${process.env.SUPABASE_URL}`);
    console.log('='.repeat(60));

    // We'll use the Supabase Management API via fetch
    // Extract project ref from URL: https://<ref>.supabase.co
    const urlMatch = process.env.SUPABASE_URL.match(/https:\/\/([^.]+)\.supabase\.co/);
    if (!urlMatch) {
        console.error('❌ No se pudo extraer la referencia del proyecto de SUPABASE_URL');
        process.exit(1);
    }
    const projectRef = urlMatch[1];
    console.log(`\n📦 Proyecto: ${projectRef}`);

    // Tables to create using Supabase's insert-based approach
    // Since we can't run raw SQL without service_role, we'll use the supabase client
    // to create records and test if tables exist first
    
    // Strategy: Try inserting into ff_influencer_rates as a test
    // If table doesn't exist, we'll use the SQL via Management API
    
    console.log('\n🔍 Verificando si las tablas ya existen...');
    
    const { data: testData, error: testError } = await supabase
        .from('ff_influencers')
        .select('id')
        .limit(1);
    
    if (!testError) {
        console.log('✅ La tabla ff_influencers ya existe!');
        await checkAndInsertRates();
        return;
    }
    
    console.log('📝 Tablas no encontradas. Creando via Management API...');
    
    // Use Supabase Management API with service role
    // We need service_role key for DDL - try with anon key first via SQL endpoint
    const sqlStatements = [
        // ff_influencers
        `CREATE TABLE IF NOT EXISTS ff_influencers (
            id SERIAL PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            tiktok_handle TEXT NOT NULL,
            followers_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            diamonds_balance INTEGER DEFAULT 0,
            total_diamonds_earned INTEGER DEFAULT 0,
            admin_notes TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            last_login TIMESTAMPTZ
        )`,
        // ff_influencer_submissions
        `CREATE TABLE IF NOT EXISTS ff_influencer_submissions (
            id SERIAL PRIMARY KEY,
            influencer_id INTEGER NOT NULL,
            tiktok_url TEXT NOT NULL,
            title TEXT,
            description TEXT,
            screenshot_data TEXT,
            screenshot_filename TEXT,
            views_submitted INTEGER DEFAULT 0,
            views_verified INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            diamonds_awarded INTEGER DEFAULT 0,
            admin_notes TEXT,
            week_start DATE,
            submitted_at TIMESTAMPTZ DEFAULT NOW(),
            reviewed_at TIMESTAMPTZ,
            paid_at TIMESTAMPTZ
        )`,
        // ff_influencer_payments
        `CREATE TABLE IF NOT EXISTS ff_influencer_payments (
            id SERIAL PRIMARY KEY,
            influencer_id INTEGER NOT NULL,
            submission_id INTEGER,
            diamonds_amount INTEGER NOT NULL,
            note TEXT,
            week_label TEXT,
            paid_at TIMESTAMPTZ DEFAULT NOW()
        )`,
        // ff_influencer_rates
        `CREATE TABLE IF NOT EXISTS ff_influencer_rates (
            id SERIAL PRIMARY KEY,
            label TEXT NOT NULL,
            min_views INTEGER NOT NULL,
            max_views INTEGER,
            diamonds_reward INTEGER NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )`
    ];

    const mgmtUrl = `https://api.supabase.com/v1/projects/${projectRef}/database/query`;
    
    for (const sql of sqlStatements) {
        const tableName = (sql.match(/CREATE TABLE IF NOT EXISTS (\w+)/)||[])[1] || 'tabla';
        console.log(`\n⏳ Creando ${tableName}...`);
        
        try {
            const res = await fetch(mgmtUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.SUPABASE_KEY}`
                },
                body: JSON.stringify({ query: sql })
            });
            
            if (res.ok) {
                console.log(`✅ ${tableName} creada`);
            } else {
                const body = await res.text();
                console.error(`❌ ${tableName}: ${res.status} - ${body.slice(0, 200)}`);
            }
        } catch(e) {
            console.error(`❌ ${tableName}: ${e.message}`);
        }
    }
    
    await checkAndInsertRates();
}

async function checkAndInsertRates() {
    console.log('\n⏳ Verificando tarifas predeterminadas...');
    
    const { data: existingRates, error } = await supabase
        .from('ff_influencer_rates')
        .select('id')
        .limit(1);
    
    if (error) {
        console.error('❌ No se pudo acceder a ff_influencer_rates:', error.message);
        console.log('\n⚠️  Las tablas necesitan ser creadas manualmente en Supabase.');
        console.log('    Por favor ejecuta el archivo supabase_influencers.sql desde el Dashboard de Supabase.');
        return;
    }
    
    if (existingRates && existingRates.length > 0) {
        console.log('✅ Tarifas ya existen, no es necesario insertar.');
    } else {
        console.log('⏳ Insertando tarifas predeterminadas...');
        const rates = [
            { label: 'Basico',      min_views: 1000,   max_views: 4999,  diamonds_reward: 50,   is_active: true },
            { label: 'Intermedio',  min_views: 5000,   max_views: 9999,  diamonds_reward: 150,  is_active: true },
            { label: 'Popular',     min_views: 10000,  max_views: 49999, diamonds_reward: 400,  is_active: true },
            { label: 'Viral',       min_views: 50000,  max_views: 99999, diamonds_reward: 1000, is_active: true },
            { label: 'Mega Viral',  min_views: 100000, max_views: null,  diamonds_reward: 2500, is_active: true },
        ];
        
        const { error: insertErr } = await supabase
            .from('ff_influencer_rates')
            .insert(rates);
        
        if (insertErr) {
            console.error('❌ Error insertando tarifas:', insertErr.message);
        } else {
            console.log('✅ Tarifas predeterminadas insertadas!');
        }
    }
    
    // Final check: list all tables
    console.log('\n📊 Verificación final:');
    const tables = ['ff_influencers', 'ff_influencer_submissions', 'ff_influencer_payments', 'ff_influencer_rates'];
    
    for (const table of tables) {
        const { error: e } = await supabase.from(table).select('id').limit(1);
        if (!e) {
            console.log(`  ✅ ${table} — accesible`);
        } else {
            console.log(`  ❌ ${table} — ${e.message}`);
        }
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('  ✅ Setup completado!');
    console.log('  Abre: http://localhost:3500/influencers.html');
    console.log('='.repeat(60) + '\n');
}

setupInfluencerTables().catch(e => {
    console.error('Error fatal:', e.message);
    process.exit(1);
});
