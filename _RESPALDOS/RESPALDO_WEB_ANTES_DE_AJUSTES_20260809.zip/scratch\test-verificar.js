/**
 * test-verificar.js
 * Test the bdv payment verification logic with a known transaction
 */
require('dotenv').config();
const { verificarPagoBDV } = require('../bdv-service.js');

async function test() {
    console.log('🏦 TEST: Verificar Pago BDV con referencia 1433 y monto 5803.50 Bs');
    console.log('==================================================');
    
    // Debería encontrar la transacción de la UI del BDV
    const result = await verificarPagoBDV(5803.50, '1433');
    console.log('Resultado de la verificación:', result);
    
    if (result.success) {
        console.log('✅ ÉXITO: Pago verificado correctamente!');
    } else {
        console.log('❌ FALLO: No se encontró el pago.');
    }
    
    process.exit(0);
}

test().catch(e => {
    console.error(e);
    process.exit(1);
});
