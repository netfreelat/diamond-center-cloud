function testMatch(referencia, cleanRefReported, descripcion) {
    if (cleanRefReported.length < 4) {
        return false;
    }
    if (
        descripcion.includes('ABO TRASP') ||
        descripcion.includes('TRASPASO') ||
        descripcion.includes('TRANSFERENCIA')
    ) {
        const minLength = Math.max(8, cleanRefReported.length);
        const targetRefPortion = cleanRefReported.slice(-minLength);
        return referencia.endsWith(targetRefPortion) || referencia.includes(targetRefPortion);
    } else {
        return referencia.endsWith(cleanRefReported);
    }
}

// Cases
const cases = [
    // 1. Exact match with same length
    { bankRef: '0050900171973', userRef: '1973', desc: 'OPERACION PAGOMOVIL BDV', expected: true },
    // 2. Extra zero in user reference
    { bankRef: '0050900171973', userRef: '01973', desc: 'OPERACION PAGOMOVIL BDV', expected: false },
    // 3. User reference is shorter than 4 digits
    { bankRef: '0050900171973', userRef: '973', desc: 'OPERACION PAGOMOVIL BDV', expected: false },
    // 4. Exact 6-digit match
    { bankRef: '0050900171973', userRef: '171973', desc: 'OPERACION PAGOMOVIL BDV', expected: true },
    // 5. Transfer case - ends with 8 digits
    { bankRef: '0050900171973', userRef: '00171973', desc: 'ABO TRASP BDV', expected: true },
    // 6. Transfer case - shorter than 8 digits but matches suffix
    { bankRef: '0050900171973', userRef: '171973', desc: 'ABO TRASP BDV', expected: true },
    // 7. Transfer case - matches suffix
    { bankRef: '0050900171973', userRef: '0171973', desc: 'ABO TRASP BDV', expected: true }
];

let allPassed = true;
cases.forEach((c, idx) => {
    const res = testMatch(c.bankRef, c.userRef, c.desc);
    const passed = res === c.expected;
    if (!passed) allPassed = false;
    console.log(`Case ${idx + 1}: userRef='${c.userRef}', bankRef='${c.bankRef}', desc='${c.desc}' => result=${res} (expected: ${c.expected}) - ${passed ? '✅ PASS' : '❌ FAIL'}`);
});

console.log(`\nFinal result: ${allPassed ? '🎉 ALL PASSED!' : '💥 SOME FAILED!'}`);
