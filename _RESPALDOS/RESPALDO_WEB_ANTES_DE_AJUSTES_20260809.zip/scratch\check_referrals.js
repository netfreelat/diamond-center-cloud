const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Consultando base de datos de Supabase para analizar referidos...");
    
    // 1. Obtener todos los usuarios que fueron referidos por alguien
    const { data: users, error: usersErr } = await supabase
        .from('ff_users')
        .select('*')
        .not('referred_by', 'is', null);

    if (usersErr) {
        console.error("Error obteniendo usuarios:", usersErr.message);
        return;
    }

    console.log(`\nFound ${users.length} referred users in the database.`);
    
    if (users.length === 0) {
        console.log("No hay usuarios referidos registrados aún.");
        return;
    }

    // 2. Analizar el estado de cada uno
    let claimedCount = 0;
    let pendingCount = 0;

    for (const u of users) {
        console.log(`-----------------------------------------------`);
        console.log(`Usuario Referido: ${u.name} (ID: ${u.uid})`);
        console.log(`  Referido por: ${u.referred_by}`);
        console.log(`  ¿Compra realizada y beneficio cobrado?: ${u.referral_claimed ? 'SÍ (Recompensa entregada)' : 'NO (Pendiente de 1ra compra)'}`);
        
        if (u.referral_claimed) {
            claimedCount++;
            // Consultar cuántos puntos tiene el referidor
            const { data: referrer } = await supabase
                .from('ff_users')
                .select('*')
                .eq('uid', u.referred_by)
                .single();
            if (referrer) {
                console.log(`  Estado del Referidor (${referrer.name}): tiene ${referrer.points || 0} puntos ($${((referrer.points || 0) * 0.003).toFixed(2)} USDT)`);
            }
        } else {
            pendingCount++;
        }
    }

    console.log(`\n================ SUMMARY ================`);
    console.log(`Total Referidos: ${users.length}`);
    console.log(`  - Recompensas Cobradas (Primera compra hecha): ${claimedCount}`);
    console.log(`  - Vinculaciones Pendientes (Sin primera compra): ${pendingCount}`);
    console.log(`==========================================`);
}

run().catch(console.error);
