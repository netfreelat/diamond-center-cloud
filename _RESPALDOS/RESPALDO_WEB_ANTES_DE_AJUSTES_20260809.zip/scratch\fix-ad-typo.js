const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('❌ Falta SUPABASE_URL o SUPABASE_KEY en el .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function fixAdTypo() {
    try {
        const { data, error } = await supabase
            .from('ff_settings')
            .select('whatsapp_config')
            .eq('id', 1)
            .single();

        if (error) throw error;

        let config = data.whatsapp_config || {};
        if (config.publicidades && config.publicidades.length > 0) {
            config.publicidades.forEach(ad => {
                if (ad.imagen && ad.imagen.startsWith('ig/')) {
                    ad.imagen = ad.imagen.replace('ig/', 'img/');
                    console.log('🔄 Corrigiendo ruta de imagen:', ad.imagen);
                }
            });

            const { error: updateError } = await supabase
                .from('ff_settings')
                .update({ whatsapp_config: config })
                .eq('id', 1);

            if (updateError) throw updateError;
            console.log('✅ Base de datos actualizada con la ruta correcta!');
        } else {
            console.log('ℹ️ No hay publicidades para corregir.');
        }

    } catch (e) {
        console.error('❌ Error corrigiendo typo:', e.message);
    }
}

fixAdTypo();
