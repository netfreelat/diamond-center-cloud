const SUPABASE_URL = 'https://gtvlraxlszucoglbnzen.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0dmxyYXhsc3p1Y29nbGJuemVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4Mzg3MTcsImV4cCI6MjA5MTQxNDcxN30.IfbOm2PzrJx_Ycui1GPOeS30_18x4h7W4aMzSzYkr_Y';

const winnerData = {
    uid: "7247325486",
    name: "4z \u4e97\u4e59\u30d6\u5c3a\u5c3a\u30d6\u30c4\u1d2c",
    premio: "341 Diamantes",
    cycleEnd: "2026-07-27T01:00:00.000Z",
    timestamp: "2026-07-27T01:05:00.000Z",
    ticketList: []
};

const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': 'Bearer ' + SUPABASE_KEY,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation'
};

async function restore() {
    // Leer juegos actual
    const readRes = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1&select=juegos`, { headers });
    const readData = await readRes.json();
    if (!readData || !readData[0]) { console.error('No se pudo leer ff_settings'); return; }

    const juegos = readData[0].juegos || {};
    if (!juegos.sorteo_semanal) juegos.sorteo_semanal = {};
    juegos.sorteo_semanal.lastWinner = winnerData;
    juegos.sorteo_semanal.premio = "341 Diamantes";

    // Actualizar
    const updateRes = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ juegos })
    });
    const updateData = await updateRes.json();
    console.log('Status:', updateRes.status);

    if (updateRes.status === 200 || updateRes.status === 204) {
        console.log('✅ Ganador restaurado en Supabase:', winnerData.name, '(', winnerData.uid, ')');
    } else {
        console.error('❌ Error actualizando:', JSON.stringify(updateData));
    }

    // Verificar
    const checkRes = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1&select=juegos`, { headers });
    const checkData = await checkRes.json();
    const lw = checkData[0] && checkData[0].juegos && checkData[0].juegos.sorteo_semanal && checkData[0].juegos.sorteo_semanal.lastWinner;
    console.log('Verificación lastWinner:', lw ? lw.name + ' (' + lw.uid + ')' : 'null');
}

restore().catch(e => { console.error(e.message); process.exit(1); });

