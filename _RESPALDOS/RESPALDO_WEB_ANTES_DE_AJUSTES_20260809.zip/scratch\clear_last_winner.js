const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_KEY || '');

async function clearLastWinner() {
    console.log('Eliminando el ganador de prueba de Supabase...');

    // 1. Limpiar lastWinner de ff_settings
    const { data: settingsData, error } = await supabase
        .from('ff_settings')
        .select('*')
        .eq('id', 1)
        .single();

    if (error) {
        console.error('Error leyendo Supabase:', error.message);
        return;
    }

    const juegos = settingsData.juegos || {};
    if (juegos.sorteo_semanal) {
        delete juegos.sorteo_semanal.lastWinner;
        delete juegos.sorteo_semanal.lastResetTimestamp;
    }

    const { error: updateErr } = await supabase
        .from('ff_settings')
        .update({ juegos })
        .eq('id', 1);

    if (updateErr) {
        console.error('Error actualizando Supabase settings:', updateErr.message);
    } else {
        console.log('✅ lastWinner eliminado de ff_settings');
    }

    // 2. Limpiar registros de prueba de sorteo en ff_recientes
    const { error: recientesErr } = await supabase
        .from('ff_recientes')
        .delete()
        .eq('type', 'sorteo');

    if (recientesErr) {
        console.warn('Error eliminando recientes de prueba:', recientesErr.message);
    } else {
        console.log('✅ Entradas de prueba eliminadas de ff_recientes');
    }
}

clearLastWinner();
