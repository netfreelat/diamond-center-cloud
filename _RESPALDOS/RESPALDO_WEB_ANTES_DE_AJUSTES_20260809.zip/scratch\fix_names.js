const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { createClient } = require('@supabase/supabase-js');
const https = require('https');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error("Error: SUPABASE_URL y SUPABASE_KEY son requeridos en el archivo .env.");
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
    auth: { persistSession: false }
});

function fetchGarenaName(uid) {
    return new Promise((resolve) => {
        const postData = `action=ValidarParametros&id=${encodeURIComponent(uid)}`;
        const options = {
            hostname: 'netfreelat.net',
            path: '/redeem/conexion_api/api.php',
            method: 'POST',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                'Referer': 'https://netfreelat.net/redeem/',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            },
            timeout: 8000
        };

        const req = https.request(options, (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    let data = null;
                    const jsonMatch = body.match(/\{.*\}/s);
                    if (jsonMatch) {
                        try {
                            data = JSON.parse(jsonMatch[0]);
                        } catch (e) {}
                    }
                    if (data && data.alerta === 'green' && data.Nickname) {
                        resolve(data.Nickname.trim());
                    } else {
                        resolve(null);
                    }
                } catch (e) {
                    resolve(null);
                }
            });
        });

        req.on('error', () => resolve(null));
        req.on('timeout', () => {
            req.destroy();
            resolve(null);
        });
        req.write(postData);
        req.end();
    });
}

async function run() {
    console.log("Cargando usuarios desde Supabase...");
    const { data: users, error } = await supabase.from('ff_users').select('*');
    if (error) {
        console.error('Error al obtener usuarios de Supabase:', error.message);
        return;
    }
    
    console.log(`Total usuarios en Supabase: ${users.length}`);
    const targets = users.filter(u => {
        const nameClean = (u.name || '').trim().toLowerCase();
        const isGeneric = nameClean === 'jugador' || 
                          nameClean === 'pruebaff' || 
                          nameClean === 'jugadorpruebaff' || 
                          nameClean.includes('jugador') || 
                          nameClean.includes('pruebaff') || 
                          /^[\s\-—_~]*$/.test(nameClean);
        return isGeneric;
    });
    
    console.log(`Encontrados ${targets.length} usuarios con nombres genéricos.`);
    
    let successCount = 0;
    for (const user of targets) {
        console.log(`Procesando UID: ${user.uid} (Nombre actual: '${user.name}')...`);
        const cleanUid = user.uid.replace(/\D/g, '');
        const garenaName = await fetchGarenaName(cleanUid);
        if (garenaName) {
            console.log(`  -> Nombre real Garena encontrado: '${garenaName}'`);
            const { error: updateError } = await supabase
                .from('ff_users')
                .update({ name: garenaName })
                .eq('uid', user.uid);
            
            if (updateError) {
                console.error(`  ❌ Error actualizando en Supabase:`, updateError.message);
            } else {
                console.log(`  ✅ Actualizado con éxito en Supabase.`);
                successCount++;
            }
        } else {
            console.log(`  ⚠️ No se pudo obtener el nombre real de Garena para el UID: ${user.uid}`);
        }
        // Pequeño retardo entre peticiones
        await new Promise(r => setTimeout(r, 800));
    }
    console.log(`Proceso terminado. Se actualizaron con éxito ${successCount} usuarios.`);
}

run();
