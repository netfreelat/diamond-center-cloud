/**
 * Script para extraer los paquetes de jadh.shop/producto/freefire-paquetes
 * usando login con credenciales reales y mantiendo la sesión (cookies)
 */
const https = require('https');
const querystring = require('querystring');

const EMAIL = 'jmnetfreelat@gmail.com';
const PASSWORD = 'Clifor1988';

let cookieJar = '';

function request(options, body = null) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            // Guardar cookies
            const setCookies = res.headers['set-cookie'];
            if (setCookies) {
                setCookies.forEach(c => {
                    const cookiePart = c.split(';')[0];
                    if (!cookieJar.includes(cookiePart.split('=')[0])) {
                        cookieJar += (cookieJar ? '; ' : '') + cookiePart;
                    } else {
                        // Reemplazar cookie existente
                        const key = cookiePart.split('=')[0];
                        cookieJar = cookieJar.replace(new RegExp(key + '=[^;]*'), cookiePart);
                    }
                });
            }

            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
        });
        req.on('error', reject);
        if (body) req.write(body);
        req.end();
    });
}

async function main() {
    console.log('🔑 Paso 1: Obteniendo página de login para capturar CSRF token...');
    
    const loginPageRes = await request({
        hostname: 'jadh.shop',
        path: '/',
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml'
        }
    });

    console.log('Login page status:', loginPageRes.status);
    
    // Buscar CSRF token si existe
    let csrfToken = '';
    const csrfMatch = loginPageRes.body.match(/name="csrf_token"\s+value="([^"]+)"/);
    if (csrfMatch) {
        csrfToken = csrfMatch[1];
        console.log('CSRF token encontrado:', csrfToken);
    } else {
        console.log('Sin CSRF token (no requerido)');
    }

    console.log('\n🔐 Paso 2: Enviando credenciales de login...');
    
    const loginData = querystring.stringify({
        email: EMAIL,
        password: PASSWORD,
        ...(csrfToken ? { csrf_token: csrfToken } : {})
    });

    const loginRes = await request({
        hostname: 'jadh.shop',
        path: '/login',
        method: 'POST',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(loginData),
            'Cookie': cookieJar,
            'Referer': 'https://jadh.shop/',
            'Accept': 'text/html,application/xhtml+xml'
        }
    }, loginData);

    console.log('Login response status:', loginRes.status);
    console.log('Cookies guardadas:', cookieJar.substring(0, 100) + '...');
    
    if (loginRes.status === 302 || loginRes.status === 301) {
        const redirect = loginRes.headers['location'];
        console.log('Redireccionando a:', redirect);
        
        // Seguir redirect
        const redirectPath = redirect.startsWith('http') ? new URL(redirect).pathname : redirect;
        const afterLogin = await request({
            hostname: 'jadh.shop',
            path: redirectPath || '/',
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Cookie': cookieJar,
                'Accept': 'text/html,application/xhtml+xml'
            }
        });
        console.log('After redirect status:', afterLogin.status);
    }

    console.log('\n🛒 Paso 3: Accediendo a freefire-paquetes...');
    
    const paquetesRes = await request({
        hostname: 'jadh.shop',
        path: '/producto/freefire-paquetes',
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': cookieJar,
            'Accept': 'text/html,application/xhtml+xml',
            'Referer': 'https://jadh.shop/'
        }
    });

    console.log('Freefire-paquetes status:', paquetesRes.status);
    
    if (paquetesRes.body.includes('login') || paquetesRes.body.includes('Iniciar Sesión')) {
        console.log('⚠️  Aún requiere login. Guardando HTML para inspección...');
        require('fs').writeFileSync('scratch/paquetes_response.html', paquetesRes.body);
        console.log('HTML guardado en scratch/paquetes_response.html');
        return;
    }

    // Extraer opciones del select
    console.log('\n📦 Extrayendo paquetes del selector...');
    const optionRegex = /<option\s+value="([^"]+)"[^>]*>([^<]+)<\/option>/g;
    let match;
    const options = [];
    while ((match = optionRegex.exec(paquetesRes.body)) !== null) {
        options.push({ value: match[1], text: match[2].trim() });
    }

    if (options.length > 0) {
        console.log('\n✅ PAQUETES ENCONTRADOS:');
        options.forEach(o => console.log(`  value="${o.value}" => "${o.text}"`));
    } else {
        console.log('❌ No se encontraron opciones en el select. Guardando HTML...');
        require('fs').writeFileSync('scratch/paquetes_response.html', paquetesRes.body);
        console.log('HTML guardado en scratch/paquetes_response.html');
    }
    
    // También buscar freefire-auto para comparar
    console.log('\n📊 Comparando con freefire-auto...');
    const autoRes = await request({
        hostname: 'jadh.shop',
        path: '/producto/freefire-auto',
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Cookie': cookieJar,
            'Accept': 'text/html,application/xhtml+xml'
        }
    });

    const autoOptions = [];
    while ((match = optionRegex.exec(autoRes.body)) !== null) {
        autoOptions.push({ value: match[1], text: match[2].trim() });
    }
    
    if (autoOptions.length > 0) {
        console.log('\n✅ PAQUETES freefire-auto (ya implementados):');
        autoOptions.forEach(o => console.log(`  value="${o.value}" => "${o.text}"`));
    }
}

main().catch(console.error);
