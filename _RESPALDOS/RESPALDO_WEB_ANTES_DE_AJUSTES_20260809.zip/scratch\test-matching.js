function areRefsSimilar(ref1, ref2) {
    if (!ref1 || !ref2) return false;
    
    // Saneamiento: remover caracteres no alfanuméricos
    const r1 = ref1.toString().trim().replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    const r2 = ref2.toString().trim().replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    
    if (!r1 || !r2) return false;

    if (r1 === r2) return true;
    if (r1.endsWith(r2) || r2.endsWith(r1)) return true;

    // Si ambos son puramente numéricos, comparar los últimos 6 dígitos (control bancario común)
    const isNum1 = /^\d+$/.test(r1);
    const isNum2 = /^\d+$/.test(r2);
    if (isNum1 && isNum2) {
        const minLen = Math.min(r1.length, r2.length);
        if (minLen >= 6) {
            // Comparar los últimos 6 o 7 dígitos (máximo disponible de forma segura)
            const compareLen = minLen >= 7 ? 7 : 6;
            const end1 = r1.slice(-compareLen);
            const end2 = r2.slice(-compareLen);
            return end1 === end2;
        }
    }

    return false;
}

const tests = [
    { a: '006675887569', b: '006675887569', expected: true, label: 'Coincidencia exacta' },
    { a: '006675887569', b: '0677275887569', expected: true, label: 'Diferente prefijo, mismo final (7 dígitos)' },
    { a: '006675892039', b: '0677275892039', expected: true, label: 'Caso 2: Santana ref 2' },
    { a: '1234567', b: '567', expected: true, label: 'EndsWith corto' },
    { a: '123456', b: '789012', expected: false, label: 'Diferentes números' },
    { a: '123', b: '123', expected: true, label: 'Números muy cortos idénticos' },
    { a: '123', b: '124', expected: false, label: 'Números muy cortos diferentes' },
    { a: 'Ref: 006675887569', b: '006675887569', expected: true, label: 'Alfanumérico con texto' },
    { a: '006675887569', b: '0677275887568', expected: false, label: 'Diferente último dígito' }
];

let failed = 0;
tests.forEach((t, index) => {
    const result = areRefsSimilar(t.a, t.b);
    if (result === t.expected) {
        console.log(`✅ Test ${index + 1} passed: ${t.label}`);
    } else {
        console.error(`❌ Test ${index + 1} FAILED: ${t.label} (Got ${result}, expected ${t.expected})`);
        failed++;
    }
});

if (failed === 0) {
    console.log('\n🌟 ¡TODOS LOS TESTS PASARON EXITOSAMENTE! 🌟');
    process.exit(0);
} else {
    console.error(`\n❌ Fallaron ${failed} tests.`);
    process.exit(1);
}
