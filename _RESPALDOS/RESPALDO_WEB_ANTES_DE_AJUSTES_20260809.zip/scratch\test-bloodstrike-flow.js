/**
 * TEST: Flujo completo de Blood Strike en modo simulación
 * Simula una recarga de Blood Strike via jadh.shop (TEST_MODE = true)
 * Sin consumir saldo real.
 */
const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
process.env.TEST_MODE = 'true'; // ← SEGURO: no compra nada real
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const { rechargeViaJadh } = require('../jadh-service.js');

const TEST_UID     = '123456789';   // ID de jugador de prueba
const TEST_PACK    = '100';         // Paquete: 100+5 🪙 ($0.73)

async function main() {
    console.log('╔══════════════════════════════════════╗');
    console.log('║   TEST BLOOD STRIKE — jadh.shop      ║');
    console.log('║   Modo: SIMULACIÓN (sin gasto real)  ║');
    console.log('╚══════════════════════════════════════╝\n');
    console.log(`🎮 Juego:   Blood Strike`);
    console.log(`🆔 UID:     ${TEST_UID}`);
    console.log(`📦 Paquete: ${TEST_PACK} (100+5🪙 = $0.73)\n`);

    const result = await rechargeViaJadh(TEST_UID, TEST_PACK, 'bloodstrike');

    console.log('\n══ RESULTADO ══');
    if (result.success) {
        console.log('✅ ÉXITO:');
        console.log(`   Orden:    ${result.orderId}`);
        console.log(`   Nickname: ${result.nickname}`);
        console.log(`   Monto:    ${result.amount}`);
        console.log(`   Mensaje:  ${result.message}`);
    } else {
        console.log('❌ FALLO:');
        console.log(`   Mensaje: ${result.message}`);
    }
}

main().catch(err => {
    console.error('Error inesperado:', err.message);
    process.exit(1);
});
