const puppeteer = require('puppeteer-core');

(async () => {
    try {
        const browser = await puppeteer.launch({ 
            executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--no-zygote', '--single-process']
        });
        const page = await browser.newPage();
        
        console.log("Navigating to Roblox USA page...");
        await page.goto('https://jadh.shop/producto/roblox-usa', { waitUntil: 'networkidle2' });
        
        console.log("Checking dropdown packages...");
        const options = await page.$$eval('#packageSelect option, select[name="product_package"] option, select option', opts => 
            opts.map(o => ({ value: o.value, text: o.textContent.trim() }))
        ).catch(e => []);
        console.log("Dropdown Options:", JSON.stringify(options, null, 2));
        
        const inputs = await page.$$eval('input[type="text"], input[type="number"], input[name^="gp_"]', inputs => 
            inputs.map(i => ({ name: i.name, id: i.id, placeholder: i.placeholder }))
        ).catch(e => []);
        console.log("Inputs found:", JSON.stringify(inputs, null, 2));
        
        await browser.close();
    } catch (e) {
        console.error(e);
    }
})();
