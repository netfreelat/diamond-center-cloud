const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function checkBloodstrikeSelectors() {
    console.log('[TEST-BLOODSTRIKE] 🚀 Analizando selectores de Bloodstrike en jadh.shop...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(60000);

    try {
        // --- Login ---
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2' })
        ]);

        // --- Bloodstrike ---
        await page.goto('https://jadh.shop/producto/bloodstrike', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        const bsInfo = await page.evaluate(() => {
            const selects = Array.from(document.querySelectorAll('select')).map(s => ({
                id: s.id, name: s.name, class: s.className,
                options: Array.from(s.options).map(o => ({ value: o.value, text: o.text.trim() }))
            }));
            const inputs = Array.from(document.querySelectorAll('input')).map(i => ({
                id: i.id, name: i.name, type: i.type, placeholder: i.placeholder
            }));
            const buttons = Array.from(document.querySelectorAll('button, [type="submit"]')).map(b => ({
                id: b.id, text: b.innerText.trim().substring(0, 50), type: b.type
            }));
            const hasPackageSelect = !!document.querySelector('#packageSelect');
            return { selects, inputs, buttons, hasPackageSelect, title: document.title, url: location.href };
        });

        console.log('\n=== BLOODSTRIKE ===');
        console.log('URL:', bsInfo.url);
        console.log('Título:', bsInfo.title);
        console.log('#packageSelect existe:', bsInfo.hasPackageSelect);
        console.log('Selects encontrados:', JSON.stringify(bsInfo.selects, null, 2));
        console.log('Inputs encontrados:', JSON.stringify(bsInfo.inputs, null, 2));
        console.log('Botones encontrados:', JSON.stringify(bsInfo.buttons, null, 2));

    } catch (e) {
        console.error('[TEST-BLOODSTRIKE] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[TEST-BLOODSTRIKE] 🏁 Fin.');
    }
}

checkBloodstrikeSelectors();
