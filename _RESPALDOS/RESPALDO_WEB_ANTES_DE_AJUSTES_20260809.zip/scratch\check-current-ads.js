const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('❌ Falta SUPABASE_URL o SUPABASE_KEY en el .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkSupabaseSettings() {
    try {
        const { data, error } = await supabase
            .from('ff_settings')
            .select('whatsapp_config')
            .eq('id', 1)
            .single();

        if (error) throw error;

        console.log('--- WHATSAPP_CONFIG EN SUPABASE ---');
        console.log(JSON.stringify(data.whatsapp_config, null, 2));

    } catch (e) {
        console.error('❌ Error fetching settings:', e.message);
    }
}

checkSupabaseSettings();
