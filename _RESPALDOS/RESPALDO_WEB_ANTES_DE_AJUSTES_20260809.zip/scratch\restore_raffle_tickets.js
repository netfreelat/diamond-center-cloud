const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_KEY || '');

async function restore() {
    console.log('Restaurando boletos y participantes de la ruleta semanal...');

    const { data: settingsData, error } = await supabase
        .from('ff_settings')
        .select('*')
        .eq('id', 1)
        .single();

    if (error) {
        console.error('Error leyendo Supabase:', error.message);
        return;
    }

    const juegos = settingsData.juegos || {};
    if (juegos.sorteo_semanal) {
        delete juegos.sorteo_semanal.lastResetTimestamp;
        delete juegos.sorteo_semanal.lastWinner;
    }

    const { error: updateErr } = await supabase
        .from('ff_settings')
        .update({ juegos })
        .eq('id', 1);

    if (updateErr) {
        console.error('Error actualizando Supabase:', updateErr.message);
    } else {
        console.log('✅ Boletos y participantes de la ruleta restaurados con éxito en Supabase!');
    }
}

restore();
