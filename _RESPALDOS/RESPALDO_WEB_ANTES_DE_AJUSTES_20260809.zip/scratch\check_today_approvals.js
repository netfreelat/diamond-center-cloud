const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Buscando todos los pedidos aprobados el día de hoy (11/07/2026)...");
    
    // Obtener pedidos del 11 de julio de 2026 en adelante
    const todayStr = '2026-07-11T00:00:00.000Z';
    
    const { data: orders, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('status', 'approved')
        .gte('time', todayStr)
        .order('time', { ascending: false });

    if (error) {
        console.error("Error obteniendo pedidos:", error.message);
        return;
    }

    console.log(`\nPedidos aprobados hoy: ${orders.length}`);

    for (const o of orders) {
        console.log(`-----------------------------------------------`);
        console.log(`Ref: ${o.ref} | Cliente: ${o.name} (ID: ${o.uid})`);
        console.log(`  Juego: ${o.juego} | Paquete: ${o.pack} | Precio: ${o.price}`);
        console.log(`  WhatsApp: ${o.wa}`);
        console.log(`  Fecha: ${new Date(o.time).toLocaleString("es-VE", { timeZone: "America/Caracas" })}`);
        console.log(`  login_uid: ${o.login_uid}`);
    }
}

run().catch(console.error);
