const SUPABASE_URL = 'https://gtvlraxlszucoglbnzen.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0dmxyYXhsc3p1Y29nbGJuemVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4Mzg3MTcsImV4cCI6MjA5MTQxNDcxN30.IfbOm2PzrJx_Ycui1GPOeS30_18x4h7W4aMzSzYkr_Y';

const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': 'Bearer ' + SUPABASE_KEY,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation'
};

const defaultPublicidades = [
    { imagen: "img/Geminianiversario.png", link: "" },
    { imagen: "img/11.png", link: "" },
    { imagen: "img/Gemini_Generated_Image_s5ynsos5ynsos5yn.png", link: "" }
];

async function fix() {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, { headers });
    const data = await res.json();
    if (!data || !data[0]) return;

    const row = data[0];
    const whatsapp_config = row.whatsapp_config || {};
    whatsapp_config.publicidades = defaultPublicidades;

    const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ whatsapp_config })
    });

    console.log("Status actualización banners:", patchRes.status);
    if (patchRes.status === 200 || patchRes.status === 204) {
        console.log("✅ Banners publicitarios restaurados con ÉXITO en Supabase.");
    }
}

fix().catch(console.error);
