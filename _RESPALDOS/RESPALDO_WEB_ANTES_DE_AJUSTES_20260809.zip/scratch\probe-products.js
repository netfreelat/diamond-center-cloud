const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function probeProducts() {
    console.log('[PROBE] 🚀 Probing product URLs on jadh.shop...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(30000);

    const urls = [
        'https://jadh.shop/producto/roblox',
        'https://jadh.shop/producto/roblox-auto',
        'https://jadh.shop/producto/roblox-directo',
        'https://jadh.shop/producto/roblox-global'
    ];

    try {
        // Login first
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2' })
        ]);

        for (const url of urls) {
            console.log(`[PROBE] Checking ${url}...`);
            const res = await page.goto(url, { waitUntil: 'networkidle2' }).catch(() => null);
            if (res) {
                const status = res.status();
                const title = await page.title();
                console.log(`[PROBE] Result: Status ${status} | Title: "${title}"`);
                if (status === 200 && !title.toLowerCase().includes('página no encontrada')) {
                    // Log package options if select exists
                    const opts = await page.evaluate(() => {
                        const sel = document.querySelector('#packageSelect');
                        if (!sel) return null;
                        return Array.from(sel.options).map(o => o.text.trim());
                    });
                    if (opts) {
                        console.log(`[PROBE] Found packages:`, opts);
                    }
                }
            }
        }

    } catch (e) {
        console.error('[PROBE] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[PROBE] 🏁 Probing finished.');
    }
}

probeProducts();
