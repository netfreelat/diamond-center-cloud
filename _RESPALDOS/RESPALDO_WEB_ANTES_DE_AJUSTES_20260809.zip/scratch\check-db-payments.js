const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    console.log('--- BUSCANDO PAGOS RECIBIDOS ---');
    const { data: data1, error: error1 } = await supabase
        .from('ff_pagos_recibidos')
        .select('*')
        .order('date', { ascending: false })
        .limit(30);

    if (error1) {
        console.error('Error fetching payments:', error1);
        return;
    }

    console.log('Recent payments received in Supabase:');
    console.log(JSON.stringify(data1, null, 2));

    console.log('\n--- BUSCANDO PEDIDO ---');
    const { data: data2, error: error2 } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('uid', '14053419441');

    if (error2) {
        console.error('Error fetching orders:', error2);
        return;
    }

    console.log('Orders for UID 14053419441:');
    console.log(JSON.stringify(data2, null, 2));
}

run();
