function testLunes(dayStr) {
    const d = new Date(dayStr + 'T12:00:00Z');
    
    // Simulating getCaracasDateParts
    const year = d.getUTCFullYear();
    const month = d.getUTCMonth();
    const day = d.getUTCDate();

    const startOfToday = new Date(Date.UTC(year, month, day, 4, 0, 0, 0));
    
    const dayOfWeek = new Date(Date.UTC(year, month, day)).getUTCDay();
    const daysToSubtract = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setUTCDate(startOfWeek.getUTCDate() - daysToSubtract);

    console.log(`Input: ${dayStr} (Day of week: ${dayOfWeek}) -> Monday start: ${startOfWeek.toISOString()}`);
}

testLunes('2026-06-28'); // Sunday
testLunes('2026-06-29'); // Monday
testLunes('2026-06-30'); // Tuesday
testLunes('2026-07-04'); // Saturday
