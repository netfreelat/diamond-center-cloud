const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Analizando pedidos de usuarios referidos aprobados...");
    
    // Obtener usuarios referidos con recompensa cobrada
    const { data: users } = await supabase
        .from('ff_users')
        .select('uid, name')
        .eq('referral_claimed', true);

    if (!users || users.length === 0) {
        console.log("No hay usuarios referidos con compras completadas.");
        return;
    }

    const uids = users.map(u => u.uid);

    // Obtener pedidos de estos usuarios
    const { data: orders, error: ordersErr } = await supabase
        .from('ff_orders')
        .select('*')
        .in('uid', uids)
        .eq('status', 'approved')
        .order('time', { ascending: true });

    if (ordersErr) {
        console.error("Error obteniendo pedidos:", ordersErr.message);
        return;
    }

    console.log(`\nPedidos aprobados encontrados: ${orders.length}`);
    
    for (const o of orders) {
        console.log(`-----------------------------------------------`);
        console.log(`Pedido Ref: ${o.ref} | Cliente: ${o.name} (ID: ${o.uid})`);
        console.log(`  Juego: ${o.juego} | Paquete: ${o.pack}`);
        console.log(`  Precio Registrado: ${o.price}`);
        console.log(`  Fecha: ${o.time}`);
    }
}

run().catch(console.error);
