const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

const { createClient } = require('@supabase/supabase-js');
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
    console.log('--- RECENT PENDING / REJECTED / APPROVED ORDERS ---');
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .order('time', { ascending: false })
        .limit(15);
    
    if (error) {
        console.error('Error fetching orders:', error.message);
        return;
    }

    data.forEach(o => {
        console.log(`[${o.status.toUpperCase()}] ID: ${o.id} | Ref: ${o.ref} | Pack: ${o.pack} | Price: ${o.price} | Method: ${o.method} | Time: ${o.time} | User: ${o.name} (${o.uid}) | Reason: ${o.reason || 'N/A'}`);
    });
}

main();
