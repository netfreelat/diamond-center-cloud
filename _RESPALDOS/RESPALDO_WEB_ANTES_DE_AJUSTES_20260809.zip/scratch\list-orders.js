const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function list() {
    const { data, error } = await supabase
        .from('ff_orders')
        .select('ref, status, time, pin, pack, uid, method')
        .eq('status', 'pending');

    if (error) {
        console.error(error);
    } else {
        console.log('--- ALL PENDING ORDERS IN SUPABASE ---');
        console.log(data);
    }
}

list();
