const homeText = `Mi ID:
00253
Saldo:
5.55 $
Historial de transacciones
Freefire Auto
Monto total:
0.84$
Orden:
#192892
Fecha:
2026-05-31 • 06:53 PM
Nickname:
Sneyder2107
ID de Jugador:
2937558386
Artículos (1)
110 💎:
Copiar
Freefire Auto
Monto total:
0.84$
Orden:
#192891
Fecha:
2026-05-31 • 06:50 PM
Nickname:
Sneyder2107
ID de Jugador:
2937558386
Artículos (1)
110 💎:`;

function parseTransactions(text, playerID) {
    const lines = text.split('\n');
    const transactions = [];
    let current = null;
    
    const getValue = (lines, index, prefix) => {
        const line = lines[index].trim();
        let val = line.substring(prefix.length).trim();
        if (!val && index + 1 < lines.length) {
            val = lines[index + 1].trim();
        }
        return val;
    };

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line === 'Freefire Auto') {
            if (current) transactions.push(current);
            current = { type: 'Freefire Auto' };
        } else if (current) {
            if (line.startsWith('Monto total:')) {
                current.amount = getValue(lines, i, 'Monto total:');
            } else if (line.startsWith('Orden:')) {
                current.orderId = getValue(lines, i, 'Orden:');
            } else if (line.startsWith('Fecha:')) {
                current.date = getValue(lines, i, 'Fecha:');
            } else if (line.startsWith('Nickname:')) {
                current.nickname = getValue(lines, i, 'Nickname:');
            } else if (line.startsWith('ID de Jugador:')) {
                current.uid = getValue(lines, i, 'ID de Jugador:');
                transactions.push(current);
                current = null;
            }
        }
    }
    if (current) transactions.push(current);

    const match = transactions.find(t => t.uid === playerID);
    return { match, all: transactions };
}

console.log('Test with Sneyder2107 ID (2937558386):');
console.log(JSON.stringify(parseTransactions(homeText, '2937558386'), null, 2));

console.log('\nTest with nonexistent ID (12345):');
console.log(JSON.stringify(parseTransactions(homeText, '12345'), null, 2));
