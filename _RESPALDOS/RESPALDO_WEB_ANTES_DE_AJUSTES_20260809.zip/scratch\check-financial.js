require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
    const { data: allOrders, error } = await supabase
        .from('ff_orders')
        .select('ref, control_num, uid, pack, method, price, status, time')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    if (error) {
        console.error('Error:', error);
        return;
    }

    console.log(`Total approved orders in DB: ${allOrders.length}`);
    console.log('Last 10 approved orders:');
    allOrders.slice(0, 10).forEach(o => {
        console.log(`- Ref: ${o.ref}, Time: ${o.time}, Pack: ${o.pack}, Method: ${o.method}, Price: ${o.price}`);
    });

    const nowVE = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Caracas' }));
    console.log('\nnowVE:', nowVE.toString(), 'ISO:', nowVE.toISOString());

    const startOfToday = new Date(nowVE);
    startOfToday.setHours(0, 0, 0, 0);
    console.log('startOfToday:', startOfToday.toString(), 'ISO:', startOfToday.toISOString());

    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfToday.getDate() - startOfToday.getDay());

    const startOfMonth = new Date(nowVE.getFullYear(), nowVE.getMonth(), 1);

    let countToday = 0;
    allOrders.forEach(o => {
        const t = new Date(o.time);
        if (t >= startOfToday) {
            countToday++;
            console.log(`[TODAY MATCH] Ref: ${o.ref}, Time: ${o.time}, Parsed: ${t.toISOString()}`);
        }
    });
    console.log(`Count Today with current logic: ${countToday}`);
}

check();
