const puppeteer = require('puppeteer-core');
const path = require('path');
require('dotenv').config();

(async () => {
    try {
        const browser = await puppeteer.launch({ 
            executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
        });
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(60000);
        
        const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
        const password = process.env.JADH_PASSWORD || 'Clifor1988';

        console.log("Navigating to login page...");
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        
        console.log("Entering credentials...");
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        
        console.log("Submitting login...");
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);
        
        console.log("Navigating to Roblox USA product page...");
        await page.goto('https://jadh.shop/producto/roblox-usa', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#packageSelect', { timeout: 15000 });

        console.log("--- TEST 1: Setting select value without dispatching change event ---");
        await page.evaluate(() => {
            const select = document.querySelector('#packageSelect');
            const options = Array.from(select.querySelectorAll('option'));
            const targetOption = options.find(o => o.textContent.toLowerCase().includes('10'));
            if (targetOption) {
                select.value = targetOption.value;
            }
        });
        await new Promise(r => setTimeout(r, 2000));
        let totalText = await page.evaluate(() => {
            const totalEl = document.querySelector('span#total, .total, div[class*="total"]');
            return totalEl ? totalEl.innerText.trim() : document.body.innerText.match(/total:\s*\d+(\.\d+)?\$/i)?.[0] || 'Not found';
        });
        console.log("Total price (no event):", totalText);
        
        // Take a screenshot
        await page.screenshot({ path: 'scratch/test_no_event.png' });

        console.log("--- TEST 2: Dispatching change event manually ---");
        await page.evaluate(() => {
            const select = document.querySelector('#packageSelect');
            select.dispatchEvent(new Event('change', { bubbles: true }));
        });
        await new Promise(r => setTimeout(r, 2000));
        totalText = await page.evaluate(() => {
            const totalEl = document.querySelector('span#total, .total, div[class*="total"]');
            return totalEl ? totalEl.innerText.trim() : document.body.innerText.match(/total:\s*\d+(\.\d+)?\$/i)?.[0] || 'Not found';
        });
        console.log("Total price (with event):", totalText);
        
        // Take a screenshot
        await page.screenshot({ path: 'scratch/test_with_event.png' });

        await browser.close();
    } catch (e) {
        console.error(e);
    }
})();
