const fs = require('fs');
const content = fs.readFileSync('server.js', 'utf8');
const lines = content.split('\n');
lines.forEach((line, index) => {
    if (line.includes('pathname === \'/api/admin/login\'') || line.includes('pathname === \'/admin/aprobar\'')) {
        console.log(`Line ${index + 1}: ${line}`);
    }
    if (line.includes('ADMIN_PASS') || line.includes('admin_password')) {
        console.log(`Line ${index + 1}: ${line}`);
    }
});
