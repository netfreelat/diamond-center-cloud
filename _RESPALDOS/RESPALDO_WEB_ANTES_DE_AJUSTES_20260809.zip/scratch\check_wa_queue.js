const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Consultando la cola de WhatsApp en Supabase (ff_wa_queue)...");
    
    const { data: queue, error } = await supabase
        .from('ff_wa_queue')
        .select('*');

    if (error) {
        console.error("Error obteniendo la cola:", error.message);
        return;
    }

    console.log(`\nHay ${queue.length} mensajes en la cola actualmente.`);

    const now = Date.now();
    console.log(`Hora actual del servidor (timestamp): ${now} (${new Date().toLocaleString("es-VE", { timeZone: "America/Caracas" })})`);

    for (const item of queue) {
        console.log(`-----------------------------------------------`);
        console.log(`ID: ${item.id}`);
        console.log(`Destinatario: ${item.number}`);
        console.log(`Mensaje (resumen): ${item.message.split('\n')[0]}`);
        console.log(`¿Enviado?: ${item.sent}`);
        console.log(`Delay: ${item.delay}`);
        console.log(`Creado el: ${item.created_at}`);

        if (item.id.includes('_sendAfter_')) {
            const parts = item.id.split('_sendAfter_');
            const sendAfterTime = parseInt(parts[parts.length - 1]);
            const diffMin = ((sendAfterTime - now) / 60000).toFixed(1);
            console.log(`⏰ Tiempo de Envío Programado: ${sendAfterTime} (${new Date(sendAfterTime).toLocaleString("es-VE", { timeZone: "America/Caracas" })})`);
            if (diffMin > 0) {
                console.log(`⏳ Faltan ${diffMin} minutos para que sea elegible para envío.`);
            } else {
                console.log(`✅ Ya es elegible para envío (hace ${Math.abs(diffMin)} minutos).`);
            }
        } else {
            console.log(`⚡ Elegible para envío inmediato.`);
        }
    }
}

run().catch(console.error);
