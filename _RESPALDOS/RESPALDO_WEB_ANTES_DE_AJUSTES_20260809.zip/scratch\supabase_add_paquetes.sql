-- Script para actualizar los precios en Supabase con los 4 nuevos paquetes especiales
-- Ejecutar en el SQL Editor de Supabase

-- Ver configuración actual
SELECT id, precios FROM ff_settings WHERE id = 1;

-- Actualizar precios añadiendo los paquetes especiales
UPDATE ff_settings
SET precios = precios || '{
  "basica":  {"usdt": 0.75,  "label": "🃏 Tarjeta Básica"},
  "semanal": {"usdt": 2.80,  "label": "📅 Tarjeta Semanal"},
  "mensual": {"usdt": 13.50, "label": "👑 Tarjeta Mensual"},
  "booyah":  {"usdt": 4.20,  "label": "🏆 Pase Booyah"}
}'::jsonb
WHERE id = 1;

-- Verificar resultado
SELECT id, precios FROM ff_settings WHERE id = 1;
