const fs = require('fs');
const path = require('path');

const logPath = path.join('C:', 'Users', 'juanm', '.gemini', 'antigravity-ide', 'brain', '4a75cbcd-1f38-447c-a521-921fa5db35f6', '.system_generated', 'tasks', 'task-472.log');

if (!fs.existsSync(logPath)) {
    console.error('❌ El archivo de log no existe en:', logPath);
    process.exit(1);
}

const content = fs.readFileSync(logPath, 'utf8');
const lowerContent = content.toLowerCase();

console.log('--- BUSCANDO PALABRAS CLAVE EN EL LOG ---');
const words = ['reembolsado', 'encontrado', 'saldo', 'incorrecto', 'fail', 'fallido'];

words.forEach(w => {
    const count = (lowerContent.split(w).length - 1);
    console.log(`- '${w}': ${count} ocurrencias`);
});

console.log('\n--- EXTRACTO ALREDEDOR DE "fallido" ---');
let index = -1;
let occurrences = 0;
while ((index = lowerContent.indexOf('fallido', index + 1)) !== -1) {
    occurrences++;
    if (occurrences <= 3) {
        console.log(`\n--- Ocurrencia #${occurrences} (Char ${index}) ---`);
        console.log(content.substring(index - 100, index + 300));
    }
}
