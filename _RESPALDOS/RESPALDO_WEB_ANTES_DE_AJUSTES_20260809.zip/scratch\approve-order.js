const https = require('https');
require('dotenv').config();

const ref = '006675887569, 006675892039';
const secret = process.env.ADMIN_PASS || 'Clifor1988**.';

const payload = JSON.stringify({ ref });

const options = {
    hostname: 'recargasney.com',
    port: 443,
    path: '/admin/aprobar',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'x-wa-secret': secret
    }
};

console.log(`Enviando aprobación para la referencia: ${ref}`);
console.log(`Usando x-wa-secret: ${secret}`);

const req = https.request(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`Código de respuesta: ${res.statusCode}`);
        console.log(`Respuesta del servidor: ${body}`);
    });
});

req.on('error', (e) => {
    console.error(`Error en la petición: ${e.message}`);
});

req.write(payload);
req.end();
