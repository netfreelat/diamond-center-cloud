const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function testRanges() {
    const { data: allOrders, error } = await supabase
        .from('ff_orders')
        .select('time, pack, method, price, status')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    if (error) throw error;

    const tasa = 655;

    function getCaracasDateParts(date = new Date()) {
        const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/Caracas',
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: false
        });
        const parts = formatter.formatToParts(date);
        const map = {};
        parts.forEach(p => map[p.type] = p.value);
        return {
            year: parseInt(map.year),
            month: parseInt(map.month) - 1,
            day: parseInt(map.day)
        };
    }

    const now = new Date();
    const partsVE = getCaracasDateParts(now);

    const startOfToday = new Date(Date.UTC(partsVE.year, partsVE.month, partsVE.day, 4, 0, 0, 0));
    const startOfYesterday = new Date(startOfToday);
    startOfYesterday.setUTCDate(startOfYesterday.getUTCDate() - 1);
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setUTCDate(startOfWeek.getUTCDate() - 7);
    const startOfMonth = new Date(Date.UTC(partsVE.year, partsVE.month, 1, 4, 0, 0, 0));

    const JADH_COSTS = {
        '100':  0.81,
        '310':  2.59,
        '520':  3.76,
        '1060': 6.99,
        '2180': 13.88,
        '5600': 35.32
    };

    function calcPeriod(orders, from, to = null) {
        let revenueUsdt = 0;
        let revenueBs   = 0;
        let costUsdt    = 0;
        let countPM     = 0;
        let countBin    = 0;
        let totalOrders = 0;

        for (const o of orders) {
            const t = new Date(o.time);
            if (t < from) continue;
            if (to && t >= to) continue;

            totalOrders++;
            const priceStr = (o.price || '').toString().trim();
            let saleUsdt = 0;
            let saleBs   = 0;
            if (priceStr.includes('/')) {
                const parts = priceStr.split('/');
                saleUsdt = parseFloat(parts[0].replace(/usdt/i, '').trim()) || 0;
                saleBs   = parseFloat(parts[1].replace(/bs/i, '').trim()) || 0;
            } else if (priceStr.toUpperCase().includes('USDT')) {
                saleUsdt = parseFloat(priceStr.replace(/usdt/i, '').trim()) || 0;
                saleBs   = saleUsdt * tasa;
            }

            if (o.method === 'binance') {
                countBin++;
            } else {
                countPM++;
            }

            revenueUsdt += saleUsdt;
            revenueBs   += saleBs;

            const packKey = (o.pack || '').toString().split(' ')[0].replace(',','').trim();
            costUsdt += JADH_COSTS[packKey] || 0;
        }

        return { totalOrders, revenueUsdt, countPM, countBin };
    }

    console.log('Today:', calcPeriod(allOrders, startOfToday));
    console.log('Yesterday:', calcPeriod(allOrders, startOfYesterday, startOfToday));
    console.log('Week:', calcPeriod(allOrders, startOfWeek));
    console.log('Month:', calcPeriod(allOrders, startOfMonth));
}

testRanges();
