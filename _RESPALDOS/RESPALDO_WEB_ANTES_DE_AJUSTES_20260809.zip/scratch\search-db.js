const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function search() {
    const { data: ordersData, error: ordersError } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('pin', 'C49C2C85-311C-453B-8504-16F594E1F3E4');

    const { data: pinesData, error: pinesError } = await supabase
        .from('ff_pines')
        .select('*')
        .eq('code', 'C49C2C85-311C-453B-8504-16F594E1F3E4');

    console.log('Orders matching pin:', ordersData);
    console.log('Pines matching code:', pinesData);
}

search();
