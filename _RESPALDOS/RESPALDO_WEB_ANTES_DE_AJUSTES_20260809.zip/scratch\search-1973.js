const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    const { data: orders, error: oErr } = await supabase
        .from('ff_orders')
        .select('*')
        .ilike('ref', '%1973%');

    const { data: payments, error: pErr } = await supabase
        .from('ff_pagos_recibidos')
        .select('*')
        .ilike('ref', '%1973%');

    console.log('Orders found:', orders);
    console.log('Payments found:', payments);
}

run();
