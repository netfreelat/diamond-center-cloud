const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Faltan variables de Supabase.');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('ref', 'TESTLIVE01')
        .single();

    if (error) {
        console.error('Error al consultar la orden:', error.message);
    } else {
        console.log('--- DETALLES DE LA ORDEN TESTLIVE01 ---');
        console.log(JSON.stringify(data, null, 2));
    }
}

check();
