require('dotenv').config();
const crypto = require('crypto');
const https = require('https');

const API_KEY    = process.env.BINANCE_API_KEY;
const API_SECRET = process.env.BINANCE_API_SECRET;

function req(path) {
    return new Promise((resolve) => {
        const ts = Date.now();
        const qs = `timestamp=${ts}&recvWindow=10000`;
        const sig = crypto.createHmac('sha256', API_SECRET).update(qs).digest('hex');
        const opts = {
            hostname: 'api.binance.com',
            path: `${path}?${qs}&signature=${sig}`,
            headers: { 'X-MBX-APIKEY': API_KEY },
            timeout: 10000
        };
        https.get(opts, (res) => {
            let b = '';
            res.on('data', c => b += c);
            res.on('end', () => {
                try {
                    const d = JSON.parse(b);
                    console.log(`\n[${path}] HTTP=${res.statusCode} code=${d.code || d.status} msg=${d.msg || d.message || (Array.isArray(d) ? 'array:'+d.length : 'ok')}`);
                } catch(e) {
                    console.log(`[${path}] Parse error: ${b.substring(0,100)}`);
                }
                resolve();
            });
        }).on('error', e => { console.log(`[${path}] Error: ${e.message}`); resolve(); });
    });
}

(async () => {
    console.log('Probando todos los endpoints posibles...\n');
    
    // Endpoints de lectura comunes
    await req('/api/v3/account');              // cuenta spot
    await req('/sapi/v1/pay/transactions');    // pay history
    await req('/sapi/v1/asset/transfer');      // transferencias internas
    await req('/sapi/v1/capital/deposit/hisrec'); // historial depósitos
    await req('/sapi/v1/accountSnapshot');     // snapshot cuenta
    await req('/sapi/v1/asset/get-funding-asset'); // activos funding
    await req('/sapi/v2/asset/get-funding-asset'); // activos funding v2
    
    console.log('\nFin del diagnóstico.');
    console.log('Busca el endpoint que devuelva HTTP=200 y no code=-2008 ni -2015');
})();
