const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { createClient } = require('@supabase/supabase-js');
const WebSocket = require('ws');
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY, {
    auth: { persistSession: false },
    realtime: {
        transport: WebSocket
    }
});

async function run() {
    const { data: users, error } = await supabase.from('ff_users').select('*');
    if (error) {
        console.error('Error fetching users:', error.message);
        return;
    }
    console.log('Total registered users in Supabase:', users.length);
    let withPhone = 0;
    users.forEach(u => {
        if (u.phone && u.phone.trim() !== '') {
            withPhone++;
            console.log(`- UID: ${u.uid} | Name: ${u.name} | Phone: ${u.phone}`);
        }
    });
    console.log('Users with phone:', withPhone);
}

run();
