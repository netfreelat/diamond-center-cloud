const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const imgDir = path.join(__dirname, '..', 'img');
const rootDir = path.join(__dirname, '..');

async function run() {
    const browser = await puppeteer.launch({ headless: 'new' });
    const page = await browser.newPage();

    // Buscar imágenes en img/ y en el root
    const images = [];
    
    // Archivos del root
    const rootFiles = ['badge-diamond.png', 'fondo.jpg', 'reviews_banner.png'];
    for (const file of rootFiles) {
        const filePath = path.join(rootDir, file);
        if (fs.existsSync(filePath)) {
            images.push({ name: file, path: filePath, root: true });
        }
    }

    // Archivos de img/
    if (fs.existsSync(imgDir)) {
        const files = fs.readdirSync(imgDir);
        for (const file of files) {
            const filePath = path.join(imgDir, file);
            if (fs.statSync(filePath).isFile() && /\.(png|jpg|jpeg|gif)$/i.test(file)) {
                images.push({ name: 'img/' + file, path: filePath, root: false });
            }
        }
    }

    console.log(`Analizando ${images.length} imágenes...`);
    const results = [];

    for (const img of images) {
        const stats = fs.statSync(img.path);
        const sizeKB = (stats.size / 1024).toFixed(1);
        
        // Cargar imagen en la página para medir dimensiones
        const base64 = fs.readFileSync(img.path).toString('base64');
        const ext = path.extname(img.path).substring(1);
        const mime = ext.toLowerCase() === 'jpg' ? 'image/jpeg' : `image/${ext.toLowerCase()}`;
        const dataUrl = `data:${mime};base64,${base64}`;

        const dimensions = await page.evaluate(async (url) => {
            return new Promise((resolve) => {
                const i = new Image();
                i.onload = () => resolve({ w: i.width, h: i.height });
                i.onerror = () => resolve({ w: 0, h: 0 });
                i.src = url;
            });
        }, dataUrl);

        results.push({
            name: img.name,
            sizeKB: parseFloat(sizeKB),
            width: dimensions.w,
            height: dimensions.h
        });
    }

    results.sort((a, b) => b.sizeKB - a.sizeKB);
    console.table(results);

    await browser.close();
}

run().catch(console.error);
