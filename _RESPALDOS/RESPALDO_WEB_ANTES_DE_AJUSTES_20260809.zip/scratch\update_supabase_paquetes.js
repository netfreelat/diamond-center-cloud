/**
 * Script para actualizar los precios en Supabase con los 4 nuevos paquetes especiales
 */
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_KEY,
    { auth: { persistSession: false } }
);

const NUEVOS_PAQUETES = {
    "basica":  { "usdt": 0.75,  "label": "🃏 Tarjeta Básica" },
    "semanal": { "usdt": 2.80,  "label": "📅 Tarjeta Semanal" },
    "mensual": { "usdt": 13.50, "label": "👑 Tarjeta Mensual" },
    "booyah":  { "usdt": 4.20,  "label": "🏆 Pase Booyah" }
};

async function main() {
    console.log('📦 Conectando a Supabase...');
    
    // 1. Leer configuración actual
    const { data: current, error: readErr } = await supabase
        .from('ff_settings')
        .select('id, precios')
        .eq('id', 1)
        .single();
    
    if (readErr) {
        console.error('❌ Error leyendo settings:', readErr.message);
        process.exit(1);
    }
    
    console.log('✅ Configuración actual leída.');
    console.log('   Paquetes existentes:', Object.keys(current.precios || {}).join(', '));
    
    // 2. Verificar si ya existen los paquetes
    const preciosActuales = current.precios || {};
    const yaExisten = Object.keys(NUEVOS_PAQUETES).filter(k => preciosActuales[k]);
    if (yaExisten.length > 0) {
        console.log(`⚠️  Los siguientes paquetes ya existen: ${yaExisten.join(', ')}`);
        console.log('   Se sobreescribirán con los valores actualizados.');
    }
    
    // 3. Mezclar paquetes existentes con los nuevos
    const preciosActualizados = { ...preciosActuales, ...NUEVOS_PAQUETES };
    
    console.log('\n🔄 Actualizando Supabase con los 4 nuevos paquetes especiales...');
    console.log('   Nuevos paquetes:', Object.keys(NUEVOS_PAQUETES).join(', '));
    
    // 4. Guardar en Supabase
    const { error: updateErr } = await supabase
        .from('ff_settings')
        .update({ precios: preciosActualizados })
        .eq('id', 1);
    
    if (updateErr) {
        console.error('❌ Error actualizando settings:', updateErr.message);
        process.exit(1);
    }
    
    // 5. Verificar resultado
    const { data: updated } = await supabase
        .from('ff_settings')
        .select('precios')
        .eq('id', 1)
        .single();
    
    console.log('\n✅ SUPABASE ACTUALIZADO EXITOSAMENTE');
    console.log('   Total de paquetes en Supabase:', Object.keys(updated.precios || {}).length);
    console.log('   Paquetes actuales:', Object.keys(updated.precios || {}).join(', '));
    
    // Mostrar detalles de los nuevos paquetes
    console.log('\n📋 Detalles de los nuevos paquetes especiales:');
    Object.entries(NUEVOS_PAQUETES).forEach(([key, val]) => {
        console.log(`   ${val.label}  →  ${val.usdt} USDT`);
    });
}

main().catch(console.error);
