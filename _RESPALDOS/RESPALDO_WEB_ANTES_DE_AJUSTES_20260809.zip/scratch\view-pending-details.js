const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('status', 'pending');

    if (error) {
        console.error('Error fetching pending orders:', error);
        return;
    }

    console.log('Pending orders details:', JSON.stringify(data, null, 2));
}

run();
