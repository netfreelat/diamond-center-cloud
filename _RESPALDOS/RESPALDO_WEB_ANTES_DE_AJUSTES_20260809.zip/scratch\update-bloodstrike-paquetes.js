/**
 * Actualiza los paquetes de Blood Strike en Supabase (ff_settings.juegos)
 * con los 6 paquetes reales obtenidos de jadh.shop
 */
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function main() {
    console.log('📡 Conectando a Supabase...');

    // 1. Leer el campo juegos actual
    const { data, error } = await supabase
        .from('ff_settings')
        .select('juegos')
        .eq('id', 1)
        .single();

    if (error) {
        console.error('❌ Error leyendo ff_settings:', error.message);
        process.exit(1);
    }

    const juegos = data.juegos || {};
    console.log('\n📋 Juegos actuales en Supabase:');
    Object.entries(juegos).forEach(([k, v]) => {
        const packs = Object.keys(v.paquetes || {});
        console.log(`   ${k}: ${packs.length} paquetes → [${packs.join(', ')}]`);
    });

    // 2. Definir los 6 paquetes correctos de Blood Strike
    const bloodstrikePaquetes = {
        "100":  { "usdt": 0.73,  "label": "100 + 5 🪙 Monedas" },
        "300":  { "usdt": 2.24,  "label": "300 + 20 🪙 Monedas" },
        "500":  { "usdt": 3.66,  "label": "500 + 40 🪙 Monedas" },
        "1000": { "usdt": 7.44,  "label": "1.000 + 100 🪙 Monedas" },
        "2000": { "usdt": 14.59, "label": "2.000 + 260 🪙 Monedas" },
        "5000": { "usdt": 36.19, "label": "5.000 + 800 🪙 Monedas" }
    };

    // 3. Actualizar Blood Strike manteniendo el resto de juegos intacto
    juegos['bloodstrike'] = {
        ...(juegos['bloodstrike'] || {}),
        nombre: "Blood Strike",
        inputLabel: "ID de Jugador",
        inputPlaceholder: "Ej: 123456789",
        icono: "fa-skull-crossbones",
        paquetes: bloodstrikePaquetes
    };

    // 4. Guardar en Supabase
    const { error: updateError } = await supabase
        .from('ff_settings')
        .update({ juegos })
        .eq('id', 1);

    if (updateError) {
        console.error('❌ Error actualizando ff_settings:', updateError.message);
        process.exit(1);
    }

    console.log('\n✅ Blood Strike actualizado correctamente en Supabase:');
    Object.entries(bloodstrikePaquetes).forEach(([k, v]) => {
        console.log(`   ${k}: ${v.label} → $${v.usdt} USDT`);
    });
    console.log('\n🎮 Ya deberían aparecer los 6 paquetes en la tienda.');
}

main().catch(err => {
    console.error('Error inesperado:', err.message);
    process.exit(1);
});
