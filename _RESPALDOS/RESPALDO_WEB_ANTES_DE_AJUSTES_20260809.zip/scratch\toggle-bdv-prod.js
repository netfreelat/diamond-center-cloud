const https = require('https');

const data = JSON.stringify({ enabled: true });

const options = {
  hostname: 'recargasney.com',
  port: 443,
  path: '/admin/bdv-config',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-wa-secret': 'Clifor1988**.',
    'Content-Length': data.length
  }
};

const req = https.request(options, res => {
  console.log(`STATUS: ${res.statusCode}`);
  res.on('data', d => {
    process.stdout.write(d);
  });
});

req.on('error', error => {
  console.error(error);
});

req.write(data);
req.end();
