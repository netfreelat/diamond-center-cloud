const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function testDomParser() {
    console.log('[TEST-PARSER] 🚀 Iniciando prueba de parseo DOM...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(60000);

    try {
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        const parsedTransactions = await page.evaluate(() => {
            // Busquemos las tarjetas de transacciones.
            // Normalmente en Bootstrap/Jadh son elementos con clase "card" o similar que contienen "Monto total:"
            const cards = Array.from(document.querySelectorAll('.card, .transaction-card, div')).filter(el => {
                // Filtramos elementos que contengan "Monto total:" y "Orden:" de forma directa
                if (el.children.length === 0) return false;
                const text = el.innerText || '';
                return text.includes('Monto total:') && text.includes('Orden:');
            });

            // Encontrar el contenedor de nivel más bajo para cada tarjeta (para no duplicar padres/hijos)
            const uniqueCards = [];
            cards.forEach(card => {
                // Si ninguna tarjeta ya guardada contiene a esta, y esta no contiene a ninguna guardada (o preferimos la más pequeña/interna)
                const isParentOfExisting = uniqueCards.some(existing => card.contains(existing));
                const isChildOfExisting = uniqueCards.some(existing => existing.contains(card));
                
                if (isChildOfExisting) {
                    // Reemplazar la existente más grande por esta más pequeña/específica
                    const idx = uniqueCards.findIndex(existing => existing.contains(card));
                    if (idx !== -1) uniqueCards[idx] = card;
                } else if (!isParentOfExisting) {
                    uniqueCards.push(card);
                }
            });

            return uniqueCards.map(card => {
                const text = card.innerText || '';
                const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
                
                // Buscar PINs dentro de esta tarjeta
                const pinRows = Array.from(card.querySelectorAll('.pin-row'));
                const pins = pinRows.map(row => {
                    const labelEl = row.querySelector('.pin-label, label');
                    const inputEl = row.querySelector('.pin-input, input');
                    return {
                        label: labelEl ? labelEl.innerText.trim() : '',
                        pin: inputEl ? inputEl.value.trim() : ''
                    };
                });

                // Si no hay .pin-row, buscar cualquier input o botón con data-copy
                if (pins.length === 0) {
                    const inputs = Array.from(card.querySelectorAll('input.pin-input, input[readonly]'));
                    inputs.forEach(input => {
                        pins.push({
                            label: 'PIN',
                            pin: input.value.trim()
                        });
                    });
                }

                return {
                    text: text.substring(0, 300),
                    lines: lines.slice(0, 15),
                    pins
                };
            });
        });

        console.log(`Parsed ${parsedTransactions.length} transactions from DOM:`);
        parsedTransactions.slice(0, 3).forEach((t, idx) => {
            console.log(`\n--- Transaction #${idx + 1} ---`);
            console.log('Lines:', t.lines);
            console.log('PINs:', t.pins);
        });

    } catch (e) {
        console.error('[TEST-PARSER] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[TEST-PARSER] 🏁 Fin.');
    }
}

testDomParser();
