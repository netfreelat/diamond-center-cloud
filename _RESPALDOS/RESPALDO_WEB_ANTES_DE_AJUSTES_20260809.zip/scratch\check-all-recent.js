require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function inspect() {
    const { data: orders } = await supabase
        .from('ff_orders')
        .select('ref, control_num, uid, pack, method, price, status, time')
        .order('time', { ascending: false })
        .limit(20);

    console.log('Recent 20 orders:');
    orders.forEach(o => {
        console.log(`${o.time} | status: ${o.status} | ref: ${o.ref} | pack: ${o.pack} | price: ${o.price}`);
    });
}

inspect();
