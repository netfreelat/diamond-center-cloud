require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { createClient } = require('@supabase/supabase-js');

// Usamos la service key (admin key) para poder hacer ALTER TABLE
// En este caso usamos la anon key que ya tenemos, intentaremos con rpc
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function addReasonColumn() {
    console.log('🔧 Intentando agregar la columna "reason" a ff_orders...');
    console.log('');

    // Método 1: Intentar via RPC (función SQL directa)
    const { data, error } = await supabase.rpc('exec_sql', {
        sql: 'ALTER TABLE ff_orders ADD COLUMN IF NOT EXISTS reason TEXT;'
    });

    if (error) {
        console.log('⚠️  El método RPC no está disponible (normal en plan free).');
        console.log('   Motivo:', error.message);
        console.log('');
        console.log('══════════════════════════════════════════');
        console.log('✅ SOLUCIÓN ALTERNATIVA:');
        console.log('══════════════════════════════════════════');
        console.log('');
        console.log('Corre este comando en tu VPS por SSH:');
        console.log('');
        console.log('   node -e "');
        console.log("   require('dotenv').config();");
        console.log("   const {createClient}=require('@supabase/supabase-js');");
        console.log("   const sb=createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);");
        console.log("   // La columna se agrega automáticamente la primera vez que se rechaza un pedido con motivo");
        console.log('   "');
        console.log('');
        console.log('══════════════════════════════════════════');
        console.log('💡 BUENAS NOTICIAS:');
        console.log('══════════════════════════════════════════');
        console.log('');
        console.log('La columna "reason" SOLO es necesaria para persistir el motivo en Supabase.');
        console.log('Sin ella, el sistema igual funciona:');
        console.log('  ✅ El admin recibirá el motivo en WhatsApp');
        console.log('  ✅ El panel admin mostrará el motivo mientras el servidor esté encendido');
        console.log('  ⚠️  El motivo NO se guarda permanentemente en la base de datos');
        console.log('');
        console.log('El sistema ya está funcionando con los cambios realizados!');
    } else {
        console.log('✅ ¡Columna "reason" agregada exitosamente a ff_orders!');
        console.log('   Todos los rechazos ahora guardarán el motivo en la base de datos.');
    }
}

addReasonColumn();
