const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function check() {
    const { data, error } = await supabase
        .from('ff_settings')
        .select('precios, juegos')
        .eq('id', 1)
        .single();
    if (error) {
        console.error('Error fetching settings:', error);
    } else {
        console.log('--- PRECIOS ---');
        console.log(JSON.stringify(data.precios, null, 2));
        console.log('--- JUEGOS ---');
        console.log(JSON.stringify(data.juegos, null, 2));
    }
}

check();
