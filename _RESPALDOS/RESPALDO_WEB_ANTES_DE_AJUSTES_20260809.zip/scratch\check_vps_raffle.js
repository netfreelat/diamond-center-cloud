const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_KEY || '');

async function check() {
    console.log('=== DIAGNÓSTICO DE REFERIDOS Y SORTEO ===');
    const { data: usersData, error } = await supabase
        .from('ff_users')
        .select('uid, name, referred_by, registered')
        .not('referred_by', 'is', null);

    if (error) {
        console.error('Error consultando Supabase:', error.message);
        return;
    }

    console.log(`Total de usuarios vinculados con referred_by: ${usersData.length}`);

    const referrerCounts = {};
    usersData.forEach(u => {
        if (u.referred_by) {
            referrerCounts[u.referred_by] = (referrerCounts[u.referred_by] || 0) + 1;
        }
    });

    console.log('\n--- Conteo de Referidos por Referidor ---');
    console.log(referrerCounts);

    const participants = [];
    Object.entries(referrerCounts).forEach(([refUid, count]) => {
        const tickets = Math.floor(count / 2);
        participants.push({ refUid, count, tickets });
    });

    console.log('\n--- Participantes Elegibles (1 ticket cada 2 referidos) ---');
    console.table(participants);

    process.exit(0);
}

check();
