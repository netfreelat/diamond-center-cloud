const puppeteer = require('puppeteer');
require('dotenv').config();

async function run() {
    console.log('🚀 Iniciando simulación de ID incorrecto con espera larga...');
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    try {
        console.log('🔑 Iniciando sesión...');
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com');
        await page.type('#login-password', process.env.JADH_PASSWORD || 'Clifor1988');
        
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        console.log('📡 Navegando a Blood Strike...');
        await page.goto('https://jadh.shop/producto/bloodstrike', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 2000));

        console.log('📝 Seleccionando paquete 100🪙 (ID 162)...');
        await page.waitForSelector('#packageSelect', { timeout: 15000 });
        await page.select('#packageSelect', '162');

        console.log('📝 Ingresando ID incorrecto (12345)...');
        const inputSelector = await page.evaluate(() => {
            const newEl = document.querySelector('#gameAccountId');
            if (newEl) return '#gameAccountId';
            const legacyEl = document.querySelector('input[name^="gp_"]');
            return legacyEl ? (legacyEl.id ? '#' + legacyEl.id : 'input[name="' + legacyEl.name + '"]') : null;
        });
        await page.type(inputSelector, '12345');

        console.log('💎 Haciendo clic en Recargar...');
        await page.click('#btnPurchase');

        console.log('⏳ Esperando 25 segundos para procesamiento completo...');
        await new Promise(r => setTimeout(r, 25000));

        console.log('📸 Tomando captura del resultado final...');
        await page.screenshot({ path: 'bad_id_final_result.png', fullPage: true });

        const url = page.url();
        const pageText = await page.evaluate(() => document.body.innerText);

        console.log('\n--- DIAGNÓSTICO FINAL ---');
        console.log('URL actual:', url);
        console.log('Texto completo de la página:');
        console.log(pageText);
        console.log('-------------------------\n');

    } catch (e) {
        console.error('❌ Error durante la simulación:', e);
    } finally {
        await browser.close();
    }
}

run();
