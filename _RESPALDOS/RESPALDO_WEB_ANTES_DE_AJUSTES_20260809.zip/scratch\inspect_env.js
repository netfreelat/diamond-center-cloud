const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
console.log('ADMIN_PASS from dotenv:', process.env.ADMIN_PASS);
