const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    console.log('--- BUSCANDO PAGOS ESPECÍFICOS ---');
    
    // Buscar todos los pagos recibidos hoy
    const { data: data1, error: error1 } = await supabase
        .from('ff_pagos_recibidos')
        .select('*')
        .order('date', { ascending: false })
        .limit(50);

    if (error1) {
        console.error('Error fetching payments:', error1);
        return;
    }

    console.log('Payments list:');
    data1.forEach(p => {
        console.log(`Ref: ${p.ref} | Amount: ${p.amount} | Date: ${p.date} | Used: ${p.used}`);
    });
}

run();
