const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

async function run() {
    console.log('🚀 Iniciando script de prueba para jadh.shop (Paso 2)...');
    const browser = await puppeteer.launch({
        headless: true,
        executablePath: puppeteer.executablePath(),
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    try {
        console.log('🌐 Navegando a https://jadh.shop/ ...');
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        
        console.log('🔑 Completando login...');
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', 'jmnetfreelat@gmail.com');
        await page.type('#login-password', 'Clifor1988');
        
        console.log('Click en botón Iniciar Sesión...');
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        console.log('✅ Login completado. Obteniendo texto de la página de inicio...');
        const homeText = await page.evaluate(() => document.body.innerText);
        console.log('\n--- TEXTO DE LA PÁGINA DE INICIO (HISTORIAL) ---');
        console.log(homeText.substring(0, 3000));
        console.log('------------------------------------------------\n');

        console.log('Navegando al producto Freefire Auto...');
        await page.goto('https://jadh.shop/producto/freefire-auto', { waitUntil: 'networkidle2' });
        
        console.log('URL actual:', page.url());

        // Tomar una captura de pantalla de la página del producto
        const screenshotPath = path.join(__dirname, 'freefire-auto.png');
        await page.screenshot({ path: screenshotPath, fullPage: true });
        console.log(`📸 Captura de pantalla guardada en: ${screenshotPath}`);

        // Extraer la estructura HTML relevante de la compra
        const formDetails = await page.evaluate(() => {
            const form = document.querySelector('form');
            if (!form) return { error: 'No se encontró formulario en la página' };

            const inputs = Array.from(form.querySelectorAll('input, select, textarea')).map(el => ({
                tag: el.tagName.toLowerCase(),
                type: el.type || null,
                name: el.name || null,
                id: el.id || null,
                placeholder: el.placeholder || null,
                value: el.value || null,
                options: el.tagName.toLowerCase() === 'select' ? 
                    Array.from(el.options).map(o => ({ value: o.value, text: o.text })) : null
            }));

            const buttons = Array.from(form.querySelectorAll('button')).map(b => ({
                text: b.innerText.trim(),
                type: b.type || null,
                id: b.id || null
            }));

            return {
                action: form.action,
                method: form.method,
                inputs,
                buttons,
                text: document.body.innerText.substring(0, 1500)
            };
        });

        console.log('\n--- DETALLES DEL FORMULARIO DE COMPRA ---');
        console.log(JSON.stringify(formDetails, null, 2));
        console.log('----------------------------------------\n');
        
    } catch (error) {
        console.error('❌ Ocurrió un error en el script:', error);
    } finally {
        await browser.close();
        console.log('🌐 Navegador cerrado.');
    }
}

run();
