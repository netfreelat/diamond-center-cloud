require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    const { data: allOrders, error } = await supabase
        .from('ff_orders')
        .select('ref, time, status')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    if (error) {
        console.error(error);
        return;
    }

    function getCaracasDateParts(date = new Date()) {
        const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/Caracas',
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: false
        });
        const parts = formatter.formatToParts(date);
        const map = {};
        parts.forEach(p => map[p.type] = p.value);
        return {
            year: parseInt(map.year),
            month: parseInt(map.month) - 1,
            day: parseInt(map.day)
        };
    }

    const now = new Date();
    const partsVE = getCaracasDateParts(now);

    const startOfToday = new Date(Date.UTC(partsVE.year, partsVE.month, partsVE.day, 4, 0, 0, 0));

    // startOfYesterday
    const startOfYesterday = new Date(startOfToday);
    startOfYesterday.setUTCDate(startOfYesterday.getUTCDate() - 1);

    // startOfWeek
    const dayOfWeek = new Date(Date.UTC(partsVE.year, partsVE.month, partsVE.day)).getUTCDay();
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setUTCDate(startOfWeek.getUTCDate() - dayOfWeek);

    // startOfMonth
    const startOfMonth = new Date(Date.UTC(partsVE.year, partsVE.month, 1, 4, 0, 0, 0));

    function count(from, to = null) {
        let cnt = 0;
        for (const o of allOrders) {
            const t = new Date(o.time);
            if (t < from) continue;
            if (to && t >= to) continue;
            cnt++;
        }
        return cnt;
    }

    console.log('Now:', now.toISOString());
    console.log('Today (from):', startOfToday.toISOString(), 'Count:', count(startOfToday));
    console.log('Yesterday (from, to):', startOfYesterday.toISOString(), 'to', startOfToday.toISOString(), 'Count:', count(startOfYesterday, startOfToday));
    console.log('Week (from):', startOfWeek.toISOString(), 'Count:', count(startOfWeek));
    console.log('Month (from):', startOfMonth.toISOString(), 'Count:', count(startOfMonth));
}

run();
