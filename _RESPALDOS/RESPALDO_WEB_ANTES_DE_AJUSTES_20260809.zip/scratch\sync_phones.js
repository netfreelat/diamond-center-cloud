const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error("Error: SUPABASE_URL y SUPABASE_KEY son requeridos en el archivo .env.");
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
    auth: { persistSession: false }
});

async function run() {
    console.log("Cargando usuarios y pedidos desde Supabase...");
    
    // Obtener todos los usuarios
    const { data: users, error: usersErr } = await supabase.from('ff_users').select('*');
    if (usersErr) {
        console.error('Error al obtener usuarios:', usersErr.message);
        return;
    }

    console.log(`Total usuarios: ${users.length}`);

    // Obtener todos los pedidos con número de WA válido
    const { data: orders, error: ordersErr } = await supabase
        .from('ff_orders')
        .select('uid, login_uid, wa, time')
        .not('wa', 'is', null)
        .neq('wa', '')
        .neq('wa', 'No provisto')
        .order('time', { ascending: false });

    if (ordersErr) {
        console.error('Error al obtener pedidos:', ordersErr.message);
        return;
    }

    console.log(`Total pedidos con WhatsApp: ${orders.length}`);

    // Mapear los teléfonos más recientes por UID
    const phoneMap = {};
    orders.forEach(o => {
        const uid = o.login_uid || o.uid;
        if (uid && o.wa && !phoneMap[uid]) {
            phoneMap[uid] = o.wa.trim();
        }
    });

    let updatedCount = 0;

    for (const user of users) {
        const currentPhone = (user.phone || '').trim();
        
        // Si no tiene teléfono en el perfil, buscar en el mapa de pedidos
        if (currentPhone === '') {
            const foundPhone = phoneMap[user.uid];
            if (foundPhone) {
                console.log(`UID: ${user.uid} (${user.name}) -> Teléfono encontrado en pedidos: ${foundPhone}`);
                
                const { error: updateErr } = await supabase
                    .from('ff_users')
                    .update({ phone: foundPhone })
                    .eq('uid', user.uid);

                if (updateErr) {
                    console.error(`  ❌ Error actualizando teléfono para UID ${user.uid}:`, updateErr.message);
                } else {
                    console.log(`  ✅ Teléfono actualizado.`);
                    updatedCount++;
                }
            } else {
                console.log(`UID: ${user.uid} (${user.name}) -> Sin teléfono en perfil ni en pedidos.`);
            }
        }
    }

    console.log(`Proceso terminado. Se actualizaron los teléfonos de ${updatedCount} usuarios.`);
}

run();
