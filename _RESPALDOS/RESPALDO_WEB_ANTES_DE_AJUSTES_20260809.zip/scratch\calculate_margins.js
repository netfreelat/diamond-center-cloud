const prices = {
    // Free Fire
    "ff_100": { name: "FF 100+10 💎", sell: 0.86, cost: 0.79 },
    "ff_310": { name: "FF 310+31 💎", sell: 2.80, cost: 2.64 },
    "ff_520": { name: "FF 520+52 💎", sell: 4.15, cost: 3.69 },
    "ff_1060": { name: "FF 1060+106 💎", sell: 7.60, cost: 6.86 },
    "ff_2180": { name: "FF 2180+218 💎", sell: 14.60, cost: 13.63 },
    "ff_5600": { name: "FF 5600+560 💎", sell: 36.50, cost: 34.70 },
    "ff_basica": { name: "FF T. Básica 🃏", sell: 0.70, cost: 0.68 },
    "ff_semanal": { name: "FF T. Semanal 📅", sell: 2.85, cost: 2.66 },
    "ff_mensual": { name: "FF T. Mensual 👑", sell: 13.50, cost: 12.77 },
    "ff_booyah": { name: "FF Pase Booyah 🏆", sell: 4.40, cost: 4.08 },
    
    // Roblox
    "rob_10usd": { name: "Roblox 10 USD 🤖", sell: 9.99, cost: 9.63 },
    
    // Blood Strike
    "bs_100": { name: "BS 100+5 🪙", sell: 0.85, cost: 0.76 },
    "bs_300": { name: "BS 300+20 🪙", sell: 2.55, cost: 2.32 },
    "bs_500": { name: "BS 500+40 🪙", sell: 4.15, cost: 3.80 },
    "bs_1000": { name: "BS 1000+100 🪙", sell: 8.40, cost: 7.72 },
    "bs_2000": { name: "BS 2000+260 🪙", sell: 16.50, cost: 15.16 },
    "bs_5000": { name: "BS 5000+800 🪙", sell: 40.90, cost: 37.60 }
};

console.log("Calculando márgenes con precios NUEVOS y DEFINITIVOS...");
const results = [];

for (const key in prices) {
    const p = prices[key];
    const sellPrice = p.sell;
    const costPrice = p.cost;
    
    // Ganancia normal
    const normalProfit = sellPrice - costPrice;
    const normalMargin = (normalProfit / sellPrice) * 100;
    
    // Primera compra con referido (3% de descuento en el precio de venta)
    const discountedPrice = sellPrice * 0.97;
    const refProfitWithBonus = discountedPrice - costPrice - 0.05;
    const refMargin = (refProfitWithBonus / discountedPrice) * 100;
    
    results.push({
        Producto: p.name,
        'Venta ($)': sellPrice.toFixed(2),
        'Costo ($)': costPrice.toFixed(2),
        'Ganancia Normal ($)': normalProfit.toFixed(3),
        'Margen Normal (%)': normalMargin.toFixed(1) + '%',
        'Venta Desc. 3% ($)': discountedPrice.toFixed(2),
        'Ganancia 1ra Compra ($)': refProfitWithBonus.toFixed(3),
        'Margen 1ra Compra (%)': refMargin.toFixed(1) + '%'
    });
}

console.table(results);
