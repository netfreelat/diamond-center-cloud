require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Faltan SUPABASE_URL o SUPABASE_KEY en las variables de entorno.');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    try {
        const { data, error, count } = await supabase
            .from('ff_push_subscriptions')
            .select('*', { count: 'exact' });
        
        if (error) {
            console.error('Error al obtener suscripciones:', error.message);
            return;
        }

        console.log(`Total de suscripciones encontradas: ${count}`);
        if (data && data.length > 0) {
            console.log('Últimas 10 suscripciones registradas:');
            data.slice(-10).forEach(sub => {
                console.log(`ID: ${sub.id} | UID (Usuario/FF ID): ${sub.uid} | Endpoint: ${sub.endpoint ? sub.endpoint.slice(0, 50) + '...' : 'null'} | Creado: ${sub.created_at}`);
            });
        } else {
            console.log('No hay suscripciones en la tabla.');
        }
    } catch (e) {
        console.error('Error inesperado:', e.message);
    }
}

run();
