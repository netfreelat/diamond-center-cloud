const puppeteer = require('puppeteer');
const path = require('path');
require('dotenv').config();

async function checkDashboard() {
    let browser;
    try {
        const launchOptions = {
            headless: "new",
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        };
        if (process.platform === 'win32') {
            launchOptions.executablePath = path.join(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
        }

        browser = await puppeteer.launch(launchOptions);
        const page = await browser.newPage();
        
        console.log("Navigating to auth...");
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        
        const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
        const password = process.env.JADH_PASSWORD || 'Clifor1988';
        
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => {})
        ]);

        console.log("Navigating to dashboard...");
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(resolve => setTimeout(resolve, 5000));

        const html = await page.evaluate(() => document.body.innerHTML);
        const text = await page.evaluate(() => document.body.innerText);
        
        const fs = require('fs');
        fs.writeFileSync('dashboard_dump.html', html);
        fs.writeFileSync('dashboard_dump.txt', text);
        
        console.log("Dump saved to dashboard_dump.txt and dashboard_dump.html");

        const transactions = await page.evaluate(() => {
            const cards = Array.from(document.querySelectorAll('.card, .transaction-card, div')).filter(el => {
                if (el.children.length === 0) return false;
                const text = el.innerText || '';
                return text.includes('Monto total:') && text.includes('Orden:');
            });

            const uniqueCards = [];
            cards.forEach(card => {
                const isParentOfExisting = uniqueCards.some(existing => card.contains(existing));
                const isChildOfExisting = uniqueCards.some(existing => existing.contains(card));
                if (isChildOfExisting) {
                    const idx = uniqueCards.findIndex(existing => existing.contains(card));
                    if (idx !== -1) uniqueCards[idx] = card;
                } else if (!isParentOfExisting) {
                    uniqueCards.push(card);
                }
            });

            return uniqueCards.map(c => c.innerText);
        });

        console.log("Parsed Cards:");
        transactions.slice(0, 5).forEach((t, i) => {
            console.log(`\n--- Card ${i+1} ---`);
            console.log(t);
        });

    } catch (e) {
        console.error(e);
    } finally {
        if (browser) await browser.close();
    }
}

checkDashboard();
