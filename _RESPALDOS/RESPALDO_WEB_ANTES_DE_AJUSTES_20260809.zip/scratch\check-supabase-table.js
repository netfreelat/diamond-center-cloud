require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Faltan credenciales de Supabase en .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkTable() {
    console.log('Verificando si la tabla ff_push_subscriptions existe en Supabase...');
    const { data, error } = await supabase
        .from('ff_push_subscriptions')
        .select('*')
        .limit(1);

    if (error) {
        if (error.code === 'PGRST116' || error.message.includes('does not exist')) {
            console.log('\n======================================================');
            console.log('⚠️ LA TABLA NO EXISTE EN SUPABASE AÚN');
            console.log('======================================================');
            console.log('Por favor, ejecuta el siguiente SQL en el editor SQL');
            console.log('de tu panel de Supabase (SQL Editor -> New Query):\n');
            console.log(`CREATE TABLE IF NOT EXISTS ff_push_subscriptions (
  id SERIAL PRIMARY KEY,
  uid TEXT NOT NULL,
  endpoint TEXT NOT NULL UNIQUE,
  keys_p256dh TEXT NOT NULL,
  keys_auth TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_push_subs_uid ON ff_push_subscriptions(uid);`);
            console.log('======================================================\n');
        } else {
            console.error('Error consultando Supabase:', error.message);
        }
    } else {
        console.log('¡Confirmado! La tabla ff_push_subscriptions ya existe o fue creada con éxito.');
    }
}

checkTable();
