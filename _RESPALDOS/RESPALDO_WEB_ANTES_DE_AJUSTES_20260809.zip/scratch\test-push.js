require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');
const webPush = require('web-push');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Faltan SUPABASE_URL o SUPABASE_KEY en las variables de entorno.');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Configurar Web Push
const vapidEmail = process.env.VAPID_EMAIL || 'mailto:netfreelat@gmail.com';
const vapidPublicKey = process.env.VAPID_PUBLIC_KEY ? process.env.VAPID_PUBLIC_KEY.trim().replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_') : undefined;
const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY ? process.env.VAPID_PRIVATE_KEY.trim().replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_') : undefined;

if (vapidPublicKey && vapidPrivateKey) {
    webPush.setVapidDetails(vapidEmail, vapidPublicKey, vapidPrivateKey);
    console.log('[PUSH] Web Push configurado correctamente.');
} else {
    console.error('[PUSH] Faltan claves VAPID.');
    process.exit(1);
}

async function run() {
    try {
        // Obtener la última suscripción
        const { data: subs, error } = await supabase
            .from('ff_push_subscriptions')
            .select('*')
            .order('id', { ascending: false })
            .limit(1);

        if (error) {
            console.error('Error obteniendo suscripción:', error.message);
            return;
        }

        if (!subs || subs.length === 0) {
            console.log('No hay suscripciones registradas en la base de datos.');
            return;
        }

        const sub = subs[0];
        console.log(`Intentando enviar notificación de prueba a UID: ${sub.uid}`);
        console.log(`Endpoint: ${sub.endpoint}`);

        const pushSubscription = {
            endpoint: sub.endpoint,
            keys: {
                p256dh: sub.keys_p256dh,
                auth: sub.keys_auth
            }
        };

        const payload = JSON.stringify({
            title: 'Notificación de Prueba 💎',
            body: 'Esta es una notificación de prueba para verificar el sistema push.',
            icon: '/icon-192.png',
            data: { url: '/historial' }
        });

        await webPush.sendNotification(pushSubscription, payload);
        console.log('✅ ¡Notificación enviada con éxito!');
    } catch (e) {
        console.error('❌ Error al enviar la notificación:', e);
        if (e.statusCode) {
            console.error(`Código de estado HTTP: ${e.statusCode}`);
            console.error(`Cuerpo de la respuesta: ${e.body}`);
        }
    }
}

run();
