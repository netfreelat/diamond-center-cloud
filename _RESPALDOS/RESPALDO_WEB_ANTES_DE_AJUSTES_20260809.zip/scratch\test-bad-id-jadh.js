const puppeteer = require('puppeteer');
require('dotenv').config();

async function run() {
    console.log('🚀 Iniciando simulación de ID incorrecto en jadh.shop...');
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    try {
        console.log('🔑 Iniciando sesión...');
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com');
        await page.type('#login-password', process.env.JADH_PASSWORD || 'Clifor1988');
        
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        console.log('📡 Navegando a Blood Strike...');
        await page.goto('https://jadh.shop/producto/bloodstrike', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 2000));

        console.log('📝 Seleccionando paquete 100🪙 (ID 162)...');
        await page.waitForSelector('#packageSelect', { timeout: 15000 });
        await page.select('#packageSelect', '162');

        console.log('📝 Ingresando ID incorrecto (12345)...');
        const inputSelector = await page.evaluate(() => {
            const newEl = document.querySelector('#gameAccountId');
            if (newEl) return '#gameAccountId';
            const legacyEl = document.querySelector('input[name^="gp_"]');
            return legacyEl ? (legacyEl.id ? '#' + legacyEl.id : 'input[name="' + legacyEl.name + '"]') : null;
        });
        await page.type(inputSelector, '12345');

        console.log('💎 Haciendo clic en Recargar...');
        await Promise.all([
            page.click('#btnPurchase'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 45000 }).catch(() => {})
        ]);

        console.log('⏳ Esperando 5 segundos para que cargue la respuesta...');
        await new Promise(r => setTimeout(r, 5000));

        console.log('📸 Tomando captura del resultado...');
        await page.screenshot({ path: 'bad_id_result.png', fullPage: true });

        const url = page.url();
        const pageText = await page.evaluate(() => document.body.innerText);
        const alertText = await page.evaluate(() => {
            const alert = document.querySelector('.alert, .error, [class*="error"], [class*="alert"]');
            return alert ? alert.innerText : 'No se encontró elemento de alerta.';
        });

        console.log('\n--- DIAGNÓSTICO ---');
        console.log('URL actual:', url);
        console.log('Texto de alerta específico:', alertText);
        console.log('Texto completo de la página (primeros 1500 chars):');
        console.log(pageText.substring(0, 1500));
        console.log('-------------------\n');

    } catch (e) {
        console.error('❌ Error durante la simulación:', e);
    } finally {
        await browser.close();
    }
}

run();
