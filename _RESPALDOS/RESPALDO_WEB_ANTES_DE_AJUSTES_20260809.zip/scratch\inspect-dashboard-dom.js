const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function inspectCopiarDOM() {
    console.log('[TEST-DOM] 🚀 Iniciando inspección de botones Copiar...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(60000);

    try {
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);

        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        const copyElements = await page.evaluate(() => {
            // Buscar elementos que tengan el texto "Copiar" o que llamen a funciones de copiar
            const elements = Array.from(document.querySelectorAll('*')).filter(el => {
                return el.innerText && el.innerText.trim() === 'Copiar';
            });
            
            return elements.map(el => {
                const parent = el.parentElement;
                return {
                    tagName: el.tagName,
                    className: el.className,
                    outerHTML: el.outerHTML,
                    parentTagName: parent ? parent.tagName : '',
                    parentClassName: parent ? parent.className : '',
                    parentHTML: parent ? parent.outerHTML.substring(0, 1000) : ''
                };
            });
        });

        console.log(`Encontrados ${copyElements.length} elementos "Copiar":`);
        copyElements.forEach((el, idx) => {
            console.log(`\n--- Elemento #${idx + 1} ---`);
            console.log(`HTML: ${el.outerHTML}`);
            console.log(`Parent Tag: ${el.parentTagName} | Class: ${el.parentClassName}`);
            console.log(`Parent HTML (primeros 1000 chars):`);
            console.log(el.parentHTML);
        });

    } catch (e) {
        console.error('[TEST-DOM] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[TEST-DOM] 🏁 Inspección finalizada.');
    }
}

inspectCopiarDOM();
