-- ============================================================
-- Diamond Center FF - Tablas Supabase
-- Ejecutar en: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Usuarios y sistema de puntos
CREATE TABLE IF NOT EXISTS ff_users (
  uid TEXT PRIMARY KEY,
  name TEXT DEFAULT 'Jugador',
  apellido TEXT,
  points INTEGER DEFAULT 0,
  password TEXT,
  cedula TEXT,
  phone TEXT,
  registered TIMESTAMPTZ DEFAULT NOW(),
  referred_by TEXT
);

-- Pedidos / Órdenes
CREATE TABLE IF NOT EXISTS ff_orders (
  ref TEXT PRIMARY KEY,
  uid TEXT,
  login_uid TEXT,
  name TEXT,
  pack TEXT,
  method TEXT,
  price TEXT,
  status TEXT DEFAULT 'pending',
  time TIMESTAMPTZ DEFAULT NOW(),
  wa TEXT,
  pin TEXT,
  telegram_msg_id TEXT,
  control_num TEXT,
  ip_address TEXT,
  reason TEXT
);

-- Configuración general (fila única)
CREATE TABLE IF NOT EXISTS ff_settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  tasa_del_dia DECIMAL DEFAULT 635.00,
  barra_informativa TEXT DEFAULT '¡Bienvenidos a Diamond Center FF!',
  admin_username TEXT DEFAULT 'admin',
  admin_password TEXT DEFAULT '1234',
  metodos_pago JSONB DEFAULT '{}',
  whatsapp_config JSONB DEFAULT '{}',
  precios JSONB DEFAULT '{}'
);

-- Pines de canje
CREATE TABLE IF NOT EXISTS ff_pines (
  id SERIAL PRIMARY KEY,
  amount TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  used BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Últimas recargas (marquesina)
CREATE TABLE IF NOT EXISTS ff_recientes (
  id SERIAL PRIMARY KEY,
  name TEXT,
  pack TEXT,
  type TEXT DEFAULT 'recarga',
  time TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Cola de mensajes WhatsApp
CREATE TABLE IF NOT EXISTS ff_wa_queue (
  id TEXT PRIMARY KEY,
  number TEXT,
  message TEXT,
  sent BOOLEAN DEFAULT FALSE,
  delay INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pagos recibidos validados (para el bot de BDV)
CREATE TABLE IF NOT EXISTS ff_pagos_recibidos (
  ref TEXT PRIMARY KEY,
  amount DECIMAL,
  date TEXT,
  used BOOLEAN DEFAULT FALSE
);

-- ============================================================
-- Insertar configuración inicial (ajusta los valores a los tuyos)
-- ============================================================
INSERT INTO ff_settings (id, tasa_del_dia, barra_informativa, admin_username, admin_password, metodos_pago, whatsapp_config, precios)
VALUES (
  1,
  635.00,
  '🔥 Recarga tus diamantes de forma segura y rápida 🔥',
  'admin',
  '1234',
  '{
    "pagomovil": {
      "banco": "Banco de Venezuela (0102)",
      "telefono": "0414-0000000",
      "cedula": "V-00000000"
    },
    "binance": {
      "id": "000000000",
      "nombre": "Diamond Center FF"
    }
  }',
  '{
    "soporte": "584120000000",
    "canal": "https://wa.me/584120000000"
  }',
  '{
    "100":  {"usdt": 1.00, "label": "100 💎"},
    "310":  {"usdt": 3.00, "label": "310 💎"},
    "520":  {"usdt": 5.00, "label": "520 💎"},
    "1060": {"usdt": 10.00, "label": "1060 💎"},
    "2180": {"usdt": 20.00, "label": "2180 💎"},
    "5600": {"usdt": 50.00, "label": "5600 💎"}
  }'
)
ON CONFLICT (id) DO NOTHING;

-- Suscripciones de Notificaciones Push
CREATE TABLE IF NOT EXISTS ff_push_subscriptions (
  id SERIAL PRIMARY KEY,
  uid TEXT NOT NULL,
  endpoint TEXT NOT NULL UNIQUE,
  keys_p256dh TEXT NOT NULL,
  keys_auth TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_push_subs_uid ON ff_push_subscriptions(uid);

-- Contactos de WhatsApp registrados automáticamente
CREATE TABLE IF NOT EXISTS ff_wa_contacts (
  phone TEXT PRIMARY KEY,
  name TEXT DEFAULT 'Cliente',
  uid TEXT,
  source TEXT DEFAULT 'web',
  orders_count INTEGER DEFAULT 1,
  last_seen TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

