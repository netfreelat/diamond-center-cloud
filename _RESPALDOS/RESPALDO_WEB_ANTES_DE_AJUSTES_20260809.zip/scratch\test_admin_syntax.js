const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('admin.html', 'utf8');

// Extract content inside <script> ... </script> tags
const scriptMatches = html.match(/<script[\s\S]*?>([\s\S]*?)<\/script>/gi);

if (!scriptMatches) {
    console.error('No script tags found!');
    process.exit(1);
}

scriptMatches.forEach((s, i) => {
    const code = s.replace(/<script[\s\S]*?>/i, '').replace(/<\/script>/i, '');
    if (code.trim().startsWith('http') || code.includes('src=')) return; // external script
    try {
        new vm.Script(code);
        console.log(`✅ Script tag #${i+1} is SYNTAX OK`);
    } catch (e) {
        console.error(`❌ Script tag #${i+1} HAS SYNTAX ERROR:`, e.message);
        console.error(e.stack);
    }
});
