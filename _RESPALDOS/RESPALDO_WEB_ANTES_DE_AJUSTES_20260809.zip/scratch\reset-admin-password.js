const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// ✏️  Cambia estos valores si quieres
const NEW_USERNAME = 'admin';
const NEW_PASSWORD = 'Recargasney2025';

async function resetPassword() {
    console.log('🔑 Reseteando credenciales de admin en Supabase...');
    console.log(`   Usuario : ${NEW_USERNAME}`);
    console.log(`   Password : ${NEW_PASSWORD}`);

    const { error } = await supabase
        .from('ff_settings')
        .update({
            admin_username: NEW_USERNAME,
            admin_password: NEW_PASSWORD,
            admin_session_token: null   // cierra cualquier sesión activa
        })
        .eq('id', 1);

    if (error) {
        console.error('❌ Error al actualizar:', error.message);
    } else {
        console.log('✅ Contraseña actualizada correctamente.');
        console.log('   Reinicia el servidor en el VPS para que tome efecto.');
    }
}

resetPassword();
