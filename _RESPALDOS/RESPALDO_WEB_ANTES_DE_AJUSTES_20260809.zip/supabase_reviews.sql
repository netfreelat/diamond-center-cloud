-- =============================================
-- TABLA: ff_reviews (Sistema de Testimonios)
-- Ejecutar en el SQL Editor de Supabase
-- =============================================

CREATE TABLE IF NOT EXISTS ff_reviews (
    id          BIGSERIAL PRIMARY KEY,
    uid         TEXT NOT NULL,
    name        TEXT NOT NULL,
    pack        TEXT DEFAULT 'Diamantes',
    rating      SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment     TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Índice para búsquedas por rating
CREATE INDEX IF NOT EXISTS idx_ff_reviews_rating ON ff_reviews(rating DESC);

-- Índice para búsquedas por fecha
CREATE INDEX IF NOT EXISTS idx_ff_reviews_created ON ff_reviews(created_at DESC);

-- Habilitar Row Level Security
ALTER TABLE ff_reviews ENABLE ROW LEVEL SECURITY;

-- Política: Cualquiera puede leer reseñas con rating >= 4 (las que se muestran)
CREATE POLICY "Allow public read of good reviews"
    ON ff_reviews FOR SELECT
    USING (rating >= 4);

-- Política: Solo el service role puede insertar (el servidor Node)
CREATE POLICY "Allow service role insert"
    ON ff_reviews FOR INSERT
    WITH CHECK (true);
