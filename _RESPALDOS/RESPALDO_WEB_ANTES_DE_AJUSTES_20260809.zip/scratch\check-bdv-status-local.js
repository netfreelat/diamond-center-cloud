const { getBDVStatus, bdvLogin, bdvMovimientos } = require('../bdv-service.js');
require('dotenv').config();

async function checkStatus() {
    console.log('=== ESTADO DEL BOT DE BDV ===');
    console.log(getBDVStatus());

    console.log('=== INTENTANDO INICIAR SESIÓN BDV ===');
    const loginRes = await bdvLogin();
    console.log('Resultado del login:', loginRes);

    if (loginRes.success) {
        console.log('=== OBTENIENDO MOVIMIENTOS ===');
        const movs = await bdvMovimientos();
        if (movs) {
            console.log(`Movimientos obtenidos: ${movs.length}`);
            movs.slice(0, 5).forEach(m => {
                console.log(`Fecha: ${m.fecha} | Ref: ${m.referencia} | Desc: ${m.descripcion} | Importe: ${m.importe} | Tipo: ${m.indicadorCargoAbono}`);
            });
        } else {
            console.log('No se pudieron obtener movimientos.');
        }
    }
}

checkStatus();
