require('dotenv').config({ path: '../.env' });
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function restoreUsers() {
  try {
    const rawData = fs.readFileSync('../usuarios.json', 'utf8');
    const oldUsers = JSON.parse(rawData);

    // Fetch current users from Supabase
    const { data: currentUsers, error: fetchError } = await supabase.from('ff_users').select('*');
    if (fetchError) {
      console.error('Error fetching current users:', fetchError);
      return;
    }

    const currentMap = {};
    currentUsers.forEach(u => {
      currentMap[u.uid] = u;
    });

    let restoredCount = 0;
    let updatedCount = 0;

    for (const uid in oldUsers) {
      const oldU = oldUsers[uid];
      
      if (!currentMap[uid]) {
        // User is not in Supabase, insert it
        const payload = {
          uid: uid,
          name: oldU.name || 'Jugador',
          points: oldU.points || 0,
          password: oldU.password || null,
          registered: oldU.registered || new Date().toISOString(),
          referred_by: oldU.referred_by || null,
          referral_claimed: oldU.referral_claimed || false,
          cedula: oldU.cedula || null,
          phone: oldU.phone || null,
          apellido: oldU.apellido || null
        };
        
        const { error: insertError } = await supabase.from('ff_users').insert([payload]);
        if (insertError) {
          console.error(`Error inserting user ${uid}:`, insertError);
        } else {
          console.log(`✅ Usuario restaurado: ${uid} - ${payload.name} con ${payload.points} puntos`);
          restoredCount++;
        }
      } else {
        // User exists in Supabase. Check if we need to update points
        const currentU = currentMap[uid];
        // Only update if old points are greater, or maybe add them?
        // Usually, if they had more points before, we can restore the higher amount.
        if (oldU.points > currentU.points) {
           const { error: updateError } = await supabase.from('ff_users')
             .update({ points: oldU.points })
             .eq('uid', uid);
             
           if (updateError) {
             console.error(`Error updating user ${uid}:`, updateError);
           } else {
             console.log(`⬆️ Puntos actualizados para: ${uid} - de ${currentU.points} a ${oldU.points}`);
             updatedCount++;
           }
        }
      }
    }

    console.log(`\n🎉 Proceso completado: ${restoredCount} usuarios restaurados, ${updatedCount} actualizados.`);

  } catch (err) {
    console.error('Error:', err);
  }
}

restoreUsers();
