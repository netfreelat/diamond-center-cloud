const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function checkCatalog() {
    console.log('[CATALOG] 🚀 Iniciando análisis de catálogo en jadh.shop...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(30000);

    try {
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2' })
        ]);

        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        // Buscar enlaces de productos en el catálogo o menú
        const products = await page.evaluate(() => {
            const links = Array.from(document.querySelectorAll('a')).map(a => ({
                text: a.innerText.trim(),
                href: a.href
            }));
            
            // Filtrar enlaces que contengan "/producto/"
            return links.filter(l => l.href.includes('/producto/') && l.text);
        });

        console.log('--- PRODUCTOS ENCONTRADOS EN EL CATÁLOGO ---');
        console.log(JSON.stringify(products, null, 2));

    } catch (e) {
        console.error('[CATALOG] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[CATALOG] 🏁 Fin.');
    }
}

checkCatalog();
