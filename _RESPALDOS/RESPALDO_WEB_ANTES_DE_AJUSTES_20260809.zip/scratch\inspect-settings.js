const SUPABASE_URL = 'https://gtvlraxlszucoglbnzen.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0dmxyYXhsc3p1Y29nbGJuemVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4Mzg3MTcsImV4cCI6MjA5MTQxNDcxN30.IfbOm2PzrJx_Ycui1GPOeS30_18x4h7W4aMzSzYkr_Y';

const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': 'Bearer ' + SUPABASE_KEY
};

async function check() {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, { headers });
    const data = await res.json();
    console.log("=== SUPABASE FF_SETTINGS ROW ===");
    console.log(JSON.stringify(data, null, 2));
}

check().catch(console.error);
