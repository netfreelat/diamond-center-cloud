require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function main() {
    const newJuegos = {
        "freefire": {
            "nombre": "Free Fire",
            "inputLabel": "ID de Jugador",
            "inputPlaceholder": "Ej: 123456789",
            "icono": "fa-fire",
            "paquetes": {
                "100": { "label": "100 Diamantes", "usdt": 1.0 },
                "310": { "label": "310 Diamantes", "usdt": 3.0 },
                "520": { "label": "520 Diamantes", "usdt": 5.0 },
                "1060": { "label": "1060 Diamantes", "usdt": 10.0 },
                "2180": { "label": "2180 Diamantes", "usdt": 20.0 }
            }
        },
        "roblox": {
            "nombre": "Roblox",
            "inputLabel": "Usuario de Roblox",
            "inputPlaceholder": "Ej: mi_usuario123",
            "icono": "fa-gamepad",
            "paquetes": {
                "400": { "label": "400 Robux", "usdt": 5.0 },
                "800": { "label": "800 Robux", "usdt": 10.0 }
            }
        },
        "bloodstrike": {
            "nombre": "Bloodstrike",
            "inputLabel": "ID de Jugador",
            "inputPlaceholder": "Ej: 123456789",
            "icono": "fa-crosshairs",
            "paquetes": {
                "100": { "label": "100 Oro", "usdt": 1.0 },
                "500": { "label": "500 Oro", "usdt": 5.0 }
            }
        }
    };

    const { error } = await supabase
        .from('ff_settings')
        .update({ juegos: newJuegos })
        .eq('id', 1);

    if (error) {
        console.error('Error updating settings:', error);
    } else {
        console.log('Successfully updated juegos config!');
    }
}

main();
