const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    console.log('--- BUSCANDO TODOS LOS PEDIDOS DE HOY ---');
    const today = new Date();
    today.setHours(0,0,0,0);
    
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .gte('time', today.toISOString())
        .order('time', { ascending: false });

    if (error) {
        console.error('Error fetching today\'s orders:', error);
        return;
    }

    console.log(`Encontrados ${data.length} pedidos hoy:`);
    data.forEach(o => {
        console.log(`ID: ${o.uid} | Ref: ${o.ref} | Pack: ${o.pack} | Price: ${o.price} | Status: ${o.status} | Time: ${o.time}`);
    });
}

run();
