const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.join(__dirname, '..', '.cache', 'puppeteer');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
process.env.TEST_MODE = 'true';

const { rechargeViaJadh } = require('../jadh-service.js');

async function testMLBBFlow() {
    console.log("=== INICIANDO PRUEBA DEL FLUJO DE MOBILE LEGENDS US ===");
    const testUid = "12345678 (1234)";
    const packAmount = "51";
    const game = "mobilelegends";
    
    console.log(`Ejecutando rechargeViaJadh | ID: ${testUid} | Pack: ${packAmount} | Game: ${game}`);
    const result = await rechargeViaJadh(testUid, packAmount, game);
    console.log("=== RESULTADO DE LA PRUEBA ===");
    console.log(JSON.stringify(result, null, 2));
}

testMLBBFlow();
