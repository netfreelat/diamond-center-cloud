const fs = require('fs');
const path = require('path');

const htmlPath = 'c:\\Users\\juanm\\Documents\\PROYECTOS ANTIGRAVITY\\solo para verificar id de free fire\\admin.html';
const html = fs.readFileSync(htmlPath, 'utf8');

const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let count = 0;

while ((match = scriptRegex.exec(html)) !== null) {
    count++;
    const jsCode = match[1];
    if (jsCode.trim().length === 0) continue;
    const tempFile = `c:\\Users\\juanm\\Documents\\PROYECTOS ANTIGRAVITY\\solo para verificar id de free fire\\scratch\\temp_script_${count}.js`;
    fs.writeFileSync(tempFile, jsCode);
    console.log(`[TEST] Verificando bloque de script #${count} (${jsCode.length} bytes)...`);
    
    try {
        require('child_process').execSync(`node -c "${tempFile}"`);
        console.log(`[TEST] ✅ Bloque #${count} SINTAXIS PERFECTA.`);
    } catch(e) {
        console.error(`[TEST] ❌ ERROR EN BLOQUE #${count}:`, e.message);
    } finally {
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    }
}
