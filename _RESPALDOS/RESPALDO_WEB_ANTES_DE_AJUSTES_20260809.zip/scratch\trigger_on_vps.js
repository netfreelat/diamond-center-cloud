const http = require('http');

const data = JSON.stringify({});

const options = {
    hostname: 'localhost',
    port: 3500,
    path: '/api/admin/wa_broadcast_referrals',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'x-wa-secret': 'Sneyder12345*',
        'Content-Length': Buffer.byteLength(data)
    }
};

console.log('Sending local request to port 3500...');

const req = http.request(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
        console.log(`Status Code: ${res.statusCode}`);
        console.log('Response:', body);
        process.exit(0);
    });
});

req.on('error', (err) => {
    console.error('Error:', err.message);
    process.exit(1);
});

req.write(data);
req.end();
