const path = require('path');
process.env.TEST_MODE = 'true';
require('dotenv').config();

const { rechargeViaJadh } = require('../jadh-service');

async function testRobloxFlow() {
    console.log('[TEST-ROBLOX-FLOW] 🚀 Iniciando prueba local del flujo de Roblox...');
    
    // Ejecutar con un usuario ficticio y paquete "10" (para 10 USD Roblox)
    const result = await rechargeViaJadh('RobloxUserTest', '10', 'roblox');
    
    console.log('\n--- RESULTADO DE LA RECARGA ---');
    console.log(JSON.stringify(result, null, 2));
    
    if (result.success && result.pin === 'SIM-ROBLOX-PIN-123456') {
        console.log('\n✅ [TEST-EXITO] El bot de Roblox en modo prueba funcionó perfectamente!');
    } else {
        console.log('\n❌ [TEST-FALLO] El bot de Roblox retornó un resultado inesperado.');
    }
}

testRobloxFlow();
