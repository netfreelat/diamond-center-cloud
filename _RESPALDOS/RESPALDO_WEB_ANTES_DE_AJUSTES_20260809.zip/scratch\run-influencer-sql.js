/**
 * Script de setup para crear las tablas del programa de influencers.
 * Usa la API REST de Supabase directamente con la service_role key.
 * 
 * Si tienes acceso a Supabase, obtén la service_role key de:
 * Dashboard → Settings → API → service_role key
 * 
 * Uso: node scratch/run-influencer-sql.js <service_role_key>
 * O:   SERVICE_ROLE_KEY=xxx node scratch/run-influencer-sql.js
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY  = process.argv[2] || process.env.SUPABASE_SERVICE_KEY || '';

if (!SERVICE_KEY) {
    console.log('\n❌ Falta la service_role key de Supabase.');
    console.log('\nUso: node scratch/run-influencer-sql.js <tu_service_role_key>');
    console.log('\nObtén la key en:');
    console.log('  https://supabase.com/dashboard/project/gtvlraxlszucoglbnzen/settings/api');
    console.log('  → "service_role" key (NO la anon key)\n');
    process.exit(1);
}

const SQL = `
CREATE TABLE IF NOT EXISTS ff_influencers (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  tiktok_handle TEXT NOT NULL,
  followers_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',
  diamonds_balance INTEGER DEFAULT 0,
  total_diamonds_earned INTEGER DEFAULT 0,
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_login TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ff_influencer_submissions (
  id SERIAL PRIMARY KEY,
  influencer_id INTEGER NOT NULL,
  tiktok_url TEXT NOT NULL,
  title TEXT,
  description TEXT,
  screenshot_data TEXT,
  screenshot_filename TEXT,
  views_submitted INTEGER DEFAULT 0,
  views_verified INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',
  diamonds_awarded INTEGER DEFAULT 0,
  admin_notes TEXT,
  week_start DATE,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ff_influencer_payments (
  id SERIAL PRIMARY KEY,
  influencer_id INTEGER NOT NULL,
  submission_id INTEGER,
  diamonds_amount INTEGER NOT NULL,
  note TEXT,
  week_label TEXT,
  paid_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ff_influencer_rates (
  id SERIAL PRIMARY KEY,
  label TEXT NOT NULL,
  min_views INTEGER NOT NULL,
  max_views INTEGER,
  diamonds_reward INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_submissions_influencer ON ff_influencer_submissions(influencer_id);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON ff_influencer_submissions(status);
CREATE INDEX IF NOT EXISTS idx_payments_influencer ON ff_influencer_payments(influencer_id);

INSERT INTO ff_influencer_rates (label, min_views, max_views, diamonds_reward) VALUES
  ('Basico',      1000,   4999,   50),
  ('Intermedio',  5000,   9999,   150),
  ('Popular',     10000,  49999,  400),
  ('Viral',       50000,  99999,  1000),
  ('Mega Viral',  100000, NULL,   2500)
ON CONFLICT DO NOTHING;
`;

async function run() {
    console.log('='.repeat(60));
    console.log('  Diamond Center FF — Influencer DB Setup');
    console.log(`  URL: ${SUPABASE_URL}`);
    console.log('='.repeat(60));

    // Method 1: Supabase SQL via REST API (requires service_role)
    const endpoint = `${SUPABASE_URL}/rest/v1/`;
    
    // Try the pg_dump approach via supabase functions or direct SQL
    const sqlUrl = `${SUPABASE_URL}/rest/v1/rpc/`;
    
    // Try direct SQL via the database endpoint
    try {
        const { createClient } = require('@supabase/supabase-js');
        const supabase = createClient(SUPABASE_URL, SERVICE_KEY, {
            auth: { persistSession: false }
        });
        
        console.log('\n⏳ Ejecutando SQL con service_role key...');
        
        // Try using supabase.rpc for raw SQL (if enabled)
        const statements = SQL.split(';').map(s => s.trim()).filter(s => s.length > 10);
        
        for (const stmt of statements) {
            const label = stmt.slice(0, 60).replace(/\n/g, ' ') + '...';
            
            // Try via fetch with service key
            const res = await fetch(`${SUPABASE_URL}/rest/v1/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': SERVICE_KEY,
                    'Authorization': `Bearer ${SERVICE_KEY}`,
                    'Prefer': 'return=representation'
                }
            });
            
            // Actually use the supabase pg endpoint
            break;
        }
        
        // Use the Supabase SQL API endpoint
        const res = await fetch(`${SUPABASE_URL}/rest/v1/`, {
            method: 'OPTIONS',
            headers: {
                'apikey': SERVICE_KEY,
                'Authorization': `Bearer ${SERVICE_KEY}`
            }
        });
        
        // The real way: POST to /sql endpoint (Supabase doesn't expose this via REST)
        // Instead use the pg connection string approach
        
        // Let's try via the admin API
        const projectRef = SUPABASE_URL.match(/https:\/\/([^.]+)\.supabase\.co/)?.[1];
        const adminRes = await fetch(`https://api.supabase.com/v1/projects/${projectRef}/database/query`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${SERVICE_KEY}`
            },
            body: JSON.stringify({ query: SQL })
        });
        
        if (adminRes.ok) {
            const result = await adminRes.json();
            console.log('✅ SQL ejecutado exitosamente!');
            console.log(JSON.stringify(result, null, 2));
        } else {
            const errBody = await adminRes.text();
            console.error(`❌ Error ${adminRes.status}: ${errBody.slice(0, 300)}`);
            console.log('\n💡 La service_role key no tiene acceso al Management API.');
            console.log('   Necesitas un Personal Access Token de Supabase.');
            console.log('   Ve a: https://supabase.com/dashboard/account/tokens');
        }
        
    } catch(e) {
        console.error('Error:', e.message);
    }
}

run();
