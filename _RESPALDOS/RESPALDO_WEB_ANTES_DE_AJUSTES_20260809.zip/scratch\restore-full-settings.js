const SUPABASE_URL = 'https://gtvlraxlszucoglbnzen.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0dmxyYXhsc3p1Y29nbGJuemVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4Mzg3MTcsImV4cCI6MjA5MTQxNDcxN30.IfbOm2PzrJx_Ycui1GPOeS30_18x4h7W4aMzSzYkr_Y';

const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': 'Bearer ' + SUPABASE_KEY,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation'
};

const fullPrecios = {
    "100": { "usdt": 0.86, "label": "100 + 10 Diamantes" },
    "310": { "usdt": 2.90, "label": "310 + 31 Diamantes" },
    "520": { "usdt": 4.15, "label": "520 + 52 Diamantes" },
    "1060": { "usdt": 7.50, "label": "1060 + 106 Diamantes" },
    "2180": { "usdt": 14.56, "label": "2180 + 218 Diamantes" },
    "5600": { "usdt": 35.80, "label": "5600 + 560 Diamantes" },
    "basica": { "usdt": 0.80, "label": "🃏 Tarjeta Básica" },
    "semanal": { "usdt": 3.00, "label": "📅 Tarjeta Semanal" },
    "mensual": { "usdt": 14.01, "label": "👑 Tarjeta Mensual" },
    "booyah": { "usdt": 5.01, "label": "🏆 Pase Booyah" }
};

async function fix() {
    // 1. Read existing row
    const res = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, { headers });
    const data = await res.json();
    if (!data || !data[0]) {
        console.error("❌ No se encontró la fila id=1 en ff_settings");
        return;
    }

    const row = data[0];
    const juegos = row.juegos || {};
    
    // Ensure freefire has full packages
    if (!juegos.freefire) juegos.freefire = {};
    juegos.freefire.nombre = "Free Fire";
    juegos.freefire.icono = "fa-fire";
    juegos.freefire.inputLabel = "ID de Jugador";
    juegos.freefire.inputPlaceholder = "Ej: 123456789";
    juegos.freefire.paquetes = fullPrecios;

    const metodos_pago = row.metodos_pago || {};
    if (!metodos_pago.pagomovil) metodos_pago.pagomovil = {};
    metodos_pago.pagomovil.banco = metodos_pago.pagomovil.banco || "Banco de Venezuela (0102)";
    metodos_pago.pagomovil.cedula = metodos_pago.pagomovil.cedula || "18165391";
    metodos_pago.pagomovil.telefono = metodos_pago.pagomovil.telefono || "04243445879";
    metodos_pago.pagomovil.auto_approve_enabled = true;

    const whatsapp_config = row.whatsapp_config || {};
    whatsapp_config.bot = whatsapp_config.bot || "584123491068";
    whatsapp_config.soporte = whatsapp_config.soporte || "584125322412";
    whatsapp_config.canal = whatsapp_config.canal || "https://whatsapp.com/channel/0029Vb7Wf8M35fLnOvFiY01K";
    whatsapp_config.modo = "activo";

    const updatePayload = {
        tasa_del_dia: 812.00,
        precios: fullPrecios,
        juegos: juegos,
        metodos_pago: metodos_pago,
        whatsapp_config: whatsapp_config
    };

    console.log("Restaurando configuración completa en Supabase...");
    const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/ff_settings?id=eq.1`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify(updatePayload)
    });

    console.log("Status respuesta Supabase:", patchRes.status);
    if (patchRes.status === 200 || patchRes.status === 204) {
        console.log("✅ Configuración restaurada con ÉXITO en Supabase:");
        console.log(" - Tasa del día: 812.00 Bs");
        console.log(" - Paquetes Free Fire: 10 paquetes restaurados");
        console.log(" - Auto-aprobación BDV: ACTIVADA");
        console.log(" - Bot WhatsApp: ACTIVADO");
    } else {
        const errText = await patchRes.text();
        console.error("❌ Error al actualizar Supabase:", errText);
    }
}

fix().catch(console.error);
