const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function checkPending() {
    console.log('--- BUSCANDO PEDIDOS PENDIENTES ---');
    const { data, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('status', 'pending')
        .order('time', { ascending: false });

    if (error) {
        console.error('Error querying Supabase:', error.message);
        return;
    }

    if (!data || data.length === 0) {
        console.log('No hay pedidos pendientes.');
        return;
    }

    data.forEach(o => {
        console.log(`ID: ${o.uid} | Ref: ${o.ref} | Pack: ${o.pack} | Price: ${o.price} | Method: ${o.method} | Time: ${o.time}`);
    });
}

checkPending();
