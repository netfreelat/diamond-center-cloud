const dotenv = require('dotenv');
dotenv.config();
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

function normalizePhone(num) {
    if (!num) return null;
    let clean = num.toString().replace(/\D/g, '');
    if (!clean) return null;
    if (clean.startsWith('0')) {
        clean = '58' + clean.substring(1);
    } else if (!clean.startsWith('58') && clean.length === 10) {
        clean = '58' + clean;
    }
    if (clean.length < 8 || clean.length > 15) return null;
    return clean;
}

async function main() {
    console.log('--- CREATING OR VERIFYING ff_wa_contacts TABLE ---');
    
    // Check if table exists
    const { data: testData, error: testErr } = await supabase.from('ff_wa_contacts').select('*').limit(1);
    
    if (testErr && testErr.code === '42P01') {
        console.log('⚠️ La tabla ff_wa_contacts no existe aún en Supabase.');
    } else {
        console.log('✅ Tabla ff_wa_contacts accesible.');
    }

    const contactsMap = {};

    // 1. Fetch users
    console.log('\n--- EXTRACTING NUMBERS FROM ff_users ---');
    const { data: users } = await supabase.from('ff_users').select('uid, name, phone, registered');
    if (users) {
        users.forEach(u => {
            const clean = normalizePhone(u.phone);
            if (clean) {
                contactsMap[clean] = {
                    phone: clean,
                    name: u.name && u.name !== 'Jugador' ? u.name : 'Cliente',
                    uid: u.uid || null,
                    source: 'web_user',
                    last_seen: u.registered || new Date().toISOString()
                };
            }
        });
    }

    // 2. Fetch orders
    console.log('\n--- EXTRACTING NUMBERS FROM ff_orders ---');
    const { data: orders } = await supabase.from('ff_orders').select('uid, name, wa, time');
    if (orders) {
        orders.forEach(o => {
            const clean = normalizePhone(o.wa);
            if (clean) {
                if (contactsMap[clean]) {
                    if (o.name && o.name !== 'Jugador' && o.name !== '—') contactsMap[clean].name = o.name;
                    if (o.uid) contactsMap[clean].uid = o.uid;
                    contactsMap[clean].last_seen = o.time || contactsMap[clean].last_seen;
                } else {
                    contactsMap[clean] = {
                        phone: clean,
                        name: o.name && o.name !== 'Jugador' && o.name !== '—' ? o.name : 'Cliente',
                        uid: o.uid || null,
                        source: 'web_order',
                        last_seen: o.time || new Date().toISOString()
                    };
                }
            }
        });
    }

    const contactsList = Object.values(contactsMap);
    console.log(`\n📦 Subiendo batch de ${contactsList.length} contactos a ff_wa_contacts...`);

    // Batch upsert in chunks of 100
    for (let i = 0; i < contactsList.length; i += 100) {
        const chunk = contactsList.slice(i, i + 100);
        const { error } = await supabase.from('ff_wa_contacts').upsert(chunk, { onConflict: 'phone' });
        if (error) {
            console.error('Error upserting chunk:', error.message);
        }
    }

    // Fetch total count
    const { count } = await supabase.from('ff_wa_contacts').select('*', { count: 'exact', head: true });
    console.log(`\n🎉 BASE DE DATOS INICIALIZADA CON ${count} CONTACTOS DE WHATSAPP!`);
}

main();
