const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

function getCaracasDateParts(date = new Date()) {
    const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: 'America/Caracas',
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: false
    });
    const parts = formatter.formatToParts(date);
    const map = {};
    parts.forEach(p => map[p.type] = p.value);
    return {
        year: parseInt(map.year),
        month: parseInt(map.month) - 1, // 0-indexed
        day: parseInt(map.day),
        hour: parseInt(map.hour % 24),
        minute: parseInt(map.minute),
        second: parseInt(map.second)
    };
}

// Robust start of today in Caracas returned as UTC Date object
function getCaracasStartOfToday(now = new Date()) {
    const parts = getCaracasDateParts(now);
    // Caracas is UTC-4. 00:00:00 in Caracas (UTC-4) is 04:00:00 UTC.
    // We construct the UTC date corresponding to YYYY-MM-DD 00:00:00 Caracas time.
    return new Date(Date.UTC(parts.year, parts.month, parts.day, 4, 0, 0, 0));
}

function getCaracasStartOfWeek(now = new Date()) {
    const startToday = getCaracasStartOfToday(now);
    const parts = getCaracasDateParts(now);
    // Day of week in Caracas (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
    // To find day of week, we can check the UTC date of startToday which corresponds to the day in Caracas
    const d = new Date(Date.UTC(parts.year, parts.month, parts.day));
    const dayOfWeek = d.getUTCDay();
    const startOfWeek = new Date(startToday);
    startOfWeek.setUTCDate(startOfWeek.getUTCDate() - dayOfWeek);
    return startOfWeek;
}

function getCaracasStartOfMonth(now = new Date()) {
    const parts = getCaracasDateParts(now);
    return new Date(Date.UTC(parts.year, parts.month, 1, 4, 0, 0, 0));
}

async function testSolution() {
    const { data: allOrders } = await supabase
        .from('ff_orders')
        .select('ref, time, pack, price, method')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    const now = new Date();
    const startToday = getCaracasStartOfToday(now);
    const startWeek  = getCaracasStartOfWeek(now);
    const startMonth = getCaracasStartOfMonth(now);

    console.log('Current UTC Time:', now.toISOString());
    console.log('Caracas Start of Today (UTC):', startToday.toISOString());
    console.log('Caracas Start of Week (UTC):', startWeek.toISOString());
    console.log('Caracas Start of Month (UTC):', startMonth.toISOString());

    function calc(from) {
        let count = 0;
        let totalUsdt = 0;
        allOrders.forEach(o => {
            const t = new Date(o.time);
            if (t >= from) {
                count++;
            }
        });
        return count;
    }

    console.log('\n--- RESULTS WITH ROBUST CALCULATION ---');
    console.log('Today orders count:', calc(startToday));
    console.log('Week orders count:', calc(startWeek));
    console.log('Month orders count:', calc(startMonth));

    console.log('\nOrders matching Today:');
    allOrders.forEach(o => {
        if (new Date(o.time) >= startToday) {
            console.log(`- Ref: ${o.ref}, Time: ${o.time}, Pack: ${o.pack}, Price: ${o.price}`);
        }
    });
}

testSolution();
