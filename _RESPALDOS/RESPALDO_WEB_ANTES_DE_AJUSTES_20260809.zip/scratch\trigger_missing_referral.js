const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    const wa = '584125932186';
    const name = '༒☬❦.RICO.❦☬༒';
    const referralUid = '5447327819';
    const ref = '006640481479';

    const refLink = `https://recargasney.com/?ref=${referralUid}`;
    const refMsgText =
        `🎁 *¡Gana dinero invitando a tus amigos!*\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Hola *${name}*, ¿sabes que tienes un link personal para ganar cashback?\n\n` +
        `👉 *Cómo funciona el programa de referidos:*\n\n` +
        `💰 *Tú ganas* → *+$0.05 USDT* cada vez que un amigo realiza su primera recarga\n\n` +
        `🎮 *Tu amigo gana* → *-3% de descuento* en su primera compra\n\n` +
        `∞ *¡Sin límite de referidos!* Entre más compartes, más ganas.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🔗 *Tu link único:*\n${refLink}\n\n` +
        `_¡Compártelo en tus grupos de Free Fire y empieza a cobrar!_ 🚀💎`;

    // Enviar de inmediato (sendAfter es la hora actual)
    const refMsgId = `wa_refpitch_${ref}_sendAfter_${Date.now()}`;
    const refWaItem = { id: refMsgId, number: wa, message: refMsgText };

    console.log(`Encolando mensaje de referido manual para ${wa}...`);
    const { error } = await supabase.from('ff_wa_queue').insert(refWaItem);

    if (error) {
        console.error("Error insertando en la cola:", error.message);
    } else {
        console.log("✅ ¡Mensaje encolado con éxito en la base de datos! El bot lo procesará en segundos.");
    }
}

run().catch(console.error);
