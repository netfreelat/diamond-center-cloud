const https = require('https');

const url = 'https://recargasney.com/notificar?uid=12345678&name=TestPlayer&pack=100&method=pagomovil&ref=998877&price=1.00USDT/655.00Bs&wa=584125313735&juego=freefire';

https.get(url, (res) => {
  console.log(`STATUS: ${res.statusCode}`);
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  res.on('end', () => {
    console.log('RESPONSE:', data);
  });
}).on('error', (err) => {
  console.error('Error:', err.message);
});
