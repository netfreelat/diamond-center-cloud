const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const fs = require('fs');
const envFile = fs.readFileSync('.env', 'utf8');
const urlMatch = envFile.match(/SUPABASE_URL=(.+)/);
const keyMatch = envFile.match(/SUPABASE_KEY=(.+)/);
const url = urlMatch ? urlMatch[1].trim() : '';
const key = keyMatch ? keyMatch[1].trim() : '';

const client = createClient(url, key);

async function run() {
    const { data: settingsData, error: fetchErr } = await client
        .from('ff_settings')
        .select('*')
        .eq('id', 1)
        .single();

    if (fetchErr) {
        console.error('Error fetching settings:', fetchErr.message);
        return;
    }

    const juegos = settingsData.juegos || {};
    juegos.sorteo_semanal = {
        premio: '341 Diamantes',
        lastWinner: {
            uid: '7247325486',
            name: '4z 亗乙ㄖ尺尺ㄖツᴬ',
            premio: '341 Diamantes',
            timestamp: new Date().toISOString()
        },
        lastResetTimestamp: new Date().toISOString()
    };

    const { error: updateErr } = await client
        .from('ff_settings')
        .update({ juegos })
        .eq('id', 1);

    if (updateErr) {
        console.error('Error updating settings:', updateErr.message);
    } else {
        console.log('✅ lastWinner successfully set in Supabase for 4z 亗乙ㄖ尺尺ㄖツᴬ (UID: 7247325486)!');
    }
}

run();
