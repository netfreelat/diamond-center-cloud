-- Añadir columna 'juegos' a la tabla ff_settings para soportar múltiples juegos (Free Fire, Roblox, COD, etc.)
-- Se usa tipo JSONB para almacenar dinámicamente los paquetes, imágenes y nombres.
ALTER TABLE ff_settings ADD COLUMN IF NOT EXISTS juegos JSONB DEFAULT '{}'::jsonb;

-- Poblar la columna con datos iniciales de ejemplo (migrando los precios actuales de Free Fire y agregando otros)
UPDATE ff_settings SET juegos = '{
  "freefire": {
    "nombre": "Free Fire",
    "inputLabel": "ID de Jugador",
    "inputPlaceholder": "Ej: 123456789",
    "icono": "fa-fire",
    "paquetes": {
       "100": { "label": "100 Diamantes", "usdt": 1.0 },
       "310": { "label": "310 Diamantes", "usdt": 3.0 },
       "520": { "label": "520 Diamantes", "usdt": 5.0 },
       "1060": { "label": "1060 Diamantes", "usdt": 10.0 },
       "2180": { "label": "2180 Diamantes", "usdt": 20.0 }
    }
  },
  "roblox": {
    "nombre": "Roblox",
    "inputLabel": "Usuario de Roblox",
    "inputPlaceholder": "Ej: mi_usuario123",
    "icono": "fa-gamepad",
    "paquetes": {
       "400": { "label": "400 Robux", "usdt": 5.0 },
       "800": { "label": "800 Robux", "usdt": 10.0 }
    }
  },
  "bloodstrike": {
    "nombre": "Bloodstrike",
    "inputLabel": "ID de Jugador",
    "inputPlaceholder": "Ej: 123456789",
    "icono": "fa-crosshairs",
    "paquetes": {
       "100": { "label": "100 Oro", "usdt": 1.0 },
       "500": { "label": "500 Oro", "usdt": 5.0 }
    }
  }
}'::jsonb WHERE id = 1;

-- Actualizar la tabla de pedidos (ff_orders) para tener una columna 'juego'
ALTER TABLE ff_orders ADD COLUMN IF NOT EXISTS juego VARCHAR(50) DEFAULT 'freefire';
