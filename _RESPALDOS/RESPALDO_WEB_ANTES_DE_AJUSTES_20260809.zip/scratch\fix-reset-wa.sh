#!/bin/bash
# Fix reset-wa-session: replace lines 2168-2185 with corrected version
FILE="/var/www/recargasney/server.js"

# Get lines before the block (1 to 2167)
head -n 2167 "$FILE" > /tmp/server_part1.js

# Write the new fixed block
cat >> /tmp/server_part1.js << 'ENDOFBLOCK'
    } else if (parsedUrl.pathname === '/admin/reset-wa-session' && req.method === 'POST') {
        const { exec } = require('child_process');
        console.log('[ADMIN] 🔄 CAMBIO DE NÚMERO: Parando bot, borrando sesión y reiniciando...');
        res.writeHead(200);
        res.end(JSON.stringify({ success: true, message: 'Sesión borrada. El bot generará un nuevo QR.' }));
        exec('pm2 stop recargasney-wa', () => {
            setTimeout(() => {
                exec('rm -rf /var/www/recargasney/.wwebjs_auth /var/www/recargasney/.wwebjs_cache', (err2) => {
                    if (err2) console.error('[ADMIN] ❌ Error al borrar sesión:', err2.message);
                    else console.log('[ADMIN] ✅ Sesión borrada. Reiniciando bot...');
                    setTimeout(() => {
                        exec('pm2 start recargasney-wa', (err3) => {
                            if (err3) console.error('[ADMIN] ❌ Error al iniciar bot:', err3.message);
                            else console.log('[ADMIN] ✅ Bot reiniciado. QR nuevo disponible.');
                        });
                    }, 1000);
                });
            }, 2000);
        });

ENDOFBLOCK

# Append lines from 2186 onwards (the BDV section starts at 2186)
tail -n +2186 "$FILE" >> /tmp/server_part1.js

# Replace original file
mv /tmp/server_part1.js "$FILE"
echo "OK: server.js actualizado ($(wc -l < "$FILE") lineas)"
