const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
    console.log("Preparando cola de referidos para los dos clientes de hoy...");

    const usersToPitch = [
        {
            wa: '584125932186',
            name: '༒☬❦.RICO.❦☬༒',
            uid: '5447327819',
            ref: '006640481479'
        },
        {
            wa: '584141476046',
            name: 'MR_$ICARI0',
            uid: '6612902245',
            ref: '006639595165'
        }
    ];

    for (const u of usersToPitch) {
        // 1. Borrar cualquier pitch anterior para esta referencia para evitar duplicados
        await supabase
            .from('ff_wa_queue')
            .delete()
            .like('id', `wa_refpitch_${u.ref}%`);

        const refLink = `https://recargasney.com/?ref=${u.uid}`;
        const refMsgText =
            `🎁 *¡Gana dinero invitando a tus amigos!*\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `Hola *${u.name}*, ¿sabes que tienes un link personal para ganar cashback?\n\n` +
            `👉 *Cómo funciona el programa de referidos:*\n\n` +
            `💰 *Tú ganas* → *+$0.05 USDT* cada vez que un amigo realiza su primera recarga\n\n` +
            `🎮 *Tu amigo gana* → *-3% de descuento* en su primera compra\n\n` +
            `∞ *¡Sin límite de referidos!* Entre más compartes, más ganas.\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `🔗 *Tu link único:*\n${refLink}\n\n` +
            `_¡Compártelo en tus grupos de Free Fire y empieza a cobrar!_ 🚀💎`;

        // Generar un ID de envío inmediato
        const refMsgId = `wa_refpitch_${u.ref}_sendAfter_${Date.now()}`;
        const refWaItem = { id: refMsgId, number: u.wa, message: refMsgText };

        console.log(`Encolando pitch para ${u.name} (${u.wa})...`);
        const { error } = await supabase.from('ff_wa_queue').insert(refWaItem);
        if (error) {
            console.error(`Error encolando para ${u.name}:`, error.message);
        } else {
            console.log(`✅ Pitch para ${u.name} encolado.`);
        }
    }

    console.log("\n🎉 ¡Todo listo en la base de datos!");
}

run().catch(console.error);
