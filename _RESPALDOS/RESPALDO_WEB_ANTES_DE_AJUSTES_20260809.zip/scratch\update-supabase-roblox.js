const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('❌ Falta SUPABASE_URL o SUPABASE_KEY en el .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function updateRobloxSettings() {
    try {
        // 1. Obtener la config actual
        const { data, error } = await supabase
            .from('ff_settings')
            .select('juegos')
            .eq('id', 1)
            .single();

        if (error) throw error;

        const juegos = data.juegos || {};
        
        // 2. Modificar solo roblox
        juegos.roblox = {
            "nombre": "Roblox",
            "inputLabel": "Usuario / ID de Roblox",
            "inputPlaceholder": "Ej: MiUsuario123",
            "icono": "fa-gamepad",
            "paquetes": {
                "10": { "usdt": 10.50, "label": "10 USD" }
            }
        };

        console.log('Nueva configuración para guardar:', JSON.stringify(juegos, null, 2));

        // 3. Guardar en Supabase
        const { error: updateError } = await supabase
            .from('ff_settings')
            .update({ juegos })
            .eq('id', 1);

        if (updateError) throw updateError;

        console.log('✅ [EXITO] Configuración de juegos actualizada en Supabase con Roblox 10 USD!');

    } catch (e) {
        console.error('❌ Error actualizando configuración:', e.message);
    }
}

updateRobloxSettings();
