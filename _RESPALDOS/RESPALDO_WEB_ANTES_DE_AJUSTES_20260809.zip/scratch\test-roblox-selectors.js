const path = require('path');
process.env.PUPPETEER_CACHE_DIR = path.resolve(__dirname, '..', '.cache', 'puppeteer');
const puppeteer = require('puppeteer');
require('dotenv').config();

const email = process.env.JADH_EMAIL || 'jmnetfreelat@gmail.com';
const password = process.env.JADH_PASSWORD || 'Clifor1988';

async function checkDashboard() {
    console.log('[TEST-DASHBOARD] 🚀 Iniciando análisis de dashboard en jadh.shop...\n');

    const launchOptions = {
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
    };

    if (process.platform === 'win32') {
        launchOptions.executablePath = path.resolve(__dirname, '..', '.cache', 'puppeteer', 'chrome', 'win64-121.0.6167.85', 'chrome-win64', 'chrome.exe');
    }

    const browser = await puppeteer.launch(launchOptions);
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(60000);

    try {
        // --- Login ---
        console.log('[TEST-DASHBOARD] 🔑 Navegando a /auth...');
        await page.goto('https://jadh.shop/auth', { waitUntil: 'networkidle2' });
        await page.waitForSelector('#login-email', { timeout: 15000 });
        await page.type('#login-email', email);
        await page.type('#login-password', password);
        await Promise.all([
            page.click('#login-form button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 })
        ]);
        console.log('[TEST-DASHBOARD] ✅ Login completado. URL actual:', page.url());

        // --- Analizar Dashboard ---
        console.log('[TEST-DASHBOARD] 📡 Navegando a /...');
        await page.goto('https://jadh.shop/', { waitUntil: 'networkidle2' });
        await new Promise(r => setTimeout(r, 4000));

        const dashboardText = await page.evaluate(() => document.body.innerText);
        console.log('\n=== TEXTO DEL DASHBOARD (primeros 4000 chars) ===');
        console.log(dashboardText.substring(0, 4000));

        const screenshotPath = path.resolve(__dirname, 'dashboard_jadh.png');
        await page.screenshot({ path: screenshotPath, fullPage: true });
        console.log(`[TEST-DASHBOARD] 📸 Screenshot guardado: ${screenshotPath}`);

    } catch (e) {
        console.error('[TEST-DASHBOARD] ❌ Error:', e.message);
    } finally {
        await browser.close();
        console.log('\n[TEST-DASHBOARD] 🏁 Análisis finalizado.');
    }
}

checkDashboard();
