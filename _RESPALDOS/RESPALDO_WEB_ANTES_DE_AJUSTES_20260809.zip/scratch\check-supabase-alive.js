require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function checkAlive() {
    console.log('🔍 Verificando conexión a Supabase...');
    console.log(`📡 URL: ${process.env.SUPABASE_URL}`);
    console.log('');

    try {
        // Test 1: ¿Responde la base de datos?
        const { data: orders, error: ordersError } = await supabase
            .from('ff_orders')
            .select('ref, status, time')
            .order('time', { ascending: false })
            .limit(3);

        if (ordersError) {
            console.error('❌ ERROR al conectar con ff_orders:', ordersError.message);
        } else {
            console.log(`✅ Tabla ff_orders OK — ${orders.length} pedidos recientes encontrados:`);
            orders.forEach(o => console.log(`   📦 Ref: ${o.ref} | Estado: ${o.status} | Fecha: ${o.time}`));
        }

        // Test 2: ¿Existen usuarios?
        const { data: users, error: usersError, count } = await supabase
            .from('ff_users')
            .select('uid', { count: 'exact', head: true });

        if (usersError) {
            console.error('❌ ERROR al conectar con ff_users:', usersError.message);
        } else {
            console.log(`\n✅ Tabla ff_users OK — ${count} usuarios registrados.`);
        }

        // Test 3: ¿Existe la configuración?
        const { data: settings, error: settingsError } = await supabase
            .from('ff_settings')
            .select('tasa_del_dia')
            .single();

        if (settingsError) {
            console.error('❌ ERROR al conectar con ff_settings:', settingsError.message);
        } else {
            console.log(`✅ Tabla ff_settings OK — Tasa del día: ${settings.tasa_del_dia}`);
        }

        console.log('\n🎉 ¡TU BASE DE DATOS ESTÁ VIVA Y FUNCIONANDO!');
        console.log('   No perdiste nada. Solo necesitas encontrar el correo correcto para el panel web de Supabase.');

    } catch (e) {
        console.error('\n💀 ERROR CRÍTICO:', e.message);
        console.log('   Esto podría indicar que el proyecto fue eliminado o la URL cambió.');
    }
}

checkAlive();
