const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function check() {
    const { data, error } = await supabase
        .from('ff_settings')
        .select('admin_username, admin_password')
        .eq('id', 1)
        .single();

    if (error) {
        console.error(error);
    } else {
        console.log('--- ADMIN CREDENTIALS ---');
        console.log('Usuario:', data.admin_username);
        console.log('Contraseña:', data.admin_password);
    }
}

check();
