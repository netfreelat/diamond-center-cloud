const fs = require('fs');
const content = fs.readFileSync('server.js', 'utf8');
const lines = content.split('\n');
lines.forEach((line, index) => {
    if (line.includes('function checkAdminAuth')) {
        console.log(`Line ${index + 1}: ${line}`);
        // print next 30 lines
        for (let i = 1; i <= 30; i++) {
            console.log(`Line ${index + 1 + i}: ${lines[index + i]}`);
        }
    }
});
