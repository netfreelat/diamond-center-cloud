const fs = require('fs');
const content = fs.readFileSync('server.js', 'utf8');
const lines = content.split('\n');

console.log('Searching for orders variable definition...');
lines.forEach((line, index) => {
    if (line.includes('let orders') || line.includes('const orders') || line.includes('orders = {}')) {
        console.log(`Line ${index + 1}: ${line}`);
    }
});
