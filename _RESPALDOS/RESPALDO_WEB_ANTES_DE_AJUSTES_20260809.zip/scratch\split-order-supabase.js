const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function run() {
    console.log('--- SPLITTING ORDER IN SUPABASE ---');

    // 1. Obtener la orden original
    const { data: order, error: fetchError } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('ref', '006675887569, 006675892039')
        .single();

    if (fetchError || !order) {
        console.error('Error fetching original order:', fetchError || 'Order not found');
        return;
    }

    console.log('Original order found:', order);

    // 2. Crear los datos de la primera orden (Aprobada, ref: 006675887569)
    const order1 = {
        ref: '006675887569',
        uid: order.uid,
        login_uid: order.login_uid,
        name: order.name,
        pack: order.pack,
        method: order.method,
        price: order.price,
        status: 'approved',
        time: order.time,
        wa: order.wa,
        pin: '#254775', // La recarga que ya se hizo
        telegram_msg_id: order.telegram_msg_id,
        control_num: order.control_num,
        ip_address: order.ip_address,
        juego: order.juego
    };

    // 3. Crear los datos de la segunda orden (Pendiente, ref: 006675892039)
    // Le sumamos 10 segundos al tiempo original para diferenciarla
    const originalDate = new Date(order.time);
    const secondDate = new Date(originalDate.getTime() + 10000);
    const order2 = {
        ref: '006675892039',
        uid: order.uid,
        login_uid: order.login_uid,
        name: order.name,
        pack: order.pack,
        method: order.method,
        price: order.price,
        status: 'pending',
        time: secondDate.toISOString(),
        wa: order.wa,
        pin: null,
        telegram_msg_id: null,
        control_num: null,
        ip_address: order.ip_address,
        juego: order.juego
    };

    // 4. Insertar las dos órdenes
    console.log('Inserting order 1 (Approved)...');
    const { error: err1 } = await supabase.from('ff_orders').insert(order1);
    if (err1) {
        console.error('Error inserting order1:', err1);
        return;
    }
    console.log('Order 1 inserted successfully.');

    console.log('Inserting order 2 (Pending)...');
    const { error: err2 } = await supabase.from('ff_orders').insert(order2);
    if (err2) {
        console.error('Error inserting order2:', err2);
        return;
    }
    console.log('Order 2 inserted successfully.');

    // 5. Eliminar la orden original combinada
    console.log('Deleting combined original order...');
    const { error: delErr } = await supabase
        .from('ff_orders')
        .delete()
        .eq('ref', '006675887569, 006675892039');
    if (delErr) {
        console.error('Error deleting combined order:', delErr);
        return;
    }
    console.log('Combined order deleted successfully.');

    // 6. Actualizar ff_pagos_recibidos
    // A) Borrar el pago de 0 Bs con ref '006675887569, 006675892039'
    console.log('Deleting combined payment entry...');
    await supabase.from('ff_pagos_recibidos').delete().eq('ref', '006675887569, 006675892039');

    // B) Actualizar el pago original '0677275887569' a used: true
    console.log('Marking first payment 0677275887569 as used...');
    await supabase.from('ff_pagos_recibidos').update({ used: true }).eq('ref', '0677275887569');

    // C) Insertar el pago '006675892039' (o el correspondiente) para que conste
    console.log('Inserting second payment entry...');
    await supabase.from('ff_pagos_recibidos').upsert({
        ref: '006675892039',
        amount: 748.2,
        date: new Date().toISOString(),
        used: false
    });

    console.log('--- ALL SUPABASE CHANGES DONE SUCCESSFULY ---');
}

run();
