﻿const { createClient } = require('@supabase/supabase-js');
const ws = require('ws');
require('dotenv').config({ path: '/var/www/recargasney/.env' });
const s = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY, {
    realtime: { transport: ws }
});
s.from('ff_users').select('uid,name,referred_by,referral_claimed,points,registered').not('referred_by','is',null).then(({ data, error }) => {
    if (error) { console.log('ERROR:', error.message); process.exit(1); }
    console.log('TOTAL:', data.length);
    data.forEach(u => console.log(JSON.stringify(u)));
    process.exit(0);
});
