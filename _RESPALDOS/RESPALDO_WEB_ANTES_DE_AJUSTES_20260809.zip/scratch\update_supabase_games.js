const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error("❌ Faltan credenciales de Supabase en .env");
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function syncGames() {
    console.log("Obteniendo ff_settings de Supabase...");
    const { data, error } = await supabase
        .from('ff_settings')
        .select('juegos')
        .eq('id', 1)
        .single();
        
    if (error) {
        console.error("❌ Error al obtener ff_settings:", error.message);
        return;
    }
    
    console.log("Juegos actuales en Supabase:", Object.keys(data.juegos || {}));
    
    const currentJuegos = data.juegos || {};
    
    const mobilelegendsData = {
        "nombre": "Mobile Legends US",
        "inputLabel": "ID de Jugador (User ID y Zone ID)",
        "inputPlaceholder": "Ej: 12345678 (1234)",
        "icono": "fa-shield-halved",
        "paquetes": {
            "51":   { "usdt": 0.90,  "label": "51 + 5 💎 Diamantes" },
            "102":  { "usdt": 1.85,  "label": "102 + 10 💎 Diamantes" },
            "253":  { "usdt": 4.69,  "label": "253 + 25 💎 Diamantes" },
            "505":  { "usdt": 9.33,  "label": "505 + 66 💎 Diamantes" },
            "1010": { "usdt": 18.94, "label": "1010 + 182 💎 Diamantes" },
            "1515": { "usdt": 28.60, "label": "1515 + 273 💎 Diamantes" }
        }
    };
    
    currentJuegos["mobilelegends"] = mobilelegendsData;
    
    console.log("Actualizando ff_settings en Supabase...");
    const { error: updateError } = await supabase
        .from('ff_settings')
        .update({ juegos: currentJuegos })
        .eq('id', 1);
        
    if (updateError) {
        console.error("❌ Error al actualizar ff_settings en Supabase:", updateError.message);
    } else {
        console.log("✅ ¡ff_settings en Supabase actualizado exitosamente con Mobile Legends US!");
    }
}

syncGames();
