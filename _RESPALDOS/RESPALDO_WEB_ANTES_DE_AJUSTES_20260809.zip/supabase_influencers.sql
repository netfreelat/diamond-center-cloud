-- ============================================================
-- Diamond Center FF - Programa de Mini Influencers (TikTok)
-- Ejecutar en: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Perfiles de influencers (cuenta separada de ff_users)
CREATE TABLE IF NOT EXISTS ff_influencers (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  tiktok_handle TEXT NOT NULL,
  followers_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',   -- pending | approved | rejected | suspended
  diamonds_balance INTEGER DEFAULT 0,
  total_diamonds_earned INTEGER DEFAULT 0,
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_login TIMESTAMPTZ
);

-- Submissions de videos de TikTok
CREATE TABLE IF NOT EXISTS ff_influencer_submissions (
  id SERIAL PRIMARY KEY,
  influencer_id INTEGER NOT NULL REFERENCES ff_influencers(id) ON DELETE CASCADE,
  tiktok_url TEXT NOT NULL,
  title TEXT,
  description TEXT,
  screenshot_data TEXT,           -- Base64 de la captura de pantalla (evidencia)
  screenshot_filename TEXT,
  views_submitted INTEGER DEFAULT 0,   -- Vistas reportadas por el influencer
  views_verified INTEGER DEFAULT 0,    -- Vistas verificadas por el admin
  status TEXT DEFAULT 'pending',       -- pending | approved | rejected | paid
  diamonds_awarded INTEGER DEFAULT 0,
  admin_notes TEXT,
  week_start DATE,                     -- Semana a la que pertenece (lunes)
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ
);

-- Historial de pagos de diamantes
CREATE TABLE IF NOT EXISTS ff_influencer_payments (
  id SERIAL PRIMARY KEY,
  influencer_id INTEGER NOT NULL REFERENCES ff_influencers(id) ON DELETE CASCADE,
  submission_id INTEGER REFERENCES ff_influencer_submissions(id),
  diamonds_amount INTEGER NOT NULL,
  note TEXT,
  week_label TEXT,                 -- Ej: "Semana del 21-27 Jul 2026"
  paid_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de tarifas (configurable por el admin)
CREATE TABLE IF NOT EXISTS ff_influencer_rates (
  id SERIAL PRIMARY KEY,
  label TEXT NOT NULL,             -- Ej: "Basico", "Intermedio", "Popular", "Viral"
  min_views INTEGER NOT NULL,      -- Minimo de vistas
  max_views INTEGER,               -- Maximo de vistas (NULL = sin limite)
  diamonds_reward INTEGER NOT NULL,-- Diamantes a pagar
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- Indices para mejorar el rendimiento
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_submissions_influencer ON ff_influencer_submissions(influencer_id);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON ff_influencer_submissions(status);
CREATE INDEX IF NOT EXISTS idx_submissions_week ON ff_influencer_submissions(week_start);
CREATE INDEX IF NOT EXISTS idx_payments_influencer ON ff_influencer_payments(influencer_id);

-- ============================================================
-- Datos iniciales: Tabla de tarifas predeterminada
-- (El admin puede editarla desde el panel de administracion)
-- ============================================================
INSERT INTO ff_influencer_rates (label, min_views, max_views, diamonds_reward) VALUES
  ('Basico',      1000,   4999,   50),
  ('Intermedio',  5000,   9999,   150),
  ('Popular',     10000,  49999,  400),
  ('Viral',       50000,  99999,  1000),
  ('Mega Viral',  100000, NULL,   2500)
ON CONFLICT DO NOTHING;
