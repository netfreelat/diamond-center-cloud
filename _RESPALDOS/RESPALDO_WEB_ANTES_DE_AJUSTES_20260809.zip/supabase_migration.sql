-- ============================================================
-- Diamond Center FF - Migración de columnas faltantes
-- Ejecutar en: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- 1. Agregar columna referral_claimed a ff_users (para el sistema de referidos)
ALTER TABLE ff_users 
ADD COLUMN IF NOT EXISTS referral_claimed BOOLEAN DEFAULT FALSE;

-- 2. Agregar columna control_num a ff_orders (número de control del pedido)
ALTER TABLE ff_orders 
ADD COLUMN IF NOT EXISTS control_num TEXT;

-- 3. Agregar columna admin_session_token a ff_settings (para el inicio de sesión global)
ALTER TABLE ff_settings 
ADD COLUMN IF NOT EXISTS admin_session_token TEXT;

-- 4. (IMPORTANTE) Asegurarse que las credenciales del admin están configuradas
--    Si no tienes usuario/contraseña definidos, actualízalos aquí:
-- UPDATE ff_settings SET admin_username = 'admin', admin_password = '1234' WHERE id = 1;

-- 5. Agregar columnas de registro completo (apellido, cédula y teléfono) a ff_users
ALTER TABLE ff_users 
ADD COLUMN IF NOT EXISTS apellido TEXT,
ADD COLUMN IF NOT EXISTS cedula TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT;

-- 6. Agregar columna ip_address a ff_orders (para registrar la IP de compra)
ALTER TABLE ff_orders 
ADD COLUMN IF NOT EXISTS ip_address TEXT;

-- 7. Agregar columna delay a ff_wa_queue (para retardar envíos masivos y evitar bloqueos de WhatsApp)
ALTER TABLE ff_wa_queue 
ADD COLUMN IF NOT EXISTS delay INTEGER;
