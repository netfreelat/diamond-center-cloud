const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function find() {
    const { data: order, error } = await supabase
        .from('ff_orders')
        .select('*')
        .eq('ref', '0000171973')
        .single();

    if (error) {
        console.error('Error finding order:', error.message);
    } else {
        console.log('Order found:', order);
    }
}

find();
