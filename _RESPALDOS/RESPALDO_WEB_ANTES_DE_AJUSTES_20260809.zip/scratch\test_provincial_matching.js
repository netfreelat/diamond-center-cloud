const dotenv = require('dotenv');
dotenv.config();
const { verificarPagoBDV } = require('../bdv-service');

async function main() {
    console.log('--- TESTING REF 000000993 (6688.00 Bs) ---');
    try {
        const res1 = await verificarPagoBDV('000000993', 6688.00);
        console.log('Res 1:', res1);
    } catch (e) {
        console.error('Error 1:', e.message);
    }

    console.log('\n--- TESTING REF 0995 (6688.00 Bs) ---');
    try {
        const res2 = await verificarPagoBDV('0995', 6688.00);
        console.log('Res 2:', res2);
    } catch (e) {
        console.error('Error 2:', e.message);
    }
}

main();
