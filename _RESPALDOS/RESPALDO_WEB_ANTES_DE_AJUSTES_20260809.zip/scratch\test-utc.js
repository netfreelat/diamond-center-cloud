process.env.TZ = 'UTC';
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function testUTC() {
    const { data: allOrders } = await supabase
        .from('ff_orders')
        .select('ref, time, pack, price')
        .eq('status', 'approved')
        .order('time', { ascending: false });

    console.log('--- Testing under TZ=UTC ---');
    console.log('System time ISO:', new Date().toISOString());

    // Original server code:
    const nowVE = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Caracas' }));
    console.log('nowVE (toLocaleString parsed in UTC):', nowVE.toISOString());

    const startOfToday = new Date(nowVE);
    startOfToday.setHours(0, 0, 0, 0);
    console.log('startOfToday:', startOfToday.toISOString());

    let count = 0;
    allOrders.forEach(o => {
        const t = new Date(o.time);
        if (t >= startOfToday) {
            count++;
            console.log(`Match: Ref ${o.ref}, Time string: ${o.time}, Parsed t: ${t.toISOString()}`);
        }
    });
    console.log('Count:', count);
}

testUTC();
