/**
 * test-bdv-puppeteer.js
 * Prueba completa del login BDV con Puppeteer + extracción de movimientos
 */
require('dotenv').config();
const { bdvLogin, bdvMovimientos, verificarPagoBDV, getBDVStatus } = require('../bdv-service.js');

async function test() {
    console.log('='.repeat(50));
    console.log('🏦 TEST: BDV en línea con Puppeteer');
    console.log('='.repeat(50));
    console.log(`👤 Usuario: ${process.env.BDV_USER}`);
    console.log(`🏦 Cuenta: ${process.env.BDV_CUENTA}`);
    console.log('');

    // 1. Test de Login
    console.log('📌 PASO 1: Login...');
    const loginOk = await bdvLogin();
    console.log(`   Resultado: ${loginOk ? '✅ EXITOSO' : '❌ FALLIDO'}`);
    console.log('   Estado:', getBDVStatus());
    console.log('');

    if (!loginOk) {
        console.log('❌ Login falló. Revisa las credenciales o las capturas en scratch/');
        process.exit(1);
    }

    // 2. Test de Movimientos
    console.log('📌 PASO 2: Obteniendo movimientos...');
    const movs = await bdvMovimientos();
    
    if (movs && movs.length > 0) {
        console.log(`   ✅ ${movs.length} movimientos obtenidos`);
        console.log('   Primeros 3 movimientos:');
        movs.slice(0, 3).forEach((m, i) => {
            console.log(`   [${i+1}] Fecha: ${m.fecha || 'N/A'} | Ref: ${m.referencia || 'N/A'} | Monto: ${m.importe || 'N/A'} | Tipo: ${m.indicadorCargoAbono || 'N/A'} | Desc: ${m.descripcion || 'N/A'}`);
        });
    } else {
        console.log('   ❌ No se obtuvieron movimientos');
    }

    console.log('');
    console.log('✅ Test completado.');
    process.exit(0);
}

test().catch(e => {
    console.error('❌ Error inesperado:', e.message);
    process.exit(1);
});
