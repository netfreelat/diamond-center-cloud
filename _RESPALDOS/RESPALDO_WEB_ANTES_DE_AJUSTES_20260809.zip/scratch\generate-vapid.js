const fs = require('fs');
const path = require('path');
const webPush = require('web-push');

console.log('Generando llaves VAPID...');
const vapidKeys = webPush.generateVAPIDKeys();

const envPath = path.join(__dirname, '..', '.env');
let envContent = '';

if (fs.existsSync(envPath)) {
    envContent = fs.readFileSync(envPath, 'utf8');
}

// Limpiar llaves previas si existiesen
envContent = envContent.replace(/^VAPID_PUBLIC_KEY=.*$/m, '');
envContent = envContent.replace(/^VAPID_PRIVATE_KEY=.*$/m, '');
envContent = envContent.replace(/^VAPID_EMAIL=.*$/m, '');

// Remover líneas en blanco consecutivas creadas por la eliminación
envContent = envContent.replace(/\n{3,}/g, '\n\n');

// Añadir nuevas llaves
envContent += `\n\n# === WEB PUSH NOTIFICATIONS ===\nVAPID_EMAIL=mailto:netfreelat@gmail.com\nVAPID_PUBLIC_KEY=${vapidKeys.publicKey}\nVAPID_PRIVATE_KEY=${vapidKeys.privateKey}\n`;

fs.writeFileSync(envPath, envContent.trim() + '\n', 'utf8');

console.log('\n=========================================');
console.log('¡LLAVES VAPID GENERADAS Y AGREGADAS A .env!');
console.log('=========================================');
console.log('PÚBLICA (VAPID_PUBLIC_KEY):');
console.log(vapidKeys.publicKey);
console.log('-----------------------------------------');
console.log('PRIVADA (VAPID_PRIVATE_KEY):');
console.log(vapidKeys.privateKey);
console.log('=========================================\n');
console.log('Copia estas llaves para colocarlas en tus variables de entorno de Render cuando lo requieras.');
