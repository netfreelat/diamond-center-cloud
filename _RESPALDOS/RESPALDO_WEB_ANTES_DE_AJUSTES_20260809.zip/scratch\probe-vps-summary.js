const { createClient } = require('@supabase/supabase-js');
const https = require('https');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

async function probe() {
    const { data } = await supabase
        .from('ff_settings')
        .select('admin_password')
        .eq('id', 1)
        .single();

    const password = data ? data.admin_password : 'admin';
    console.log('Using admin password:', password);

    const postData = JSON.stringify({ password });

    const req = https.request('https://recargasney.com/admin/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
            console.log('Login response:', body);
            try {
                const json = JSON.parse(body);
                if (json.token) {
                    fetchSummary(json.token);
                }
            } catch (e) {
                console.error(e);
            }
        });
    });

    req.write(postData);
    req.end();
}

function fetchSummary(token) {
    https.get('https://recargasney.com/admin/financial-summary', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
            console.log('\n--- LIVE VPS FINANCIAL SUMMARY RESPONSE ---');
            console.log(body);
        });
    });
}

probe();
